# AbzuNet Changelog

## v2.0.2 (February 2026)

### Completed: Full Production Implementation

#### Network Integration
- `network/swarm.rs` — Complete libp2p swarm event loop with `select!` handler
- Kademlia, GossipSub, mDNS, Identify, and Ping events fully dispatched
- UDP broadcast mesh discovery bridged to swarm dial queue
- `SwarmHandle` channel API for safe external interaction with the swarm
- Heartbeat publication (15s interval) via GossipSub segmented topics
- Kademlia bootstrap on startup and periodic re-bootstrap (5min)

#### Kademlia Content Announcement
- `SwarmCommand::ProvideContent` triggers `kad.start_providing()` on upload
- `SwarmCommand::FindProviders` triggers provider lookup; gateway falls through to DHT if content not local
- GossipSub content announcement on `abzu/content` topic for immediate mesh propagation

#### ZK Slashing Circuit
- `zkp/poseidon.rs` — Native BN254 Poseidon hash (poseidon2, poseidon_attempt_hash)
- `zkp/circuit.rs` — Full R1CS `HeartbeatFailureCircuit` implementing all 4 constraint categories
- `zkp/prover.rs` — Complete Groth16 prove/verify/serialize lifecycle
- `abzu-circuits/src/poseidon/mod.rs` — Full S-box, MDS, and permutation gadgets
- `abzu-node zkp-setup` subcommand for one-time trusted setup

#### Blockchain Bridge
- `bridge/mod.rs` — Full `ContractBridge` with `deposit_escrow`, `get_staked_collateral`, `submit_slash`
- Graceful offline mode when no RPC is configured
- `BridgeConfig` struct with optional signer key for EIP-4337 integration

#### ANS DHT Propagation
- `SwarmCommand::DhtPutName` → `kad.put_record()` on every ANS registration
- `SwarmCommand::DhtGetName` → `kad.get_record()` with pending query tracking
- Gateway ANS handlers consult DHT on local cache miss

#### DTN Messaging System (Email Equivalent)
- `DtnMessage` — Full message type with vector clock, hop count, TTL, reply threading
- `VectorClock` — Merge-correct causal ordering for partitioned networks
- `DtnQueue` — Persistent inbox, outbox, and relay queue (sled-backed)
- Routing: local delivery vs. relay queue based on recipient node ID
- Sync digest for island reconnection handshake
- 30-second relay forwarding loop via GossipSub `abzu/dtn` topic

#### Gateway (v2.0.2)
- Full messaging API: `GET/POST/DELETE /abzu/messages`, `/abzu/messages/send`
- ANS handlers now propagate to DHT and report source (local vs. dht)
- Content retrieval falls through to DHT provider list on local miss
- Node status includes DTN stats

#### Browser UI (v2.0.2)
- Full Messages tab: inbox, compose, view, reply, delete
- ANS resolver shows source (local/DHT)
- Peers panel queries live swarm peer list
- DTN send queues via `abzu/dtn` GossipSub topic

#### CLI
- `abzu-node zk-setup` — runs Groth16 trusted setup
- Ctrl+C graceful shutdown

## v2.0.1 (February 2026)
- Initial enhanced release: storage, network, and gateway stub implementations filled
