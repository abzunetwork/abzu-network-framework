// abzu-node/src/storage/chunker.rs
//! Content Chunker - 4MB Fixed-Size Chunking with BLAKE3 Integrity
//!
//! Implements Phase 2: files divided into 4MB chunks, each independently
//! verifiable using BLAKE3, enabling Bao streaming and partial retrieval.

use anyhow::{Context, Result};
use std::fs::File;
use std::io::{BufReader, Read, Write};
use std::path::Path;

pub const CHUNK_SIZE: usize = 4 * 1024 * 1024; // 4MB per spec

#[derive(Debug, Clone)]
pub struct Chunk {
    pub index: usize,
    pub data: Vec<u8>,
    pub hash: [u8; 32],
}

impl Chunk {
    pub fn new(index: usize, data: Vec<u8>) -> Self {
        let hash = *blake3::hash(&data).as_bytes();
        Self { index, data, hash }
    }

    pub fn verify(&self) -> bool {
        *blake3::hash(&self.data).as_bytes() == self.hash
    }

    pub fn size(&self) -> usize {
        self.data.len()
    }
}

pub struct Chunker {
    chunk_size: usize,
}

impl Chunker {
    pub fn new() -> Self {
        Self { chunk_size: CHUNK_SIZE }
    }

    pub fn with_chunk_size(chunk_size: usize) -> Self {
        Self { chunk_size }
    }

    pub fn chunk_bytes(&self, data: &[u8]) -> (Vec<Chunk>, [u8; 32]) {
        let chunks: Vec<Chunk> = data
            .chunks(self.chunk_size)
            .enumerate()
            .map(|(i, s)| Chunk::new(i, s.to_vec()))
            .collect();
        let root_cid = self.compute_root_cid(&chunks);
        (chunks, root_cid)
    }

    pub fn chunk_file<P: AsRef<Path>>(&self, path: P) -> Result<(Vec<Chunk>, [u8; 32])> {
        let file = File::open(path.as_ref())
            .with_context(|| format!("Cannot open: {}", path.as_ref().display()))?;
        let mut reader = BufReader::new(file);
        let mut chunks = Vec::new();
        let mut index = 0;

        loop {
            let mut buf = vec![0u8; self.chunk_size];
            let mut total = 0;
            loop {
                match reader.read(&mut buf[total..]) {
                    Ok(0) => break,
                    Ok(n) => { total += n; if total == self.chunk_size { break; } }
                    Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                    Err(e) => return Err(e.into()),
                }
            }
            if total == 0 { break; }
            buf.truncate(total);
            chunks.push(Chunk::new(index, buf));
            index += 1;
        }

        if chunks.is_empty() { chunks.push(Chunk::new(0, vec![])); }
        let root_cid = self.compute_root_cid(&chunks);
        Ok((chunks, root_cid))
    }

    /// R_cid = BLAKE3(chunk_0 || chunk_1 || ... || chunk_n)
    pub fn compute_root_cid(&self, chunks: &[Chunk]) -> [u8; 32] {
        let mut hasher = blake3::Hasher::new();
        for chunk in chunks { hasher.update(&chunk.data); }
        *hasher.finalize().as_bytes()
    }

    pub fn reassemble(chunks: &[Chunk]) -> Result<Vec<u8>> {
        let mut sorted = chunks.to_vec();
        sorted.sort_by_key(|c| c.index);
        for chunk in &sorted {
            if !chunk.verify() {
                return Err(anyhow::anyhow!("Chunk {} integrity failure", chunk.index));
            }
        }
        let mut out = Vec::with_capacity(sorted.iter().map(|c| c.size()).sum());
        for chunk in sorted { out.extend_from_slice(&chunk.data); }
        Ok(out)
    }

    pub fn reassemble_to_file<P: AsRef<Path>>(chunks: &[Chunk], dest: P) -> Result<()> {
        let mut sorted = chunks.to_vec();
        sorted.sort_by_key(|c| c.index);
        let mut file = File::create(dest.as_ref())?;
        for chunk in &sorted {
            if !chunk.verify() {
                return Err(anyhow::anyhow!("Chunk {} integrity failure", chunk.index));
            }
            file.write_all(&chunk.data)?;
        }
        Ok(())
    }
}

impl Default for Chunker {
    fn default() -> Self { Self::new() }
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ChunkManifest {
    pub root_cid: [u8; 32],
    pub chunk_count: usize,
    pub total_bytes: usize,
    pub chunk_hashes: Vec<[u8; 32]>,
    pub chunk_sizes: Vec<usize>,
}

impl ChunkManifest {
    pub fn from_chunks(chunks: &[Chunk], root_cid: [u8; 32]) -> Self {
        let mut sorted = chunks.to_vec();
        sorted.sort_by_key(|c| c.index);
        Self {
            root_cid,
            chunk_count: sorted.len(),
            total_bytes: sorted.iter().map(|c| c.size()).sum(),
            chunk_hashes: sorted.iter().map(|c| c.hash).collect(),
            chunk_sizes: sorted.iter().map(|c| c.size()).collect(),
        }
    }

    pub fn verify_chunk(&self, chunk: &Chunk) -> bool {
        chunk.index < self.chunk_hashes.len() && chunk.hash == self.chunk_hashes[chunk.index]
    }

    pub fn root_cid_hex(&self) -> String { hex::encode(self.root_cid) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_roundtrip() {
        let chunker = Chunker::with_chunk_size(10);
        let original: Vec<u8> = (0..255u8).collect();
        let (chunks, _) = chunker.chunk_bytes(&original);
        let reassembled = Chunker::reassemble(&chunks).unwrap();
        assert_eq!(original, reassembled);
    }

    #[test]
    fn test_root_cid_deterministic() {
        let chunker = Chunker::with_chunk_size(16);
        let data = b"deterministic test";
        let (_, cid1) = chunker.chunk_bytes(data);
        let (_, cid2) = chunker.chunk_bytes(data);
        assert_eq!(cid1, cid2);
    }

    #[test]
    fn test_chunk_verify() {
        let chunk = Chunk::new(0, b"test data".to_vec());
        assert!(chunk.verify());
    }
}
