// abzu-node/src/storage/bao.rs
//! Bao-style Incremental Streaming Verification
//!
//! Implements incremental content verification during streaming retrieval.
//! As each chunk arrives, it is verified against the ChunkManifest before
//! being written to the output. This provides BLAKE3-based integrity without
//! requiring the full file to be buffered in memory (O(1) memory usage).

use anyhow::{Context, Result};
use std::io::Write;
use super::chunker::{Chunk, ChunkManifest};

/// Streaming verifier: validates chunks against a manifest as they arrive
pub struct BaoStreamVerifier {
    manifest: ChunkManifest,
    expected_chunks: usize,
    received: Vec<bool>,
}

impl BaoStreamVerifier {
    /// Create a verifier for a known manifest
    pub fn new(manifest: ChunkManifest) -> Self {
        let n = manifest.chunk_count;
        Self {
            manifest,
            expected_chunks: n,
            received: vec![false; n],
        }
    }

    /// Verify and accept a single chunk.
    ///
    /// Returns Ok(()) if the chunk is valid and belongs to this file.
    /// Returns Err if the hash doesn't match or the index is out of range.
    pub fn accept_chunk(&mut self, chunk: &Chunk) -> Result<()> {
        if chunk.index >= self.expected_chunks {
            return Err(anyhow::anyhow!(
                "Chunk index {} out of range (expected < {})",
                chunk.index, self.expected_chunks
            ));
        }

        if !self.manifest.verify_chunk(chunk) {
            return Err(anyhow::anyhow!(
                "Chunk {} hash mismatch: got {}, expected {}",
                chunk.index,
                hex::encode(chunk.hash),
                hex::encode(self.manifest.chunk_hashes[chunk.index])
            ));
        }

        self.received[chunk.index] = true;
        Ok(())
    }

    /// Check whether all chunks have been received and verified
    pub fn is_complete(&self) -> bool {
        self.received.iter().all(|&v| v)
    }

    /// Return indices of chunks not yet received
    pub fn missing_chunks(&self) -> Vec<usize> {
        self.received
            .iter()
            .enumerate()
            .filter(|(_, &r)| !r)
            .map(|(i, _)| i)
            .collect()
    }

    /// Verify the final root CID once all chunks are received
    pub fn verify_root_cid(&self, actual_root_cid: &[u8; 32]) -> bool {
        *actual_root_cid == self.manifest.root_cid
    }

    /// Get the manifest for reference
    pub fn manifest(&self) -> &ChunkManifest {
        &self.manifest
    }
}

/// Streaming writer: verifies and writes chunks to a sink in order
///
/// Buffers out-of-order chunks and writes them in sequence order to
/// maintain the streaming invariant without full-file buffering.
pub struct BaoStreamWriter<W: Write> {
    verifier: BaoStreamVerifier,
    writer: W,
    next_expected: usize,
    buffer: std::collections::BTreeMap<usize, Vec<u8>>,
    bytes_written: u64,
}

impl<W: Write> BaoStreamWriter<W> {
    pub fn new(manifest: ChunkManifest, writer: W) -> Self {
        Self {
            verifier: BaoStreamVerifier::new(manifest),
            writer,
            next_expected: 0,
            buffer: std::collections::BTreeMap::new(),
            bytes_written: 0,
        }
    }

    /// Accept a chunk (any order), verify it, and write in-order chunks immediately
    pub fn write_chunk(&mut self, chunk: Chunk) -> Result<()> {
        self.verifier.accept_chunk(&chunk)?;

        // Buffer this chunk's data
        self.buffer.insert(chunk.index, chunk.data);

        // Write as many in-order chunks as possible
        while let Some(data) = self.buffer.remove(&self.next_expected) {
            self.writer.write_all(&data)
                .context("Failed to write chunk to output")?;
            self.bytes_written += data.len() as u64;
            self.next_expected += 1;
        }

        Ok(())
    }

    /// Finalize - verify all chunks received and flush the writer
    pub fn finalize(mut self) -> Result<(W, u64)> {
        if !self.verifier.is_complete() {
            let missing = self.verifier.missing_chunks();
            return Err(anyhow::anyhow!(
                "Stream incomplete: missing chunks {:?}", missing
            ));
        }
        if !self.buffer.is_empty() {
            return Err(anyhow::anyhow!(
                "Write ordering error: {} chunks unwritten", self.buffer.len()
            ));
        }
        self.writer.flush().context("Failed to flush output")?;
        Ok((self.writer, self.bytes_written))
    }

    pub fn bytes_written(&self) -> u64 {
        self.bytes_written
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use super::super::chunker::Chunker;

    #[test]
    fn test_stream_verifier_happy_path() {
        let chunker = Chunker::with_chunk_size(8);
        let data = b"Hello, Bao streaming verification!".to_vec();
        let (chunks, root_cid) = chunker.chunk_bytes(&data);
        let manifest = ChunkManifest::from_chunks(&chunks, root_cid);

        let mut verifier = BaoStreamVerifier::new(manifest);
        for chunk in &chunks {
            verifier.accept_chunk(chunk).unwrap();
        }

        assert!(verifier.is_complete());
        assert!(verifier.verify_root_cid(&root_cid));
        assert!(verifier.missing_chunks().is_empty());
    }

    #[test]
    fn test_stream_verifier_bad_chunk() {
        let chunker = Chunker::with_chunk_size(8);
        let data = b"Good data here".to_vec();
        let (chunks, root_cid) = chunker.chunk_bytes(&data);
        let manifest = ChunkManifest::from_chunks(&chunks, root_cid);

        let mut verifier = BaoStreamVerifier::new(manifest);
        // Tamper with chunk data
        let bad_chunk = Chunk { index: 0, data: b"Bad data!".to_vec(), hash: chunks[0].hash };
        let result = verifier.accept_chunk(&bad_chunk);
        assert!(result.is_err());
    }

    #[test]
    fn test_stream_writer_in_order() {
        let chunker = Chunker::with_chunk_size(8);
        let original = b"Streaming write test - in order".to_vec();
        let (chunks, root_cid) = chunker.chunk_bytes(&original);
        let manifest = ChunkManifest::from_chunks(&chunks, root_cid);

        let output = Vec::new();
        let mut writer = BaoStreamWriter::new(manifest, output);
        for chunk in chunks {
            writer.write_chunk(chunk).unwrap();
        }
        let (result, _) = writer.finalize().unwrap();
        assert_eq!(result, original);
    }

    #[test]
    fn test_stream_writer_out_of_order() {
        let chunker = Chunker::with_chunk_size(8);
        let original = b"Out of order streaming test data".to_vec();
        let (mut chunks, root_cid) = chunker.chunk_bytes(&original);
        let manifest = ChunkManifest::from_chunks(&chunks, root_cid);

        // Reverse chunk order
        chunks.reverse();

        let output = Vec::new();
        let mut writer = BaoStreamWriter::new(manifest, output);
        for chunk in chunks {
            writer.write_chunk(chunk).unwrap();
        }
        let (result, _) = writer.finalize().unwrap();
        assert_eq!(result, original);
    }
}
