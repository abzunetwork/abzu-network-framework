// abzu-node/src/zkp/prover.rs
//! Groth16 Proof Generation and Verification for Slashing
//!
//! Full lifecycle: setup → prove → verify → serialize for on-chain submission.

use anyhow::{Context, Result};
use ark_bn254::{Bn254, Fr};
use ark_groth16::{
    prepare_verifying_key, Groth16, PreparedVerifyingKey, ProvingKey, VerifyingKey,
};
use ark_serialize::{CanonicalDeserialize, CanonicalSerialize};
use ark_snark::SNARK;
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};
use std::path::Path;
use tracing::{info, warn};

use super::circuit::{HeartbeatFailureCircuit, SlashPublicInputs, SlashWitness};
use super::poseidon::{poseidon2, poseidon_attempt_hash};

/// A serialized Groth16 proof for network transmission and on-chain submission
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SerializedProof {
    pub proof_bytes: Vec<u8>,
    pub public_inputs: Vec<Vec<u8>>,
    pub circuit_version: u32,
}

impl SerializedProof {
    pub fn circuit_version() -> u32 { 1 }

    pub fn to_calldata(&self) -> Vec<u8> {
        bincode::serialize(self).unwrap_or_default()
    }

    pub fn from_calldata(bytes: &[u8]) -> Result<Self> {
        bincode::deserialize(bytes).context("Failed to deserialize proof calldata")
    }
}

/// Manages proving/verifying keys and Groth16 proof generation
pub struct SlashProver {
    proving_key: ProvingKey<Bn254>,
    prepared_vk: PreparedVerifyingKey<Bn254>,
}

impl SlashProver {
    /// Load keys from disk or run one-time trusted setup if not present
    pub fn setup_or_load<P: AsRef<Path>>(keys_dir: P) -> Result<Self> {
        let pk_path = keys_dir.as_ref().join("slash_proving_key.bin");
        let vk_path = keys_dir.as_ref().join("slash_verifying_key.bin");
        if pk_path.exists() && vk_path.exists() {
            return Self::load_keys(pk_path, vk_path);
        }
        info!("Generating Groth16 proving keys (one-time setup)…");
        Self::generate_and_save_keys(keys_dir)
    }

    fn generate_and_save_keys<P: AsRef<Path>>(dir: P) -> Result<Self> {
        std::fs::create_dir_all(dir.as_ref())?;
        let circuit = HeartbeatFailureCircuit {
            public: dummy_public_inputs(),
            witness: Some(dummy_witness()),
        };
        let mut rng = OsRng;
        let (pk, vk) = Groth16::<Bn254>::circuit_specific_setup(circuit, &mut rng)
            .context("Groth16 circuit setup failed")?;

        let pk_path = dir.as_ref().join("slash_proving_key.bin");
        let vk_path = dir.as_ref().join("slash_verifying_key.bin");
        let mut pk_bytes = Vec::new();
        pk.serialize_compressed(&mut pk_bytes)?;
        std::fs::write(&pk_path, &pk_bytes)?;
        let mut vk_bytes = Vec::new();
        vk.serialize_compressed(&mut vk_bytes)?;
        std::fs::write(&vk_path, &vk_bytes)?;
        info!("Proving key: {} bytes  Verifying key: {} bytes", pk_bytes.len(), vk_bytes.len());

        let prepared_vk = prepare_verifying_key(&vk);
        Ok(Self { proving_key: pk, prepared_vk })
    }

    fn load_keys<P: AsRef<Path>>(pk_path: P, vk_path: P) -> Result<Self> {
        let pk_bytes = std::fs::read(pk_path.as_ref())?;
        let vk_bytes = std::fs::read(vk_path.as_ref())?;
        let proving_key = ProvingKey::<Bn254>::deserialize_compressed(&*pk_bytes)
            .context("Failed to deserialize proving key")?;
        let vk = VerifyingKey::<Bn254>::deserialize_compressed(&*vk_bytes)
            .context("Failed to deserialize verifying key")?;
        info!("Groth16 keys loaded from disk");
        Ok(Self { proving_key, prepared_vk: prepare_verifying_key(&vk) })
    }

    /// Generate a ZK proof from witness data
    pub fn prove(&self, public: SlashPublicInputs, witness: SlashWitness) -> Result<SerializedProof> {
        let circuit = HeartbeatFailureCircuit { public: public.clone(), witness: Some(witness) };
        let mut rng = OsRng;
        let proof = Groth16::<Bn254>::prove(&self.proving_key, circuit, &mut rng)
            .context("Groth16 proof generation failed")?;

        let mut proof_bytes = Vec::new();
        proof.serialize_compressed(&mut proof_bytes)?;

        let mut public_inputs = Vec::new();
        for input in &[Fr::from(public.t_chain), public.h_accused,
                       public.h_att[0], public.h_att[1], public.h_att[2]] {
            let mut bytes = Vec::new();
            input.serialize_compressed(&mut bytes)?;
            public_inputs.push(bytes);
        }

        Ok(SerializedProof { proof_bytes, public_inputs, circuit_version: SerializedProof::circuit_version() })
    }

    /// Verify a serialized proof
    pub fn verify(&self, serialized: &SerializedProof) -> Result<bool> {
        use ark_groth16::Proof;
        let proof = Proof::<Bn254>::deserialize_compressed(&*serialized.proof_bytes)
            .context("Failed to deserialize proof")?;
        let public_inputs: Vec<Fr> = serialized.public_inputs.iter()
            .map(|b| Fr::deserialize_compressed(&**b).context("Bad public input"))
            .collect::<Result<_>>()?;
        let verified = Groth16::<Bn254>::verify_with_processed_vk(&self.prepared_vk, &public_inputs, &proof)
            .context("Groth16 verification error")?;
        if !verified { warn!("Slash proof INVALID"); } else { info!("Slash proof VALID"); }
        Ok(verified)
    }

    /// Compute public inputs from raw witness values (without proving)
    pub fn compute_public_inputs(
        n_high: u128, n_low: u128, t_chain: u64,
        reporter_ip: u128, nonces: [u128; 3], as_numbers: [u128; 3], timestamps: [u64; 3],
    ) -> SlashPublicInputs {
        SlashPublicInputs {
            t_chain,
            h_accused: poseidon2(n_high, n_low),
            h_att: [
                poseidon_attempt_hash(reporter_ip, nonces[0], as_numbers[0], n_high, n_low, timestamps[0] as u128),
                poseidon_attempt_hash(reporter_ip, nonces[1], as_numbers[1], n_high, n_low, timestamps[1] as u128),
                poseidon_attempt_hash(reporter_ip, nonces[2], as_numbers[2], n_high, n_low, timestamps[2] as u128),
            ],
        }
    }
}

fn dummy_public_inputs() -> SlashPublicInputs {
    SlashPublicInputs {
        t_chain: 1700000000,
        h_accused: poseidon2(1, 2),
        h_att: [poseidon2(3, 4), poseidon2(5, 6), poseidon2(7, 8)],
    }
}

fn dummy_witness() -> SlashWitness {
    SlashWitness {
        reporter_ip: 0x7f000001u128,
        n_high: 1, n_low: 2,
        nonces: [10, 20, 30],
        as_numbers: [64496, 64497, 64498],
        timestamps: [1699999100, 1699999500, 1699999900],
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[test]
    fn test_prove_and_verify() {
        let dir = TempDir::new().unwrap();
        let prover = SlashProver::setup_or_load(dir.path()).unwrap();
        let w = dummy_witness();
        let public = SlashProver::compute_public_inputs(
            w.n_high, w.n_low, w.timestamps[2] + 100,
            w.reporter_ip, w.nonces, w.as_numbers, w.timestamps,
        );
        let proof = prover.prove(public, w).unwrap();
        assert!(prover.verify(&proof).unwrap());
    }
}
