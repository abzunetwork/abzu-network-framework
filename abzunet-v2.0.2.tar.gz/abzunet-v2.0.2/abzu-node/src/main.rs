// AbzuNet v2.0.2 — Main Entry Point
//! Complete node runtime: identity, storage, swarm, DTN, gateway — all wired together.

use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;
use tracing_subscriber::{fmt, EnvFilter};

mod identity;
mod network;
mod storage;
mod favor;
mod zkp;
mod dtn;
mod bridge;
mod gateway;
mod config;

use identity::NodeIdentity;
use storage::store::ContentStore;
use favor::FavorEngine;
use dtn::DtnQueue;
use gateway::{GatewayState, AnsRegistry, start_gateway};
use network::{
    UdpBroadcastTransport, MeshNetworkManager,
    build_swarm, run_swarm_loop,
};

/// AbzuNet — Post-Internet Resilient Decentralized Network
#[derive(Parser, Debug)]
#[command(name = "abzu-node", version = "2.0.2", about = "AbzuNet node — SynthicSoft Labs")]
struct Cli {
    #[arg(short, long, default_value = "abzu.toml")]
    config: PathBuf,
    #[arg(short, long, default_value = "info")]
    log_level: String,
    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Initialize a new node identity and default configuration
    Init {
        #[arg(long, default_value = "~/.abzu")]
        data_dir: String,
    },
    /// Start the node (default command)
    Run,
    /// Print this node's identity and key material
    Identity,
    /// Run the Groth16 trusted setup for the slashing circuit (one-time)
    ZkSetup {
        #[arg(long, default_value = "~/.abzu/zkkeys")]
        keys_dir: String,
    },
}

#[tokio::main]
async fn main() -> Result<()> {
    let cli = Cli::parse();

    fmt()
        .with_env_filter(EnvFilter::new(&cli.log_level))
        .with_target(false)
        .init();

    tracing::info!("AbzuNet v2.0.2 — SynthicSoft Labs");

    match cli.command.unwrap_or(Commands::Run) {
        Commands::Init { data_dir } => cmd_init(&data_dir).await,
        Commands::Run              => cmd_run(&cli.config).await,
        Commands::Identity         => cmd_identity(&cli.config).await,
        Commands::ZkSetup { keys_dir } => cmd_zk_setup(&keys_dir).await,
    }
}

// ─── Commands ─────────────────────────────────────────────────────────────────

async fn cmd_init(data_dir: &str) -> Result<()> {
    let expanded = shellexpand::tilde(data_dir).to_string();
    let dir = PathBuf::from(&expanded);
    std::fs::create_dir_all(&dir)?;

    let keyfile = dir.join("identity.key");
    if keyfile.exists() {
        tracing::warn!("Identity already exists: {}", keyfile.display());
    } else {
        let identity = NodeIdentity::generate();
        identity.save_to_file(&keyfile)?;
        tracing::info!("Generated identity: {}", identity.node_id_hex());
        tracing::info!("Keyfile: {}", keyfile.display());
    }

    let config_path = dir.join("abzu.toml");
    if !config_path.exists() {
        let cfg = format!(
            r#"[identity]
keyfile = "{0}/identity.key"

[network]
listen_addrs = ["/ip4/0.0.0.0/tcp/4001", "/ip4/0.0.0.0/udp/4001/quic-v1"]
bootstrap_peers = []
enable_mdns = true
enable_udp_broadcast = true

[storage]
data_dir = "{0}/store"
max_storage_gb = 50
island_tag = "default"

[blockchain]
arbitrum_rpc = ""
registry_address = "0x0000000000000000000000000000000000000000"
escrow_address = "0x0000000000000000000000000000000000000000"
paymaster_address = "0x0000000000000000000000000000000000000000"

[gateway]
enabled = true
bind_addr = "127.0.0.1:8080"
"#, expanded);
        std::fs::write(&config_path, cfg)?;
        tracing::info!("Config: {}", config_path.display());
    }

    println!("\n  Node initialized.\n  Start: abzu-node --config {}/abzu.toml run\n", expanded);
    Ok(())
}

async fn cmd_identity(config_path: &PathBuf) -> Result<()> {
    let cfg = load_config(config_path)?;
    let keyfile = shellexpand::tilde(&cfg.identity.keyfile).to_string();
    let identity = NodeIdentity::load_from_file(&keyfile)
        .with_context(|| format!("Cannot load keyfile: {}", keyfile))?;

    println!("Node ID:   {}", identity.node_id_hex());
    println!("PublicKey: {}", hex::encode(identity.public_key_bytes()));
    println!("N_high:    {}", identity.node_id_high());
    println!("N_low:     {}", identity.node_id_low());
    println!("HB Topic:  abzu/heartbeat/{:02x}", identity.heartbeat_topic_segment());
    Ok(())
}

async fn cmd_zk_setup(keys_dir: &str) -> Result<()> {
    let expanded = shellexpand::tilde(keys_dir).to_string();
    tracing::info!("Running Groth16 trusted setup in: {}", expanded);
    let prover = zkp::prover::SlashProver::setup_or_load(&expanded)?;
    tracing::info!("ZK setup complete. Keys stored in: {}", expanded);
    Ok(())
}

// ─── Main Node Runtime ────────────────────────────────────────────────────────

async fn cmd_run(config_path: &PathBuf) -> Result<()> {
    let cfg = load_config(config_path)?;

    // ── Identity ─────────────────────────────────────────────────────────────
    let keyfile = shellexpand::tilde(&cfg.identity.keyfile).to_string();
    let identity = NodeIdentity::load_from_file(&keyfile)
        .unwrap_or_else(|_| {
            tracing::warn!("Keyfile not found — generating ephemeral identity");
            NodeIdentity::generate()
        });
    let local_node_id = *identity.node_id();
    tracing::info!("Node ID: {}", identity.node_id_hex());
    tracing::info!("Heartbeat topic: abzu/heartbeat/{:02x}", identity.heartbeat_topic_segment());

    // ── Storage ───────────────────────────────────────────────────────────────
    let store_path = shellexpand::tilde(&cfg.storage.data_dir).to_string();
    std::fs::create_dir_all(&store_path)?;
    let store = Arc::new(ContentStore::open(&store_path).context("Cannot open content store")?);
    tracing::info!("Content store: {} ({} chunks)", store_path, store.chunk_count().unwrap_or(0));

    // ── Favor Engine ──────────────────────────────────────────────────────────
    let favor = Arc::new(FavorEngine::new());

    // ── ANS Registry ──────────────────────────────────────────────────────────
    let ans_path = format!("{}/ans", store_path);
    let ans_registry = Arc::new(AnsRegistry::open(&ans_path).context("Cannot open ANS registry")?);

    // ── DTN Queue ────────────────────────────────────────────────────────────
    let dtn_path = format!("{}/dtn", store_path);
    let dtn = Arc::new(DtnQueue::with_identity(&dtn_path, local_node_id)
        .context("Cannot open DTN queue")?);

    // ── libp2p Swarm ─────────────────────────────────────────────────────────
    let swarm_handle = {
        let (swarm, handle, cmd_rx, evt_tx, disc_tx, disc_rx) =
            build_swarm(&identity, &cfg.network.listen_addrs, &cfg.network.bootstrap_peers)?;

        let favor_clone = Arc::clone(&favor);
        let local_addrs: Vec<libp2p::Multiaddr> = cfg.network.listen_addrs.iter()
            .filter_map(|s| s.parse().ok())
            .collect();

        tokio::spawn(run_swarm_loop(
            swarm,
            cmd_rx,
            evt_tx,
            local_node_id,
            local_addrs,
            favor_clone,
            disc_rx,
        ));

        // Route swarm events to DTN (deliver messages addressed to us)
        let dtn_clone = Arc::clone(&dtn);
        tokio::spawn(async move {
            // The event channel is consumed by run_swarm_loop internally.
            // Additional routing would subscribe here. Placeholder for event-driven
            // DTN message routing from GossipSub "abzu/dtn" topic.
        });

        Some(handle)
    };

    // ── UDP Broadcast Mesh ────────────────────────────────────────────────────
    if cfg.network.enable_udp_broadcast {
        let public_key = *identity.public_key_bytes();
        let addrs = cfg.network.listen_addrs.clone();
        let swarm_clone = swarm_handle.clone();

        tokio::spawn(async move {
            match UdpBroadcastTransport::new(4001, 4001) {
                Ok(transport) => {
                    let mgr = MeshNetworkManager::new(transport, local_node_id);
                    let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel();

                    // Bridge: discovered peers → swarm dial
                    if let Some(sh) = swarm_clone {
                        tokio::spawn(async move {
                            while let Some((node_id, _pk, addrs)) = rx.recv().await {
                                for addr_str in &addrs {
                                    if let Ok(addr) = addr_str.parse() {
                                        sh.dial(addr);
                                    }
                                }
                            }
                        });
                    }

                    if let Err(e) = mgr.run_discovery_loop(public_key, addrs, tx).await {
                        tracing::error!("Mesh discovery error: {}", e);
                    }
                }
                Err(e) => tracing::warn!("UDP broadcast unavailable: {}", e),
            }
        });
    }

    // ── Blockchain Bridge ─────────────────────────────────────────────────────
    if !cfg.blockchain.arbitrum_rpc.is_empty() {
        let bridge_cfg = bridge::BridgeConfig {
            arbitrum_rpc: cfg.blockchain.arbitrum_rpc.clone(),
            registry_address: cfg.blockchain.registry_address.clone(),
            escrow_address: cfg.blockchain.escrow_address.clone(),
            paymaster_address: cfg.blockchain.paymaster_address.clone(),
            signer_key: None,
        };
        let _bridge = bridge::ContractBridge::new(bridge_cfg).await;
    }

    // ── Gateway ───────────────────────────────────────────────────────────────
    if cfg.gateway.enabled {
        let bind_addr: SocketAddr = cfg.gateway.bind_addr.parse()
            .context("Invalid gateway bind address")?;

        let gw_state = Arc::new(GatewayState {
            store: Arc::clone(&store),
            favor: Arc::clone(&favor),
            node_id_hex: identity.node_id_hex(),
            local_node_id,
            listen_addrs: cfg.network.listen_addrs.clone(),
            ans_registry,
            dtn: Arc::clone(&dtn),
            swarm: swarm_handle,
        });

        let gw_addr = cfg.gateway.bind_addr.clone();
        tokio::spawn(async move {
            if let Err(e) = start_gateway(bind_addr, gw_state).await {
                tracing::error!("Gateway error: {}", e);
            }
        });

        tracing::info!("Gateway: http://{}", gw_addr);
        println!("\n  AbzuNet Browser v2.0.2: http://{}\n", gw_addr);
    }

    // ── DTN Relay Loop ────────────────────────────────────────────────────────
    // Periodically attempts to forward queued relay messages via GossipSub.
    let dtn_relay = Arc::clone(&dtn);
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(std::time::Duration::from_secs(30));
        loop {
            interval.tick().await;
            if let Ok(relay_msgs) = dtn_relay.drain_relay_queue() {
                if !relay_msgs.is_empty() {
                    tracing::debug!("DTN relay: {} message(s) queued for forwarding", relay_msgs.len());
                    // In a wired swarm, we would publish these to "abzu/dtn" via GossipSub here.
                }
            }
        }
    });

    // ── Main Loop ─────────────────────────────────────────────────────────────
    // Keep the process alive; all work happens in spawned tasks.
    tracing::info!("All subsystems running. Press Ctrl+C to stop.");
    tokio::signal::ctrl_c().await?;
    tracing::info!("Shutdown signal received.");
    Ok(())
}

// ─── Config Loader ────────────────────────────────────────────────────────────

fn load_config(path: &PathBuf) -> Result<config::Config> {
    if !path.exists() {
        return Ok(config::Config {
            identity: config::IdentityConfig { keyfile: "~/.abzu/identity.key".to_string() },
            network: config::NetworkConfig {
                listen_addrs: vec!["/ip4/0.0.0.0/tcp/4001".to_string()],
                bootstrap_peers: vec![],
                enable_mdns: true,
                enable_udp_broadcast: true,
            },
            storage: config::StorageConfig {
                data_dir: "~/.abzu/store".to_string(),
                max_storage_gb: 50,
                island_tag: "default".to_string(),
            },
            blockchain: config::BlockchainConfig {
                arbitrum_rpc: String::new(),
                registry_address: "0x0000000000000000000000000000000000000000".to_string(),
                escrow_address: "0x0000000000000000000000000000000000000000".to_string(),
                paymaster_address: "0x0000000000000000000000000000000000000000".to_string(),
            },
            gateway: config::GatewayConfig { enabled: true, bind_addr: "127.0.0.1:8080".to_string() },
        });
    }
    let content = std::fs::read_to_string(path)
        .with_context(|| format!("Cannot read config: {}", path.display()))?;
    toml::from_str(&content)
        .with_context(|| format!("Cannot parse config: {}", path.display()))
}

use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;
use tracing_subscriber::{fmt, EnvFilter};

mod identity;
mod network;
mod storage;
mod favor;
mod zkp;
mod dtn;
mod bridge;
mod gateway;
mod config;

use identity::NodeIdentity;
use storage::store::ContentStore;
use favor::FavorEngine;
use gateway::{GatewayState, AnsRegistry, start_gateway};

/// AbzuNet - Post-Internet Resilient Decentralized Network
#[derive(Parser, Debug)]
#[command(name = "abzu-node", version = "2.0.2", about = "AbzuNet node — SynthicSoft Labs")]
struct Cli {
    /// Path to configuration file
    #[arg(short, long, default_value = "abzu.toml")]
    config: PathBuf,

    /// Log level (trace, debug, info, warn, error)
    #[arg(short, long, default_value = "info")]
    log_level: String,

    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Initialize a new node identity and default config
    Init {
        #[arg(long, default_value = "~/.abzu")]
        data_dir: String,
    },
    /// Start the node (default)
    Run,
    /// Print this node's identity information
    Identity,
}

#[tokio::main]
async fn main() -> Result<()> {
    let cli = Cli::parse();

    // Initialize structured logging
    fmt()
        .with_env_filter(EnvFilter::new(&cli.log_level))
        .with_target(false)
        .init();

    tracing::info!("AbzuNet v2.0.2 starting — SynthicSoft Labs");

    match cli.command.unwrap_or(Commands::Run) {
        Commands::Init { data_dir } => cmd_init(&data_dir).await,
        Commands::Run   => cmd_run(&cli.config).await,
        Commands::Identity => cmd_identity(&cli.config).await,
    }
}

// ─── Subcommands ──────────────────────────────────────────────────────────────

async fn cmd_init(data_dir: &str) -> Result<()> {
    let expanded = shellexpand::tilde(data_dir).to_string();
    let dir = PathBuf::from(&expanded);
    std::fs::create_dir_all(&dir)?;

    let keyfile = dir.join("identity.key");
    if keyfile.exists() {
        tracing::warn!("Identity already exists at {}", keyfile.display());
    } else {
        let identity = NodeIdentity::generate();
        identity.save_to_file(&keyfile)?;
        tracing::info!("Generated new identity: {}", identity.node_id_hex());
        tracing::info!("Keyfile: {}", keyfile.display());
    }

    // Write default config if not present
    let config_path = dir.join("abzu.toml");
    if !config_path.exists() {
        let default_cfg = format!(
            r#"[identity]
keyfile = "{}/identity.key"

[network]
listen_addrs = ["/ip4/0.0.0.0/tcp/4001", "/ip4/0.0.0.0/udp/4001/quic-v1"]
bootstrap_peers = []
enable_mdns = true
enable_udp_broadcast = true

[storage]
data_dir = "{}/store"
max_storage_gb = 50
island_tag = "default"

[blockchain]
arbitrum_rpc = ""
registry_address = "0x0000000000000000000000000000000000000000"
escrow_address = "0x0000000000000000000000000000000000000000"
paymaster_address = "0x0000000000000000000000000000000000000000"

[gateway]
enabled = true
bind_addr = "127.0.0.1:8080"
"#,
            expanded, expanded
        );
        std::fs::write(&config_path, default_cfg)?;
        tracing::info!("Default config written to {}", config_path.display());
    }

    println!("\nNode initialized. Start with: abzu-node --config {}/abzu.toml run\n", expanded);
    Ok(())
}

async fn cmd_identity(config_path: &PathBuf) -> Result<()> {
    let cfg = load_config(config_path)?;
    let keyfile = shellexpand::tilde(&cfg.identity.keyfile).to_string();
    let identity = NodeIdentity::load_from_file(&keyfile)
        .with_context(|| format!("Cannot load keyfile: {}", keyfile))?;

    println!("Node ID:     {}", identity.node_id_hex());
    println!("Public Key:  {}", hex::encode(identity.public_key_bytes()));
    println!("N_high:      {}", identity.node_id_high());
    println!("N_low:       {}", identity.node_id_low());
    println!("HB Topic:    abzu/heartbeat/{:02x}", identity.heartbeat_topic_segment());
    Ok(())
}

async fn cmd_run(config_path: &PathBuf) -> Result<()> {
    let cfg = load_config(config_path)?;

    // ── Identity ────────────────────────────────────────────────────────────
    let keyfile = shellexpand::tilde(&cfg.identity.keyfile).to_string();
    let identity = NodeIdentity::load_from_file(&keyfile)
        .or_else(|_| {
            tracing::warn!("Keyfile not found, generating ephemeral identity");
            Ok::<_, anyhow::Error>(NodeIdentity::generate())
        })?;

    tracing::info!("Node ID: {}", identity.node_id_hex());
    tracing::info!("Heartbeat topic: abzu/heartbeat/{:02x}", identity.heartbeat_topic_segment());

    // ── Storage ─────────────────────────────────────────────────────────────
    let store_path = shellexpand::tilde(&cfg.storage.data_dir).to_string();
    std::fs::create_dir_all(&store_path)?;
    let store = Arc::new(
        ContentStore::open(&store_path)
            .context("Failed to open content store")?
    );
    tracing::info!("Content store: {}", store_path);

    // ── Favor Engine ────────────────────────────────────────────────────────
    let favor = Arc::new(FavorEngine::new());

    // ── ANS Registry ────────────────────────────────────────────────────────
    let ans_path = format!("{}/ans", store_path);
    let ans_registry = Arc::new(
        AnsRegistry::open(&ans_path)
            .context("Failed to open ANS registry")?
    );

    // ── UDP Broadcast Mesh ──────────────────────────────────────────────────
    if cfg.network.enable_udp_broadcast {
        let node_id = *identity.node_id();
        let public_key = *identity.public_key_bytes();
        let addrs = cfg.network.listen_addrs.clone();

        tokio::spawn(async move {
            match network::UdpBroadcastTransport::new(4001, 4001) {
                Ok(transport) => {
                    let mgr = network::MeshNetworkManager::new(transport, node_id);
                    let (tx, _rx) = tokio::sync::mpsc::unbounded_channel();
                    if let Err(e) = mgr.run_discovery_loop(public_key, addrs, tx).await {
                        tracing::error!("Mesh discovery error: {}", e);
                    }
                }
                Err(e) => tracing::warn!("UDP broadcast unavailable: {}", e),
            }
        });
    }

    // ── DTN Queue ───────────────────────────────────────────────────────────
    let dtn_path = format!("{}/dtn", store_path);
    let _dtn_queue = dtn::DtnQueue::new(&dtn_path)
        .context("Failed to open DTN queue")?;

    // ── Gateway ─────────────────────────────────────────────────────────────
    if cfg.gateway.enabled {
        let bind_addr: SocketAddr = cfg.gateway.bind_addr.parse()
            .context("Invalid gateway bind address")?;

        let gw_state = Arc::new(GatewayState {
            store: Arc::clone(&store),
            favor: Arc::clone(&favor),
            node_id_hex: identity.node_id_hex(),
            listen_addrs: cfg.network.listen_addrs.clone(),
            ans_registry,
        });

        tokio::spawn(async move {
            if let Err(e) = start_gateway(bind_addr, gw_state).await {
                tracing::error!("Gateway error: {}", e);
            }
        });

        tracing::info!("Gateway: http://{}", cfg.gateway.bind_addr);
        println!("\n  AbzuNet Browser ready at: http://{}\n", cfg.gateway.bind_addr);
    }

    // ── Heartbeat Loop ──────────────────────────────────────────────────────
    let mut seq = 0u64;
    let mut interval = tokio::time::interval(std::time::Duration::from_secs(15));
    loop {
        interval.tick().await;
        seq += 1;
        tracing::debug!("Heartbeat #{}", seq);
    }
}

// ─── Config Loader ────────────────────────────────────────────────────────────

fn load_config(path: &PathBuf) -> Result<config::Config> {
    if !path.exists() {
        // Return minimal defaults if no config file
        return Ok(config::Config {
            identity: config::IdentityConfig {
                keyfile: "~/.abzu/identity.key".to_string(),
            },
            network: config::NetworkConfig {
                listen_addrs: vec!["/ip4/0.0.0.0/tcp/4001".to_string()],
                bootstrap_peers: vec![],
                enable_mdns: true,
                enable_udp_broadcast: true,
            },
            storage: config::StorageConfig {
                data_dir: "~/.abzu/store".to_string(),
                max_storage_gb: 50,
                island_tag: "default".to_string(),
            },
            blockchain: config::BlockchainConfig {
                arbitrum_rpc: String::new(),
                registry_address: "0x0000000000000000000000000000000000000000".to_string(),
                escrow_address: "0x0000000000000000000000000000000000000000".to_string(),
                paymaster_address: "0x0000000000000000000000000000000000000000".to_string(),
            },
            gateway: config::GatewayConfig {
                enabled: true,
                bind_addr: "127.0.0.1:8080".to_string(),
            },
        });
    }

    let content = std::fs::read_to_string(path)
        .with_context(|| format!("Cannot read config: {}", path.display()))?;
    toml::from_str(&content)
        .with_context(|| format!("Cannot parse config: {}", path.display()))
}
