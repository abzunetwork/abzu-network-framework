// AbzuNet Client SDK - High-level API for interacting with an AbzuNet gateway
//! Provides upload, retrieval, ANS resolution, and status queries
//! against a local or remote gateway's HTTP API.

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};

pub struct AbzuClient {
    gateway_url: String,
    http: reqwest::Client,
}

#[derive(Debug, Deserialize)]
pub struct UploadResponse {
    pub cid: String,
    pub chunks: usize,
    pub bytes: usize,
}

#[derive(Debug, Deserialize)]
pub struct AnsResponse {
    pub name: String,
    pub cid: String,
}

#[derive(Debug, Deserialize)]
pub struct NodeStatus {
    pub node_id: String,
    pub version: String,
    pub listen_addrs: Vec<String>,
    pub stored_objects: usize,
    pub disk_usage_bytes: u64,
}

impl AbzuClient {
    /// Create a client pointing to a gateway URL (e.g. "http://127.0.0.1:8080")
    pub fn new(gateway_url: &str) -> Self {
        Self {
            gateway_url: gateway_url.trim_end_matches('/').to_string(),
            http: reqwest::Client::new(),
        }
    }

    /// Retrieve content by CID, returning raw bytes
    pub async fn get(&self, cid: &str) -> Result<Vec<u8>> {
        let url = format!("{}/abzu/{}", self.gateway_url, cid);
        let resp = self.http.get(&url).send().await
            .context("GET request failed")?;
        if !resp.status().is_success() {
            return Err(anyhow::anyhow!("Server returned {}: {}", resp.status(), resp.text().await?));
        }
        Ok(resp.bytes().await?.to_vec())
    }

    /// Upload raw bytes, returning the assigned CID
    pub async fn upload(&self, data: &[u8], filename: &str) -> Result<UploadResponse> {
        let part = reqwest::multipart::Part::bytes(data.to_vec()).file_name(filename.to_string());
        let form = reqwest::multipart::Form::new().part("file", part);
        let url = format!("{}/abzu/upload", self.gateway_url);
        let resp = self.http.post(&url).multipart(form).send().await
            .context("Upload request failed")?;
        if !resp.status().is_success() {
            return Err(anyhow::anyhow!("Upload failed {}: {}", resp.status(), resp.text().await?));
        }
        Ok(resp.json::<UploadResponse>().await?)
    }

    /// Resolve an ANS name to a CID
    pub async fn resolve_name(&self, name: &str) -> Result<AnsResponse> {
        let url = format!("{}/abzuname/{}", self.gateway_url, name);
        let resp = self.http.get(&url).send().await?;
        if !resp.status().is_success() {
            return Err(anyhow::anyhow!("Name '{}' not found", name));
        }
        Ok(resp.json::<AnsResponse>().await?)
    }

    /// Register an ANS name pointing to a CID
    pub async fn register_name(&self, name: &str, cid: &str) -> Result<()> {
        let url = format!("{}/abzuname/{}/{}", self.gateway_url, name, cid);
        let resp = self.http.post(&url).send().await?;
        if !resp.status().is_success() {
            return Err(anyhow::anyhow!("Registration failed: {}", resp.text().await?));
        }
        Ok(())
    }

    /// Query node status
    pub async fn status(&self) -> Result<NodeStatus> {
        let url = format!("{}/status", self.gateway_url);
        Ok(self.http.get(&url).send().await?.json::<NodeStatus>().await?)
    }

    /// List all stored CIDs on the node
    pub async fn list(&self) -> Result<Vec<String>> {
        #[derive(Deserialize)]
        struct Entry { cid: String }
        let url = format!("{}/abzu/ls", self.gateway_url);
        let entries: Vec<Entry> = self.http.get(&url).send().await?.json().await?;
        Ok(entries.into_iter().map(|e| e.cid).collect())
    }
}
