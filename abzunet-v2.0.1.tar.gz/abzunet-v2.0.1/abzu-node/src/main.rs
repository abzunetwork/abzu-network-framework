// AbzuNet Node - Main Entry Point
use anyhow::Result;
use tracing_subscriber;

mod identity;
mod network;
mod storage;
mod favor;
mod zkp;
mod dtn;
mod bridge;
mod gateway;
mod config;

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();
    tracing::info!("AbzuNet v2.0.1 starting...");
    Ok(())
}
