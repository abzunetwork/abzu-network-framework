// abzu-node/src/network/mod.rs
//! Network Layer - libp2p Integration and Mesh Transport
//!
//! Implements Phase 1 networking requirements including Kademlia DHT,
//! GossipSub mesh with topic segmentation, and custom transport layer.

pub mod transport;
pub mod kademlia;
pub mod gossipsub;
pub mod behaviour;

pub use transport::{UdpBroadcastTransport, MeshNetworkManager, MeshMessage};
