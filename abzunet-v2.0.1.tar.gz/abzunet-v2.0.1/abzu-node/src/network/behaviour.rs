// Stub: network/behaviour.rs
