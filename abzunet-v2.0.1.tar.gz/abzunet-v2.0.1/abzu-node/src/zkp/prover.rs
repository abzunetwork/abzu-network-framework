// Stub: zkp/prover.rs
