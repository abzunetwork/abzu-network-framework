// abzu-node/src/zkp/mod.rs
//! Zero-Knowledge Proof Generation for Slashing
//! Phase 4: Groth16 + Poseidon Implementation

pub mod poseidon;
pub mod circuit;
pub mod prover;

// Placeholder for arkworks integration
