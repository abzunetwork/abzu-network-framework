// abzu-node/src/favor/mod.rs
//! Autonomous Favor Engine with EWMA Scoring
//! Phase 3: 5-Dimensional Reputation System

use dashmap::DashMap;
use std::sync::Arc;

/// EWMA Parameters: α = 2/121 ≈ 0.0165, 120-sample window
const EWMA_ALPHA: f64 = 2.0 / 121.0;
const MIN_SCORE_THRESHOLD: f64 = 2500.0;

#[derive(Debug, Clone, Copy)]
pub struct FavorScore {
    pub uptime: f64,
    pub latency: f64,
    pub bandwidth: f64,
    pub storage: f64,
    pub geo_diversity: f64,
}

impl FavorScore {
    pub fn total(&self) -> f64 {
        self.uptime + self.latency + self.bandwidth + self.storage + self.geo_diversity
    }
    
    pub fn is_eligible(&self) -> bool {
        self.total() >= MIN_SCORE_THRESHOLD
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HealthState {
    Alive,         // 0-2 missed heartbeats
    Suspect,       // 3-4 missed
    Dying,         // 5-7 missed
    AbsoluteDead,  // 8+ missed
}

impl HealthState {
    pub fn from_missed_beats(count: u32) -> Self {
        match count {
            0..=2 => HealthState::Alive,
            3..=4 => HealthState::Suspect,
            5..=7 => HealthState::Dying,
            _ => HealthState::AbsoluteDead,
        }
    }
}

pub struct FavorEngine {
    scores: Arc<DashMap<[u8; 32], FavorScore>>,
    health: Arc<DashMap<[u8; 32], (HealthState, u32)>>,
}

impl FavorEngine {
    pub fn new() -> Self {
        Self {
            scores: Arc::new(DashMap::new()),
            health: Arc::new(DashMap::new()),
        }
    }
    
    pub fn update_score(&self, node_id: [u8; 32], new_score: FavorScore) {
        self.scores.insert(node_id, new_score);
    }
    
    pub fn record_missed_heartbeat(&self, node_id: [u8; 32]) -> HealthState {
        let mut entry = self.health.entry(node_id).or_insert((HealthState::Alive, 0));
        entry.1 += 1;
        entry.0 = HealthState::from_missed_beats(entry.1);
        entry.0
    }
}
