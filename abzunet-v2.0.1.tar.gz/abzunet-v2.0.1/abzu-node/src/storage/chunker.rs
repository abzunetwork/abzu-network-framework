// Stub: storage/chunker.rs
