// abzu-node/src/dtn/mod.rs
//! Delay-Tolerant Networking with Vector Clocks
//! Phase 6: DTN Mode Implementation

use sled::Db;
use anyhow::Result;
use std::collections::HashMap;

pub struct DtnQueue {
    db: Db,
}

impl DtnQueue {
    pub fn new(path: &str) -> Result<Self> {
        let db = sled::open(path)?;
        Ok(Self { db })
    }
    
    pub fn enqueue(&self, key: Vec<u8>, value: Vec<u8>) -> Result<()> {
        self.db.insert(key, value)?;
        Ok(())
    }
}

#[derive(Debug, Clone)]
pub struct VectorClock {
    pub clocks: HashMap<[u8; 32], u64>,
}

impl VectorClock {
    pub fn new() -> Self {
        Self { clocks: HashMap::new() }
    }
    
    pub fn increment(&mut self, node_id: [u8; 32]) {
        *self.clocks.entry(node_id).or_insert(0) += 1;
    }
}
