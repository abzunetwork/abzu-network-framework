#!/bin/bash
# AbzuNet v2.0.1 Complete Build Script
set -e

echo "=== Building AbzuNet v2.0.1 ==="

# Build Rust workspace
echo "Building Rust workspace..."
cargo build --release --all-features

# Build WASM client
echo "Building WASM client..."
cd abzu-wasm
if command -v wasm-pack &> /dev/null; then
    wasm-pack build --target web --release
else
    echo "⚠ wasm-pack not found, skipping WASM build"
fi
cd ..

# Build contracts (if Foundry is available)
echo "Building smart contracts..."
cd contracts
if command -v forge &> /dev/null; then
    forge build
else
    echo "⚠ Foundry not found, skipping contract build"
fi
cd ..

echo "✓ Build complete!"
echo ""
echo "Binaries location: target/release/abzu-node"
echo "Run with: ./target/release/abzu-node --help"
