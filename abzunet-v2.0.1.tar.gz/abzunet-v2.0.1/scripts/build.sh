#!/bin/bash
# AbzuNet v2.0.1 Build Script
set -e
echo "Building AbzuNet v2.0.1..."
cargo build --release --all-features
echo "Build complete!"
