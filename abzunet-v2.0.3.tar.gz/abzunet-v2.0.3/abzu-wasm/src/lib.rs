// AbzuNet WebAssembly Client
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub struct AbzuWasmClient {
    gateway_url: String,
}

#[wasm_bindgen]
impl AbzuWasmClient {
    #[wasm_bindgen(constructor)]
    pub fn new(gateway_url: String) -> Self {
        Self { gateway_url }
    }
}
