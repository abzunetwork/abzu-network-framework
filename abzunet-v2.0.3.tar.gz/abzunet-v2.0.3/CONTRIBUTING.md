# Contributing to AbzuNet

AbzuNet is open source software developed by SynthicSoft Labs for resilient decentralized infrastructure research.

## Development Process

Pull requests are welcome for bug fixes, performance improvements, and new features that align with the project's architectural goals. Before submitting significant changes, please open an issue to discuss your proposed modifications with the maintainers.

## Code Standards

All Rust code must pass clippy lints and rustfmt formatting checks. Smart contracts require comprehensive test coverage and formal verification where applicable. Documentation should be clear, complete, and include examples for public APIs.

## Testing Requirements

New features require unit tests covering core functionality and integration tests validating interaction with other subsystems. Performance-sensitive code should include benchmarks demonstrating acceptable characteristics under load.

## License

By contributing to AbzuNet, you agree that your contributions will be licensed under the MIT OR Apache-2.0 dual license.
