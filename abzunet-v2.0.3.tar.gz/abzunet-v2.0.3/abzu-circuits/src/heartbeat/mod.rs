// abzu-circuits/src/heartbeat/mod.rs
//! Heartbeat Failure Circuit — arkworks R1CS constraint system
//!
//! Re-exports the constraint synthesizer from abzu-node's zkp module
//! and provides the circuit entry point for standalone circuit compilation,
//! trusted setup, and verifier contract generation.

pub use crate::poseidon::{MDS, ROUND_CONSTANTS_T3, poseidon_permutation_gadget};

/// Circuit metadata for verifier contract generation
pub struct HeartbeatCircuitMeta {
    pub name: &'static str,
    pub version: &'static str,
    pub full_rounds: usize,
    pub partial_rounds: usize,
    pub state_width: usize,
    pub num_public_inputs: usize,
}

pub const CIRCUIT_META: HeartbeatCircuitMeta = HeartbeatCircuitMeta {
    name: "AbzuNet Heartbeat Failure Slashing Circuit",
    version: "2.0.3",
    full_rounds: 8,
    partial_rounds: 57,
    state_width: 3,
    num_public_inputs: 5, // t_chain, H_accused, H_att_1, H_att_2, H_att_3
};
