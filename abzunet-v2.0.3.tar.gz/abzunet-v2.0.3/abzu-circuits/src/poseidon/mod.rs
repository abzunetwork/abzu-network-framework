// abzu-circuits/src/poseidon/mod.rs
//! Poseidon Hash Gadget for BN254 — arkworks R1CS implementation
//!
//! Provides the fully arithmetized Poseidon permutation for use in
//! the heartbeat failure slashing circuit.

use ark_bn254::Fr;
use ark_ff::Field;
use ark_r1cs_std::{fields::fp::FpVar, prelude::*};
use ark_relations::r1cs::{ConstraintSystemRef, SynthesisError};

/// Compute the S-box gadget: y = x^5 (three multiplications: x^2, x^4, x^5)
pub fn sbox_gadget(x: FpVar<Fr>) -> Result<FpVar<Fr>, SynthesisError> {
    let x2 = x.clone() * x.clone();   // x^2
    let x4 = x2.clone() * x2;          // x^4
    Ok(x4 * x)                          // x^5
}

/// Apply the MDS matrix to a state vector in-circuit
pub fn mds_gadget(state: Vec<FpVar<Fr>>, mds: &[[u64; 3]; 3]) -> Result<Vec<FpVar<Fr>>, SynthesisError> {
    let t = state.len();
    let mut result = Vec::with_capacity(t);
    for row in mds.iter() {
        let mut acc: Option<FpVar<Fr>> = None;
        for (j, &coeff) in row.iter().enumerate() {
            let term = state[j].clone() * FpVar::constant(Fr::from(coeff));
            acc = Some(match acc {
                None => term,
                Some(a) => a + term,
            });
        }
        result.push(acc.unwrap());
    }
    Ok(result)
}

/// Full Poseidon permutation gadget for t=3 state
pub fn poseidon_permutation_gadget(
    cs: ConstraintSystemRef<Fr>,
    mut state: Vec<FpVar<Fr>>,
    full_rounds: usize,
    partial_rounds: usize,
    mds: &[[u64; 3]; 3],
    round_constants: &[u64],
) -> Result<Vec<FpVar<Fr>>, SynthesisError> {
    let t = state.len();
    let mut rc_idx = 0;

    let add_round_constants = |state: &mut Vec<FpVar<Fr>>, rc_idx: &mut usize| {
        for s in state.iter_mut() {
            *s = s.clone() + FpVar::constant(Fr::from(round_constants[*rc_idx]));
            *rc_idx += 1;
        }
    };

    // First half of full rounds
    for _ in 0..(full_rounds / 2) {
        add_round_constants(&mut state, &mut rc_idx);
        state = state.into_iter().map(sbox_gadget).collect::<Result<_,_>>()?;
        state = mds_gadget(state, mds)?;
    }

    // Partial rounds: S-box on first element only
    for _ in 0..partial_rounds {
        add_round_constants(&mut state, &mut rc_idx);
        state[0] = sbox_gadget(state[0].clone())?;
        state = mds_gadget(state, mds)?;
    }

    // Second half of full rounds
    for _ in 0..(full_rounds / 2) {
        add_round_constants(&mut state, &mut rc_idx);
        state = state.into_iter().map(sbox_gadget).collect::<Result<_,_>>()?;
        state = mds_gadget(state, mds)?;
    }

    Ok(state)
}

/// Standard MDS matrix for t=3
pub const MDS: [[u64; 3]; 3] = [[7, 23, 1], [1, 7, 23], [23, 1, 7]];

/// Minimal round constants for gadget testing (production uses full Grain LFSR table)
pub const ROUND_CONSTANTS_T3: [u64; 195] = {
    let mut arr = [1u64; 195];
    // Populate with deterministic values; production replaces with BN254 constants
    let mut i = 0usize;
    while i < 195 { arr[i] = (i as u64).wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407); i += 1; }
    arr
};
