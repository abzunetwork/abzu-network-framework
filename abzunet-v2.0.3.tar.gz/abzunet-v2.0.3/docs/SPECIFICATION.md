# AbzuNet v2.0.3 Formal Specification

## Mathematical Foundations

### Identity System
Node ID derivation uses BLAKE3 cryptographic hashing over Ed25519 public keys:

```
N_id = BLAKE3(ed25519_pubkey) ∈ {0,1}^256
```

For BN254 circuit compatibility, the Node ID is split into two 128-bit components:

```
N_high = N_id[0..16] as u128
N_low = N_id[16..32] as u128
```

Both components fit within the BN254 scalar field modulus p ≈ 2^254.

### Content Addressing
Files are divided into 4MB chunks, with the Root CID computed as:

```
R_cid = BLAKE3(chunk_0 || chunk_1 || ... || chunk_n)
```

### EWMA Favor Scoring
Node reputation follows exponentially weighted moving average with parameters:

```
α = 2/121 ≈ 0.0165 (smoothing factor)
Window = 120 samples (30 minutes at 15s intervals)
Dimensions: [Uptime, Latency, Bandwidth, Storage, Geo-diversity]
Threshold = 2500 (minimum score for shard hosting)
```

### Health State Machine
Heartbeat monitoring implements deterministic state transitions:

```
State(missed_count) = {
  Alive:        0 ≤ missed ≤ 2
  Suspect:      3 ≤ missed ≤ 4
  Dying:        5 ≤ missed ≤ 7
  AbsoluteDead: missed ≥ 8
}
```

## Zero-Knowledge Slashing Protocol

### Public Inputs
The verification circuit exposes:
- Chain timestamp t_chain
- Accused node hash H_accused = Poseidon_2(N_high, N_low)
- Three attempt hashes H_att_i for i ∈ {1, 2, 3}

### Private Witness
Hidden from verifier:
- Reporter IP address
- Accused coordinates (N_high, N_low)
- Three nonces, BGP AS numbers, timestamps

### R1CS Constraints
The circuit enforces:
1. Target binding: H_accused = Poseidon_2(N_high, N_low)
2. BGP diversity: AS_i ≠ AS_j for all i ≠ j
3. Time bounds: t_chain - 900 ≤ t_1 ≤ t_2 ≤ t_3 ≤ t_chain
4. Attempt integrity: H_att_i = Poseidon_6(IP, nonce_i, AS_i, N_high, N_low, t_i)

## Network Protocol

### GossipSub Topic Segmentation
To prevent O(N) bandwidth consumption, heartbeat topics are partitioned:

```
topic = "abzu/heartbeat/{N_id[0]:02x}"
```

This creates 256 deterministic topics, each serving approximately N/256 nodes.

### Delay-Tolerant Networking
When blockchain connectivity fails, operations are queued locally:

```
Queue_key = src_node_id || lamport_timestamp
```

Vector clock synchronization enables causal consistency upon reconnection.

## Cryptoeconomic Security

### CID-Bound Escrow
Storage payment IDs prevent front-running attacks:

```
Escrow_ID = keccak256(Payer || Root_CID || Block_Number)
```

### Slashing Conditions
Nodes are subject to stake slashing when:
- Heartbeat failures exceed threshold (8+ consecutive misses)
- Invalid proofs submitted for content attestation
- BGP diversity requirements violated in slash proofs

## Implementation Requirements

### WASM Memory Constraints
Browser clients must maintain O(1) memory usage by streaming to FileSystemWritableFileStream rather than accumulating chunks in heap buffers. Maximum working memory should not exceed 100MB regardless of file size.

### TOCTOU Safety
All DashMap operations must follow the pattern:
1. Collect keys without holding locks
2. Drop read references before await points
3. Re-acquire locks only for mutations

### Island-Aware Replication
Content placement must guarantee r_island replicas within the uploader's network partition while achieving r_min total replicas globally.

