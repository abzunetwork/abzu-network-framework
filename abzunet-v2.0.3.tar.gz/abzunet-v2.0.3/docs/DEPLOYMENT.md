# AbzuNet v2.0.1 Deployment Guide

## Prerequisites

### System Requirements
- Linux, macOS, or Windows (WSL2)
- Rust 1.75+ with wasm32-unknown-unknown target
- 2GB RAM minimum (4GB recommended)
- 10GB disk space for storage
- Open ports: TCP 4001, UDP 4001

### Optional Dependencies
- Foundry (for smart contract deployment)
- Node.js 18+ (for circuit parameter generation)
- wasm-pack (for browser client)

## Installation

### From Source

```bash
# Clone repository
git clone https://github.com/synthicsoft/abzunet-v2.git
cd abzunet-v2

# Build all components
./scripts/build_all.sh

# Initialize node
./scripts/init_node.sh
```

### Binary Release

Download pre-compiled binaries from GitHub releases:
```bash
wget https://github.com/synthicsoft/abzunet-v2/releases/download/v2.0.1/abzu-node-linux-x64.tar.gz
tar xzf abzu-node-linux-x64.tar.gz
./abzu-node init
```

## Configuration

Edit `~/.abzu/abzu.toml`:

```toml
[identity]
keyfile = "~/.abzu/identity.key"

[network]
listen_addrs = ["/ip4/0.0.0.0/tcp/4001"]
bootstrap_peers = [
    "/ip4/1.2.3.4/tcp/4001/p2p/12D3KooW..."
]
enable_mdns = true
enable_udp_broadcast = true

[storage]
data_dir = "~/.abzu/storage"
max_storage_gb = 100
island_tag = "production"

[blockchain]
arbitrum_rpc = "https://arb1.arbitrum.io/rpc"
registry_address = "0x..."
escrow_address = "0x..."
paymaster_address = "0x..."

[gateway]
enabled = true
bind_addr = "127.0.0.1:8080"
```

## Running a Node

### Start Node
```bash
abzu-node start --config ~/.abzu/abzu.toml
```

### Run as System Service (Linux)

```bash
sudo tee /etc/systemd/system/abzu-node.service << EOF
[Unit]
Description=AbzuNet Node
After=network.target

[Service]
Type=simple
User=abzu
ExecStart=/usr/local/bin/abzu-node start --config /home/abzu/.abzu/abzu.toml
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
