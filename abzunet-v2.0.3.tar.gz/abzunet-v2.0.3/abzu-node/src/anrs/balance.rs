// abzu-node/src/anrs/balance.rs
//! Local ABZU Balance Tracker
//!
//! Tracks the node's ABZU token balance locally (estimated, pending on-chain
//! confirmation) and manages withdrawal requests to the Arbitrum bridge.
//!
//! The node's Arbitrum address is derived deterministically from the Ed25519
//! public key — no wallet setup required:
//!
//!   arbitrum_address = keccak256(ed25519_pubkey)[12..]  // last 20 bytes

use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::Mutex;
use tracing::info;

// ─── Balance State ────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BalanceState {
    /// Pending balance (estimated, not yet confirmed on-chain)
    pub pending:    u64,
    /// Confirmed on-chain balance (last synced from Arbitrum)
    pub confirmed:  u64,
    /// Total lifetime earnings
    pub total_earned: u64,
    /// Total withdrawn
    pub total_withdrawn: u64,
    /// Last on-chain sync timestamp
    pub last_sync:  u64,
    /// Node's derived Arbitrum address (hex)
    pub address:    String,
}

impl Default for BalanceState {
    fn default() -> Self {
        Self {
            pending:         0,
            confirmed:       0,
            total_earned:    0,
            total_withdrawn: 0,
            last_sync:       0,
            address:         String::new(),
        }
    }
}

impl BalanceState {
    /// Total available (pending + confirmed)
    pub fn total_available(&self) -> u64 {
        self.pending + self.confirmed
    }

    /// Display balance in ABZU (8 decimal places)
    pub fn display(&self) -> String {
        format!(
            "{:.8} ABZU (pending: {:.8}, confirmed: {:.8})",
            self.total_available() as f64 / 1e8,
            self.pending as f64 / 1e8,
            self.confirmed as f64 / 1e8,
        )
    }
}

// ─── Balance Tracker ─────────────────────────────────────────────────────────

pub struct BalanceTracker {
    state:     Arc<Mutex<BalanceState>>,
    store:     sled::Db,
    threshold: u64, // Auto-withdraw threshold in ABZU (8 decimals)
}

impl BalanceTracker {
    pub fn new(
        store: sled::Db,
        node_pubkey: &[u8; 32],
        withdraw_threshold: u64,
    ) -> Result<Arc<Self>> {
        let address = derive_arbitrum_address(node_pubkey);

        // Load persisted state or initialize
        let state = if let Ok(Some(bytes)) = store.get(b"anrs/balance") {
            serde_json::from_slice::<BalanceState>(&bytes)
                .unwrap_or_default()
        } else {
            BalanceState {
                address: address.clone(),
                ..Default::default()
            }
        };

        info!("ANRS wallet address: {}", address);
        info!("Current balance: {}", state.display());

        Ok(Arc::new(Self {
            state: Arc::new(Mutex::new(state)),
            store,
            threshold: withdraw_threshold,
        }))
    }

    /// Add earned ABZU from completed epoch
    pub async fn add(&self, amount: u64) {
        let mut state = self.state.lock().await;
        state.pending += amount;
        state.total_earned += amount;
        self.persist(&state).ok();
    }

    /// Get current balance snapshot
    pub async fn snapshot(&self) -> BalanceState {
        self.state.lock().await.clone()
    }

    /// Sync confirmed balance from Arbitrum (production: call contract)
    pub async fn sync_chain_balance(&self, node_id: &[u8; 32]) -> Result<()> {
        // Production: call AbzuNodeRewards.balances(node_id) on Arbitrum
        // Update state.confirmed with on-chain value
        info!("Syncing on-chain balance for node {}", hex::encode(node_id));
        Ok(())
    }

    /// Request withdrawal of all pending ABZU to an Ethereum address
    pub async fn withdraw(&self, to_address: Option<String>) -> Result<WithdrawalRequest> {
        let mut state = self.state.lock().await;

        if state.total_available() == 0 {
            return Err(anyhow::anyhow!("No ABZU balance to withdraw"));
        }

        let recipient = to_address.unwrap_or_else(|| state.address.clone());
        let amount = state.total_available();

        let request = WithdrawalRequest {
            recipient:   recipient.clone(),
            amount,
            timestamp:   std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
        };

        // Production: submit to AbzuNodeRewards.withdraw() on Arbitrum
        // with Ed25519 signature authorizing the transfer

        info!(
            "Withdrawal requested: {:.8} ABZU → {}",
            amount as f64 / 1e8,
            recipient
        );

        state.total_withdrawn += amount;
        state.pending = 0;
        state.confirmed = 0;
        self.persist(&state).ok();

        Ok(request)
    }

    fn persist(&self, state: &BalanceState) -> Result<()> {
        let bytes = serde_json::to_vec(state)?;
        self.store.insert(b"anrs/balance", bytes)?;
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WithdrawalRequest {
    pub recipient:  String,
    pub amount:     u64,
    pub timestamp:  u64,
}

// ─── Address Derivation ───────────────────────────────────────────────────────

/// Derive Ethereum-compatible Arbitrum address from Ed25519 public key.
///
/// address = keccak256(pubkey)[12..32] formatted as 0x-prefixed hex
///
/// This gives every node a deterministic, non-custodial wallet address
/// derived directly from their identity keypair. No separate wallet setup
/// needed — the node IS the wallet.
pub fn derive_arbitrum_address(pubkey: &[u8; 32]) -> String {
    use sha3::{Digest, Keccak256};

    let hash = Keccak256::digest(pubkey);
    let address_bytes = &hash[12..32]; // Last 20 bytes = Ethereum address
    format!("0x{}", hex::encode(address_bytes))
}

// ─── Registration Payload ─────────────────────────────────────────────────────

/// Data submitted to AbzuNodeRegistry on first startup
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeRegistrationPayload {
    pub node_id:        [u8; 32],
    pub pubkey:         [u8; 32],
    pub storage_pledge: u64,   // GB
    pub lora_enabled:   bool,
    pub address:        String,
    pub signature:      Vec<u8>, // Ed25519 signature over (node_id || storage_pledge)
}
