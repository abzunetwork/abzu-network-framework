// abzu-node/src/anrs/challenge.rs
//! Storage Challenge-Response System
//!
//! Proves a node is actually holding content it claims to store.
//! Inspired by Filecoin's Proof of Data Possession (PDP), implemented
//! using AbzuNet's existing BLAKE3 infrastructure.
//!
//! Challenge Protocol:
//!   1. Every epoch, the network (or local self-check) selects N random CIDs
//!      from the DHT that this node has announced as a provider
//!   2. For each CID, the challenger requests a random chunk and its BLAKE3 hash
//!   3. The node responds with the chunk bytes
//!   4. Challenger verifies: BLAKE3(chunk_bytes) == expected_hash
//!   5. Score = challenges_passed / challenges_total
//!
//! Self-verification runs locally — the node challenges itself to prove
//! storage integrity before reporting to the ANRS epoch manager.

use anyhow::Result;
use blake3::Hasher;
use rand::Rng;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tracing::{debug, info, warn};

use crate::storage::store::ContentStore;
use crate::network::SwarmHandle;

const CHALLENGES_PER_EPOCH: usize = 10;
const CHALLENGE_TIMEOUT_SECS: u64 = 30;

// ─── Challenge Types ──────────────────────────────────────────────────────────

/// A storage challenge issued to a node
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageChallenge {
    /// The content root CID being challenged
    pub root_cid:   [u8; 32],
    /// Which chunk index to prove (random)
    pub chunk_idx:  u32,
    /// Random nonce to prevent pre-computation
    pub nonce:      [u8; 16],
    /// Unix timestamp — challenge expires after 30 seconds
    pub issued_at:  u64,
}

/// A node's response to a storage challenge
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChallengeResponse {
    pub root_cid:    [u8; 32],
    pub chunk_idx:   u32,
    pub nonce:       [u8; 16],
    /// BLAKE3(chunk_bytes || nonce) — proves possession without sending full chunk
    pub proof_hash:  [u8; 32],
    /// Chunk size in bytes (for verification)
    pub chunk_size:  u32,
}

impl ChallengeResponse {
    /// Verify this response against the expected chunk hash
    pub fn verify(&self, expected_chunk_hash: [u8; 32]) -> bool {
        // Reconstruct what the prover should have computed:
        // BLAKE3(expected_chunk_hash || nonce)
        let mut hasher = Hasher::new();
        hasher.update(&expected_chunk_hash);
        hasher.update(&self.nonce);
        let expected_proof = *hasher.finalize().as_bytes();
        expected_proof == self.proof_hash
    }
}

// ─── Challenge Engine ─────────────────────────────────────────────────────────

/// Runs storage challenge-response for this node.
/// Challenges are self-issued — the node proves storage to itself,
/// then reports the score to the ANRS epoch manager.
pub struct ChallengeEngine {
    store: Arc<ContentStore>,
}

impl ChallengeEngine {
    pub fn new(store: Arc<ContentStore>) -> Self {
        Self { store }
    }

    /// Run N storage challenges against the local store.
    /// Returns (passed, total) counts.
    pub async fn run_epoch_challenges(&self) -> (u64, u64) {
        // Get list of all locally stored root CIDs
        let stored_cids = match self.store.list_root_cids() {
            Ok(cids) => cids,
            Err(e) => {
                warn!("Failed to list stored CIDs for challenge: {}", e);
                return (0, 0);
            }
        };

        if stored_cids.is_empty() {
            debug!("No stored CIDs — skipping storage challenge");
            return (0, 0);
        }

        let mut rng = rand::thread_rng();
        let n = CHALLENGES_PER_EPOCH.min(stored_cids.len());
        let mut passed = 0u64;
        let mut total = 0u64;

        // Sample N random CIDs from local store
        let sample_indices: Vec<usize> = (0..n)
            .map(|_| rng.gen_range(0..stored_cids.len()))
            .collect();

        for idx in sample_indices {
            let root_cid = stored_cids[idx];

            // Get manifest to know how many chunks exist
            match self.store.get_manifest(&root_cid) {
                Ok(Some(manifest)) => {
                    if manifest.chunk_hashes.is_empty() {
                        continue;
                    }

                    // Pick a random chunk
                    let chunk_idx = rng.gen_range(0..manifest.chunk_hashes.len()) as u32;
                    let chunk_cid = manifest.chunk_hashes[chunk_idx as usize];

                    // Generate challenge nonce
                    let mut nonce = [0u8; 16];
                    rng.fill(&mut nonce);

                    total += 1;

                    // Attempt to retrieve and hash the chunk
                    match self.prove_chunk(chunk_cid, nonce) {
                        Ok(proof_hash) => {
                            // Self-verify: recompute expected proof hash
                            let mut hasher = Hasher::new();
                            hasher.update(&chunk_cid);
                            hasher.update(&nonce);
                            let expected = *hasher.finalize().as_bytes();

                            if proof_hash == expected {
                                passed += 1;
                                debug!("Challenge passed for CID {}", hex::encode(root_cid));
                            } else {
                                warn!("Challenge FAILED for CID {} — data corruption?", hex::encode(root_cid));
                            }
                        }
                        Err(e) => {
                            warn!("Challenge error for CID {}: {}", hex::encode(root_cid), e);
                        }
                    }
                }
                Ok(None) => {
                    warn!("No manifest for CID {}", hex::encode(root_cid));
                }
                Err(e) => {
                    warn!("Manifest error: {}", e);
                }
            }
        }

        info!(
            "Storage challenge complete: {}/{} passed ({:.0}%)",
            passed, total,
            if total > 0 { passed as f64 / total as f64 * 100.0 } else { 0.0 }
        );

        (passed, total)
    }

    /// Compute proof hash for a chunk: BLAKE3(chunk_cid || nonce)
    fn prove_chunk(&self, chunk_cid: [u8; 32], nonce: [u8; 16]) -> Result<[u8; 32]> {
        // Retrieve chunk from local store
        let chunk = self.store.get_chunk(&chunk_cid)?
            .ok_or_else(|| anyhow::anyhow!("Chunk not found: {}", hex::encode(chunk_cid)))?;

        // Verify chunk integrity first (BLAKE3 of data should match chunk_cid)
        let chunk_hash = *blake3::hash(&chunk.data).as_bytes();
        if chunk_hash != chunk_cid {
            return Err(anyhow::anyhow!("Chunk data corrupt: hash mismatch"));
        }

        // Compute proof: BLAKE3(chunk_cid || nonce)
        let mut hasher = Hasher::new();
        hasher.update(&chunk_cid);
        hasher.update(&nonce);
        Ok(*hasher.finalize().as_bytes())
    }

    /// Compute what fraction of storage pledged is actually verified
    pub async fn verified_storage_gb(&self, pledge_gb: u64) -> u64 {
        let stored_bytes = self.store.size_on_disk().unwrap_or(0);
        let stored_gb = stored_bytes / (1024 * 1024 * 1024);
        stored_gb.min(pledge_gb)
    }
}
