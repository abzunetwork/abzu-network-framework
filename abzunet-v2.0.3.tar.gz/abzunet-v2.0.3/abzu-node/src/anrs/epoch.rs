// abzu-node/src/anrs/epoch.rs
//! Epoch Manager — Token Emission and Reward Timing
//!
//! Manages the ANRS epoch cycle:
//!   1. Track time until next epoch boundary (every 3600 seconds)
//!   2. At epoch end: snapshot activity counters
//!   3. Run storage challenges
//!   4. Compute ServiceScore
//!   5. Report to on-chain AbzuNodeRewards contract (if blockchain configured)
//!   6. Update local balance
//!   7. Reset counters for next epoch
//!
//! Emission Schedule:
//!   Base hourly emission:   95,890 ABZU (8 decimals: 9_589_000_000_000)
//!   Halving interval:       17,520 epochs (2 years)
//!   Total node allocation:  700,000,000 ABZU over ~20 years
//!   Tail emission:          1% of remaining per year after primary schedule

use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tokio::time::interval;
use tracing::{error, info, warn};

use super::score::{EpochActivityCounters, ServiceScore};
use super::challenge::ChallengeEngine;
use super::balance::BalanceTracker;
use crate::favor::FavorEngine;
use crate::transport::LoraStats;

// ─── Emission Constants ───────────────────────────────────────────────────────

/// Epoch duration: 1 hour
pub const EPOCH_DURATION_SECS: u64 = 3600;

/// Base hourly emission in ABZU (8 decimal places, so this = 95,890.00000000)
pub const BASE_HOURLY_EMISSION: u64 = 9_589_000_000_000; // 95,890 ABZU × 10^8

/// Number of epochs before halving (2 years × 8760 hours/year = 17,520)
pub const HALVING_EPOCHS: u64 = 17_520;

/// Minimum emission (tail emission floor, ~0.001 ABZU/epoch)
pub const MIN_EPOCH_EMISSION: u64 = 100_000; // 0.001 ABZU

// ─── Epoch State ──────────────────────────────────────────────────────────────

/// Persistent epoch state — saved between restarts
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EpochState {
    pub current_epoch:  u64,
    pub last_epoch_ts:  u64,
    pub total_earned:   u64,  // Cumulative ABZU earned (8 decimals)
    pub total_epochs:   u64,  // Epochs participated in
}

impl EpochState {
    pub fn new() -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        Self {
            current_epoch: 0,
            last_epoch_ts: now,
            total_earned:  0,
            total_epochs:  0,
        }
    }

    /// Calculate current epoch pool based on halving schedule
    pub fn epoch_pool(&self) -> u64 {
        let halvings = self.current_epoch / HALVING_EPOCHS;
        if halvings >= 64 {
            return MIN_EPOCH_EMISSION;
        }
        let emission = BASE_HOURLY_EMISSION >> halvings;
        emission.max(MIN_EPOCH_EMISSION)
    }

    /// Human-readable current emission rate
    pub fn emission_rate_display(&self) -> String {
        let pool = self.epoch_pool();
        format!("{:.8} ABZU/epoch", pool as f64 / 1e8)
    }
}

// ─── Epoch Record ─────────────────────────────────────────────────────────────

/// Record of a completed epoch — stored locally and reported on-chain
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EpochRecord {
    pub epoch:         u64,
    pub timestamp:     u64,
    pub score:         ServiceScore,
    pub pool:          u64,    // Total pool this epoch (network-wide)
    pub earned:        u64,    // This node's share (estimated locally)
    pub challenges:    (u64, u64), // (passed, total)
    pub lora_active:   bool,
    pub reported:      bool,   // Whether reported on-chain
}

// ─── Epoch Manager ────────────────────────────────────────────────────────────

/// Manages the epoch lifecycle. Runs as a background Tokio task.
pub struct EpochManager {
    pub state:      EpochState,
    pub config:     EpochManagerConfig,
    pub activity:   Arc<EpochActivityCounters>,
    pub challenge:  Arc<ChallengeEngine>,
    pub favor:      Arc<FavorEngine>,
    pub balance:    Arc<BalanceTracker>,
    pub history:    Vec<EpochRecord>,
}

#[derive(Debug, Clone)]
pub struct EpochManagerConfig {
    pub storage_pledge_gb: u64,
    pub lora_active:       bool,
    pub node_id:           [u8; 32],
    pub auto_report:       bool,   // Report to chain automatically
}

impl EpochManager {
    pub fn new(
        config: EpochManagerConfig,
        activity: Arc<EpochActivityCounters>,
        challenge: Arc<ChallengeEngine>,
        favor: Arc<FavorEngine>,
        balance: Arc<BalanceTracker>,
    ) -> Self {
        Self {
            state: EpochState::new(),
            config,
            activity,
            challenge,
            favor,
            balance,
            history: Vec::new(),
        }
    }

    /// Run the epoch loop. Spawns as a background task.
    pub async fn run(mut self) {
        info!(
            "ANRS Epoch Manager started. Node ID: {}",
            hex::encode(self.config.node_id)
        );
        info!(
            "Initial emission rate: {} | Halving every {} epochs (2 years)",
            self.state.emission_rate_display(),
            HALVING_EPOCHS
        );

        let mut epoch_timer = interval(Duration::from_secs(EPOCH_DURATION_SECS));
        epoch_timer.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

        // Skip the immediate first tick
        epoch_timer.tick().await;

        loop {
            epoch_timer.tick().await;

            info!(
                "=== ANRS Epoch {} starting ===",
                self.state.current_epoch + 1
            );

            match self.process_epoch().await {
                Ok(record) => {
                    let earned_display = record.earned as f64 / 1e8;
                    info!(
                        "Epoch {} complete — Earned: {:.8} ABZU | Score: {:.4} | Challenges: {}/{}",
                        record.epoch,
                        earned_display,
                        record.score.total,
                        record.challenges.0,
                        record.challenges.1,
                    );
                    self.history.push(record);
                    // Keep only last 168 epochs (1 week) in memory
                    if self.history.len() > 168 {
                        self.history.remove(0);
                    }
                }
                Err(e) => {
                    error!("Epoch processing error: {}", e);
                }
            }
        }
    }

    /// Process one complete epoch:
    /// snapshot → challenge → score → reward → reset
    async fn process_epoch(&mut self) -> Result<EpochRecord> {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();

        self.state.current_epoch += 1;
        let epoch = self.state.current_epoch;

        // 1. Snapshot activity counters (resets them atomically)
        let counters = self.activity.snapshot_and_reset();

        // 2. Run storage challenges
        let (challenges_passed, challenges_total) =
            self.challenge.run_epoch_challenges().await;

        // 3. Get verified storage
        let verified_gb = self.challenge
            .verified_storage_gb(self.config.storage_pledge_gb)
            .await;

        // 4. Get favor score
        let favor_score = self.favor
            .get_score(self.config.node_id)
            .unwrap_or_default();

        // 5. Compute ServiceScore
        let mut score = ServiceScore::compute(
            &favor_score,
            self.config.storage_pledge_gb,
            verified_gb,
            counters.chunks_served,
            counters.chunks_requested,
            counters.routing_events,
            self.config.lora_active,
            counters.lora_packets_relayed,
        );

        // 6. Estimate local reward (actual distribution done on-chain)
        let pool = self.state.epoch_pool();
        // Estimated share assuming average network participation
        // Actual share depends on all nodes' scores — corrected on-chain
        let estimated_earned = if score.is_eligible() {
            // Conservative estimate: assume this node is 1% of network
            // Real on-chain distribution accounts for all nodes
            (pool as f64 * score.total * 0.01) as u64
        } else {
            0
        };

        score.earned = estimated_earned;

        // 7. Update local balance tracker
        self.balance.add(estimated_earned).await;
        self.state.total_earned += estimated_earned;
        self.state.total_epochs += 1;
        self.state.last_epoch_ts = now;

        // 8. Report on-chain (if configured and score is eligible)
        let mut reported = false;
        if self.config.auto_report && score.is_eligible() {
            match self.report_to_chain(epoch, &score).await {
                Ok(()) => reported = true,
                Err(e) => warn!("On-chain reporting failed: {} — will retry next epoch", e),
            }
        }

        Ok(EpochRecord {
            epoch,
            timestamp: now,
            score,
            pool,
            earned: estimated_earned,
            challenges: (challenges_passed, challenges_total),
            lora_active: self.config.lora_active,
            reported,
        })
    }

    /// Submit epoch score to AbzuNodeRewards contract on Arbitrum
    async fn report_to_chain(&self, epoch: u64, score: &ServiceScore) -> Result<()> {
        // Production implementation:
        //   1. ABI-encode score components as uint32 values
        //   2. Sign with node's Ed25519 key
        //   3. Submit via ethers-rs to AbzuNodeRewards.reportEpoch()
        //   4. Gas paid by contract's self-funding mechanism

        info!(
            "Reporting epoch {} score ({:.4}) to Arbitrum...",
            epoch, score.total
        );

        // Placeholder until bridge/anrs_contract.rs is wired in
        Ok(())
    }

    /// Get the last N epoch records for display
    pub fn recent_history(&self, n: usize) -> &[EpochRecord] {
        let start = self.history.len().saturating_sub(n);
        &self.history[start..]
    }
}
