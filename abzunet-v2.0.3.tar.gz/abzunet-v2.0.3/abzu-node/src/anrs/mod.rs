// abzu-node/src/anrs/mod.rs
//! Autonomous Node Reward System (ANRS)
//!
//! The ANRS pays every node operator automatically for their contribution
//! to the AbzuNet network. No mining rigs, no manual claiming, no company
//! in the middle. Just run a node and earn ABZU proportional to your
//! uptime, storage, serving, routing, and LoRa mesh participation.
//!
//! Module structure:
//!   score.rs    — ServiceScore calculation from activity counters
//!   challenge.rs — Storage challenge-response (proof of possession)
//!   epoch.rs    — Epoch timing, reward emission, on-chain reporting
//!   balance.rs  — Local balance tracking and withdrawal management
//!
//! Token: ABZU
//!   Total supply:     1,000,000,000 (fixed)
//!   Node allocation:  700,000,000 (70%)
//!   Emission:         Halving every 2 years, ~20 year primary schedule
//!   Chain:            Arbitrum (low gas, fast finality)
//!   Address:          Derived from Ed25519 pubkey — no wallet setup needed

pub mod balance;
pub mod challenge;
pub mod epoch;
pub mod score;

pub use balance::{BalanceTracker, BalanceState, WithdrawalRequest, derive_arbitrum_address};
pub use challenge::ChallengeEngine;
pub use epoch::{EpochManager, EpochManagerConfig, EpochState, EpochRecord};
pub use score::{ServiceScore, EpochActivityCounters, CounterSnapshot};

use anyhow::Result;
use std::sync::Arc;
use tracing::info;

use crate::favor::FavorEngine;
use crate::storage::store::ContentStore;
use crate::config::AnrsConfig;

/// ANRS system handle — shared across gateway and swarm
#[derive(Clone)]
pub struct AnrsHandle {
    pub activity: Arc<EpochActivityCounters>,
    pub balance:  Arc<BalanceTracker>,
}

impl AnrsHandle {
    /// Initialize the full ANRS subsystem
    pub async fn init(
        config: &AnrsConfig,
        node_id: [u8; 32],
        node_pubkey: &[u8; 32],
        store: Arc<ContentStore>,
        favor: Arc<FavorEngine>,
        sled_db: sled::Db,
        lora_active: bool,
    ) -> Result<Self> {
        info!("Initializing Autonomous Node Reward System (ANRS)");
        info!("Storage pledge: {} GB", config.storage_pledge_gb);
        info!("LoRa bonus: {}", if lora_active { "enabled" } else { "disabled" });

        // Shared activity counters (incremented by gateway and swarm)
        let activity = EpochActivityCounters::new();

        // Balance tracker (persisted to sled)
        let balance = BalanceTracker::new(
            sled_db.clone(),
            node_pubkey,
            config.withdraw_threshold,
        )?;

        // Challenge engine (proves storage integrity each epoch)
        let challenge = Arc::new(ChallengeEngine::new(store));

        // Epoch manager (background task)
        let epoch_config = EpochManagerConfig {
            storage_pledge_gb: config.storage_pledge_gb,
            lora_active,
            node_id,
            auto_report: config.enabled && !config.arbitrum_rpc.is_empty(),
        };

        let manager = EpochManager::new(
            epoch_config,
            activity.clone(),
            challenge,
            favor,
            balance.clone(),
        );

        // Spawn epoch loop as background task
        tokio::spawn(async move {
            manager.run().await;
        });

        info!("ANRS initialized. Wallet: {}", derive_arbitrum_address(node_pubkey));

        Ok(AnrsHandle { activity, balance })
    }
}
