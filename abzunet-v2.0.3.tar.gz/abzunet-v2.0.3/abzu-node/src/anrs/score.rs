// abzu-node/src/anrs/score.rs
//! Service Score Calculation — ANRS Core
//!
//! Computes each node's ServiceScore from the five dimensions of useful work.
//! The score is calculated every epoch (1 hour) and determines the node's
//! proportional share of that epoch's ABZU token reward pool.
//!
//! Score formula:
//!   ServiceScore = w_uptime   × UptimeScore    (0.20)
//!                + w_storage  × StorageScore   (0.30)
//!                + w_serving  × ServingScore   (0.25)
//!                + w_routing  × RoutingScore   (0.15)
//!                + w_lora     × LoraScore      (0.10)
//!
//! All component scores are normalized to [0.0, 1.0].
//! The LoRa bonus weight incentivizes deployment of radio mesh nodes.

use serde::{Deserialize, Serialize};
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, Ordering};
use crate::favor::{FavorEngine, FavorScore};

// ─── Weight Constants ─────────────────────────────────────────────────────────

pub const W_UPTIME:  f64 = 0.20;
pub const W_STORAGE: f64 = 0.30;
pub const W_SERVING: f64 = 0.25;
pub const W_ROUTING: f64 = 0.15;
pub const W_LORA:    f64 = 0.10;

/// Favor score normalization ceiling (5000 = fully eligible node)
const FAVOR_CEILING: f64 = 5000.0;

/// Target for routing activity per epoch (DHT queries + DTN relays)
const ROUTING_TARGET: u64 = 500;

/// Target for LoRa relayed packets per epoch (for full LoRa score)
const LORA_RELAY_TARGET: u64 = 100;

// ─── Score Components ─────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServiceScore {
    /// Normalized uptime component [0.0, 1.0]
    pub uptime:   f64,
    /// Normalized storage component [0.0, 1.0]
    pub storage:  f64,
    /// Normalized serving component [0.0, 1.0]
    pub serving:  f64,
    /// Normalized routing component [0.0, 1.0]
    pub routing:  f64,
    /// Normalized LoRa component [0.0, 1.0] (0.0 if no LoRa hardware)
    pub lora:     f64,
    /// Weighted total [0.0, 1.0]
    pub total:    f64,
    /// Raw ABZU earned this epoch (filled in by epoch.rs)
    pub earned:   u64,
}

impl ServiceScore {
    pub fn compute(
        favor: &FavorScore,
        storage_pledge_gb:    u64,
        storage_verified_gb:  u64,
        chunks_served:        u64,
        chunks_requested:     u64,
        routing_events:       u64,
        lora_active:          bool,
        lora_packets_relayed: u64,
    ) -> Self {
        let uptime = (favor.total() / FAVOR_CEILING).clamp(0.0, 1.0);

        let storage = if storage_pledge_gb == 0 {
            0.0
        } else {
            (storage_verified_gb as f64 / storage_pledge_gb as f64).clamp(0.0, 1.0)
        };

        let serving = if chunks_requested == 0 {
            // No requests this epoch — give neutral score, not zero
            // (node may be idle but available)
            0.5
        } else {
            (chunks_served as f64 / (chunks_requested + 1) as f64).clamp(0.0, 1.0)
        };

        let routing = (routing_events as f64 / ROUTING_TARGET as f64).clamp(0.0, 1.0);

        let lora = if lora_active {
            let relay_score = (lora_packets_relayed as f64 / LORA_RELAY_TARGET as f64).clamp(0.0, 1.0);
            // Base LoRa score of 0.5 just for having hardware; rest from relay activity
            0.5 + relay_score * 0.5
        } else {
            0.0
        };

        let total = (W_UPTIME  * uptime)
                  + (W_STORAGE * storage)
                  + (W_SERVING * serving)
                  + (W_ROUTING * routing)
                  + (W_LORA   * lora);

        Self {
            uptime,
            storage,
            serving,
            routing,
            lora,
            total: total.clamp(0.0, 1.0),
            earned: 0,
        }
    }

    pub fn is_eligible(&self) -> bool {
        // Must have non-trivial contribution to earn rewards
        self.total > 0.05
    }
}

// ─── Epoch Activity Counter ───────────────────────────────────────────────────

/// Atomic counters tracking this node's activity within the current epoch.
/// Reset at the start of each epoch by EpochManager.
pub struct EpochActivityCounters {
    pub chunks_served:        AtomicU64,
    pub chunks_requested:     AtomicU64,
    pub dht_queries_answered: AtomicU64,
    pub dtn_messages_relayed: AtomicU64,
    pub storage_challenges_passed: AtomicU64,
    pub storage_challenges_total:  AtomicU64,
    pub lora_packets_relayed: AtomicU64,
}

impl EpochActivityCounters {
    pub fn new() -> Arc<Self> {
        Arc::new(Self {
            chunks_served:             AtomicU64::new(0),
            chunks_requested:          AtomicU64::new(0),
            dht_queries_answered:      AtomicU64::new(0),
            dtn_messages_relayed:      AtomicU64::new(0),
            storage_challenges_passed: AtomicU64::new(0),
            storage_challenges_total:  AtomicU64::new(0),
            lora_packets_relayed:      AtomicU64::new(0),
        })
    }

    pub fn record_chunk_served(&self) {
        self.chunks_served.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_chunk_requested(&self) {
        self.chunks_requested.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_dht_query(&self) {
        self.dht_queries_answered.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_dtn_relay(&self) {
        self.dtn_messages_relayed.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_lora_relay(&self) {
        self.lora_packets_relayed.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_challenge(&self, passed: bool) {
        self.storage_challenges_total.fetch_add(1, Ordering::Relaxed);
        if passed {
            self.storage_challenges_passed.fetch_add(1, Ordering::Relaxed);
        }
    }

    pub fn routing_events(&self) -> u64 {
        self.dht_queries_answered.load(Ordering::Relaxed)
            + self.dtn_messages_relayed.load(Ordering::Relaxed)
    }

    /// Snapshot all counters and reset to zero atomically
    pub fn snapshot_and_reset(&self) -> CounterSnapshot {
        CounterSnapshot {
            chunks_served:             self.chunks_served.swap(0, Ordering::AcqRel),
            chunks_requested:          self.chunks_requested.swap(0, Ordering::AcqRel),
            routing_events:            self.routing_events(),
            storage_challenges_passed: self.storage_challenges_passed.swap(0, Ordering::AcqRel),
            storage_challenges_total:  self.storage_challenges_total.swap(0, Ordering::AcqRel),
            lora_packets_relayed:      self.lora_packets_relayed.swap(0, Ordering::AcqRel),
        }
    }
}

#[derive(Debug, Clone)]
pub struct CounterSnapshot {
    pub chunks_served:             u64,
    pub chunks_requested:          u64,
    pub routing_events:            u64,
    pub storage_challenges_passed: u64,
    pub storage_challenges_total:  u64,
    pub lora_packets_relayed:      u64,
}
