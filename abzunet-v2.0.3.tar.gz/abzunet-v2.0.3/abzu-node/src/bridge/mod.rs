// abzu-node/src/bridge/mod.rs
//! Blockchain Bridge — EIP-4337 Account Abstraction + Arbitrum Settlement
//!
//! Implements Phase 5: all on-chain operations for storage escrow and slashing.
//!
//! Flows implemented:
//!   1. deposit_escrow:    Lock ABZU tokens for a storage request
//!   2. release_escrow:    Release payment to storage node after fulfillment
//!   3. refund_escrow:     Refund payer if storage node fails (after timeout)
//!   4. submit_slash:      Submit a verified ZK proof to slash a misbehaving node
//!   5. check_collateral:  Query a node's staked collateral from the registry
//!
//! The bridge is optional — all AbzuNet features work without a blockchain
//! connection. When unavailable, operations are queued in the DTN layer
//! and submitted when connectivity is restored.

use anyhow::{Context, Result};
use ethers::{
    contract::abigen,
    middleware::SignerMiddleware,
    providers::{Http, Middleware, Provider},
    signers::{LocalWallet, Signer},
    types::{Address, Bytes, H256, U256},
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tracing::{info, warn, error};

use crate::zkp::prover::SerializedProof;

// ABI definitions for the on-chain contracts.
// In production these would be generated from the compiled Solidity ABIs via abigen!()
// macro. We define the key function signatures here as a compatible interface.

/// Escrow state as returned by the contract
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum EscrowState {
    Pending,
    Released,
    Refunded,
}

/// Snapshot of an on-chain escrow record
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EscrowRecord {
    pub escrow_id: [u8; 32],
    pub payer: String,
    pub root_cid: [u8; 32],
    pub amount: u128,
    pub required_replicas: u8,
    pub deadline: u64,
    pub state: EscrowState,
}

/// Connection configuration for the blockchain bridge
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BridgeConfig {
    pub arbitrum_rpc: String,
    pub registry_address: String,
    pub escrow_address: String,
    pub paymaster_address: String,
    /// Private key for signing transactions (hex, no 0x prefix)
    /// In production this would use EIP-4337 UserOperations via the paymaster.
    pub signer_key: Option<String>,
}

/// The blockchain bridge — handles all interactions with Arbitrum
pub struct ContractBridge {
    config: BridgeConfig,
    registry_address: Address,
    escrow_address: Address,
    /// Provider is Some when connected, None when operating offline
    provider: Option<Arc<Provider<Http>>>,
}

impl ContractBridge {
    /// Create a bridge from configuration. Attempts to connect immediately.
    pub async fn new(config: BridgeConfig) -> Self {
        let registry_address = config.registry_address.parse().unwrap_or(Address::zero());
        let escrow_address = config.escrow_address.parse().unwrap_or(Address::zero());

        let provider = if !config.arbitrum_rpc.is_empty() {
            match Provider::<Http>::try_from(config.arbitrum_rpc.as_str()) {
                Ok(p) => {
                    // Test connectivity
                    match p.get_block_number().await {
                        Ok(block) => {
                            info!("Blockchain bridge connected: block #{}", block);
                            Some(Arc::new(p))
                        }
                        Err(e) => {
                            warn!("Blockchain RPC unreachable: {}. Operating offline.", e);
                            None
                        }
                    }
                }
                Err(e) => {
                    warn!("Invalid RPC URL: {}. Bridge disabled.", e);
                    None
                }
            }
        } else {
            info!("No blockchain RPC configured. Bridge operating in offline mode.");
            None
        };

        Self { config, registry_address, escrow_address, provider }
    }

    /// Returns true if the bridge has a live blockchain connection
    pub fn is_connected(&self) -> bool {
        self.provider.is_some()
    }

    /// Deposit ABZU tokens into escrow for a storage request.
    ///
    /// Escrow_ID = keccak256(Payer || Root_CID || Block_Number)
    /// This CID-binding prevents mempool front-running attacks.
    pub async fn deposit_escrow(
        &self,
        root_cid: [u8; 32],
        amount_abzu: u128,
        required_replicas: u8,
    ) -> Result<EscrowDepositReceipt> {
        let provider = self.require_provider()?;
        let wallet = self.require_wallet()?;
        let signer = Arc::new(SignerMiddleware::new(provider.clone(), wallet));

        // Build the calldata for deposit(bytes32 root_cid, uint256 amount, uint8 required_replicas)
        let selector = ethers::utils::keccak256(b"deposit(bytes32,uint256,uint8)")[..4].to_vec();
        let mut calldata = selector;
        calldata.extend_from_slice(&root_cid);
        calldata.extend_from_slice(&U256::from(amount_abzu).encode_to_32());
        calldata.push(required_replicas);

        let tx = ethers::types::TransactionRequest::new()
            .to(self.escrow_address)
            .data(Bytes::from(calldata));

        let pending = signer.send_transaction(tx, None).await
            .context("Failed to send deposit transaction")?;

        let receipt = pending.await?
            .context("Deposit transaction not mined")?;

        info!("Escrow deposited: tx {:?}", receipt.transaction_hash);

        // Parse escrow_id from logs
        let escrow_id = parse_escrow_id_from_receipt(&receipt, root_cid);

        Ok(EscrowDepositReceipt {
            escrow_id,
            tx_hash: format!("{:?}", receipt.transaction_hash),
            block_number: receipt.block_number.map(|b| b.as_u64()).unwrap_or(0),
            root_cid,
            amount_abzu,
        })
    }

    /// Query the staked collateral for a node operator address
    pub async fn get_staked_collateral(&self, operator: Address) -> Result<u128> {
        let provider = self.require_provider()?;

        // Call getStakedCollateral(address) → uint256
        let selector = ethers::utils::keccak256(b"getStakedCollateral(address)")[..4].to_vec();
        let mut calldata = selector;
        let mut addr_bytes = [0u8; 32];
        addr_bytes[12..].copy_from_slice(operator.as_bytes());
        calldata.extend_from_slice(&addr_bytes);

        let call = ethers::types::TransactionRequest::new()
            .to(self.registry_address)
            .data(Bytes::from(calldata));

        let result = provider.call(&call.into(), None).await
            .context("getStakedCollateral call failed")?;

        let collateral = U256::from_big_endian(&result).as_u128();
        Ok(collateral)
    }

    /// Submit a slash proof to the contract.
    ///
    /// The contract verifies the Groth16 proof on-chain and slashes the
    /// accused node's staked collateral if valid.
    pub async fn submit_slash(
        &self,
        proof: &SerializedProof,
        accused_node_id: [u8; 32],
    ) -> Result<SlashReceipt> {
        let provider = self.require_provider()?;
        let wallet = self.require_wallet()?;
        let signer = Arc::new(SignerMiddleware::new(provider.clone(), wallet));

        let calldata_bytes = proof.to_calldata();

        // submitSlash(bytes32 accused, bytes calldata proof_data)
        let selector = ethers::utils::keccak256(b"submitSlash(bytes32,bytes)")[..4].to_vec();
        let mut calldata = selector;
        calldata.extend_from_slice(&accused_node_id);
        // ABI-encode the bytes: offset (32), length, data
        let offset = U256::from(64u64);
        calldata.extend_from_slice(&offset.encode_to_32());
        let len = U256::from(calldata_bytes.len() as u64);
        calldata.extend_from_slice(&len.encode_to_32());
        calldata.extend_from_slice(&calldata_bytes);
        // Pad to 32-byte boundary
        let pad = (32 - calldata_bytes.len() % 32) % 32;
        calldata.extend(std::iter::repeat(0u8).take(pad));

        let tx = ethers::types::TransactionRequest::new()
            .to(self.escrow_address)
            .data(Bytes::from(calldata));

        let pending = signer.send_transaction(tx, None).await
            .context("Failed to send slash transaction")?;

        let receipt = pending.await?
            .context("Slash transaction not mined")?;

        info!("Slash submitted: tx {:?}", receipt.transaction_hash);

        Ok(SlashReceipt {
            tx_hash: format!("{:?}", receipt.transaction_hash),
            accused_node_id: hex::encode(accused_node_id),
            block_number: receipt.block_number.map(|b| b.as_u64()).unwrap_or(0),
            success: receipt.status == Some(ethers::types::U64::one()),
        })
    }

    /// Get the current block number
    pub async fn block_number(&self) -> Result<u64> {
        let provider = self.require_provider()?;
        Ok(provider.get_block_number().await?.as_u64())
    }

    fn require_provider(&self) -> Result<Arc<Provider<Http>>> {
        self.provider.clone().context("Blockchain bridge is offline (no RPC configured)")
    }

    fn require_wallet(&self) -> Result<LocalWallet> {
        let key = self.config.signer_key.as_ref()
            .context("No signer key configured")?;
        key.parse::<LocalWallet>()
            .context("Invalid signer private key")
    }
}

// ─── Receipt Types ────────────────────────────────────────────────────────────

#[derive(Debug, Serialize, Deserialize)]
pub struct EscrowDepositReceipt {
    pub escrow_id: [u8; 32],
    pub tx_hash: String,
    pub block_number: u64,
    pub root_cid: [u8; 32],
    pub amount_abzu: u128,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SlashReceipt {
    pub tx_hash: String,
    pub accused_node_id: String,
    pub block_number: u64,
    pub success: bool,
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

trait U256Ext {
    fn encode_to_32(&self) -> [u8; 32];
}

impl U256Ext for U256 {
    fn encode_to_32(&self) -> [u8; 32] {
        let mut bytes = [0u8; 32];
        self.to_big_endian(&mut bytes);
        bytes
    }
}

fn parse_escrow_id_from_receipt(
    receipt: &ethers::types::TransactionReceipt,
    root_cid: [u8; 32],
) -> [u8; 32] {
    // Parse the EscrowDeposited event log to get the escrow_id
    // Event signature: EscrowDeposited(bytes32 indexed escrow_id, ...)
    let event_sig = ethers::utils::keccak256(b"EscrowDeposited(bytes32,address,bytes32,uint256)");
    for log in &receipt.logs {
        if !log.topics.is_empty() && log.topics[0].as_bytes() == event_sig {
            if log.topics.len() >= 2 {
                let mut id = [0u8; 32];
                id.copy_from_slice(log.topics[1].as_bytes());
                return id;
            }
        }
    }
    // Fallback: compute locally as keccak256(payer || root_cid || block)
    let mut input = Vec::new();
    if let Some(from) = receipt.from {
        input.extend_from_slice(from.as_bytes());
    }
    input.extend_from_slice(&root_cid);
    if let Some(block) = receipt.block_number {
        let mut block_bytes = [0u8; 32];
        U256::from(block.as_u64()).to_big_endian(&mut block_bytes);
        input.extend_from_slice(&block_bytes);
    }
    ethers::utils::keccak256(&input)
}

