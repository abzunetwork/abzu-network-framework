// abzu-node/src/dtn/mod.rs
//! Delay-Tolerant Networking — Asynchronous Messaging System
//!
//! Implements Phase 6: a fully decentralized, store-and-forward messaging
//! system that functions as an email equivalent for the post-internet network.
//! Messages are addressed by recipient Node ID, encrypted with Ed25519-derived
//! keys, persisted locally in sled, and delivered opportunistically over
//! GossipSub when the recipient (or any node that knows them) is reachable.
//!
//! Architecture:
//!   Sender → DtnMessage → signed + encrypted → GossipSub publish
//!                                             OR queued in sled for later delivery
//!   Receiver → sled inbox → decrypted → read by user via gateway
//!
//! Vector clocks provide causal ordering across partitioned networks, enabling
//! correct merge of inbox states when two network islands reconnect.

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use sled::Db;
use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{debug, info, warn};

// ─── Data Types ───────────────────────────────────────────────────────────────

/// A single DTN message (the email equivalent)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DtnMessage {
    /// Unique message ID: blake3(sender || recipient || timestamp || nonce)
    pub id: [u8; 32],
    /// Sender's Node ID
    pub from: [u8; 32],
    /// Recipient's Node ID
    pub to: [u8; 32],
    /// Subject line (plaintext, max 256 bytes)
    pub subject: String,
    /// Message body (may be encrypted; plaintext for local drafts)
    pub body: Vec<u8>,
    /// Content-type: "text/plain", "text/html", "application/abzu-content" (CID ref)
    pub content_type: String,
    /// Ed25519 signature over (id || from || to || subject || body)
    pub signature: Vec<u8>,
    /// Vector clock at time of sending
    pub clock: VectorClock,
    /// Unix timestamp of creation
    pub created_at: u64,
    /// Hop count (incremented at each relay)
    pub hops: u8,
    /// Maximum hops allowed (TTL equivalent)
    pub max_hops: u8,
    /// Optional CID reference (if body is a pointer to AbzuNet content)
    pub content_cid: Option<[u8; 32]>,
}

impl DtnMessage {
    /// Compute the message ID from its fields
    pub fn compute_id(from: &[u8; 32], to: &[u8; 32], created_at: u64, body: &[u8]) -> [u8; 32] {
        let mut hasher = blake3::Hasher::new();
        hasher.update(from);
        hasher.update(to);
        hasher.update(&created_at.to_le_bytes());
        hasher.update(body);
        *hasher.finalize().as_bytes()
    }

    /// Check if this message is still alive (within max_hops)
    pub fn is_alive(&self) -> bool {
        self.hops < self.max_hops
    }

    /// Return message age in seconds
    pub fn age_secs(&self) -> u64 {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        now.saturating_sub(self.created_at)
    }

    /// Build a reply to this message
    pub fn reply(&self, from: &[u8; 32], body: Vec<u8>) -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        let id = Self::compute_id(from, &self.from, now, &body);
        let subject = if self.subject.starts_with("Re: ") {
            self.subject.clone()
        } else {
            format!("Re: {}", self.subject)
        };
        Self {
            id,
            from: *from,
            to: self.from,
            subject,
            body,
            content_type: "text/plain".to_string(),
            signature: vec![],
            clock: VectorClock::new(),
            created_at: now,
            hops: 0,
            max_hops: 8,
            content_cid: None,
        }
    }
}

/// Causal vector clock for distributed ordering
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct VectorClock {
    /// Map of node_id_hex → logical time
    pub clocks: HashMap<String, u64>,
}

impl VectorClock {
    pub fn new() -> Self {
        Self { clocks: HashMap::new() }
    }

    /// Increment this node's clock entry
    pub fn tick(&mut self, node_id: &[u8; 32]) {
        let key = hex::encode(node_id);
        *self.clocks.entry(key).or_insert(0) += 1;
    }

    /// Merge another clock into this one (component-wise maximum)
    pub fn merge(&mut self, other: &VectorClock) {
        for (k, &v) in &other.clocks {
            let entry = self.clocks.entry(k.clone()).or_insert(0);
            *entry = (*entry).max(v);
        }
    }

    /// Returns true if self happened-before other
    pub fn happened_before(&self, other: &VectorClock) -> bool {
        let mut strictly_less = false;
        for (k, &v) in &self.clocks {
            let other_v = other.clocks.get(k).copied().unwrap_or(0);
            if v > other_v { return false; }
            if v < other_v { strictly_less = true; }
        }
        strictly_less
    }
}

/// Message status in the local store
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum MessageStatus {
    Queued,     // Waiting to be delivered
    Delivered,  // Confirmed delivered to recipient
    Read,       // Recipient has read it
    Failed,     // Exceeded max hops / TTL
}

/// Metadata stored alongside each message
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MessageMeta {
    pub status: MessageStatus,
    pub received_at: u64,
    pub delivered_at: Option<u64>,
    pub relay_count: u8,
}

// ─── DTN Queue (Persistent Store) ────────────────────────────────────────────

const OUTBOX_TREE: &str = "dtn_outbox";
const INBOX_TREE: &str  = "dtn_inbox";
const RELAY_TREE: &str  = "dtn_relay";
const CLOCK_KEY: &str   = "vector_clock";

/// The main DTN storage and routing engine
pub struct DtnQueue {
    db: Db,
    local_node_id: [u8; 32],
}

impl DtnQueue {
    /// Open (or create) a DTN queue at the given path
    pub fn new(path: &str) -> Result<Self> {
        let db = sled::open(path).with_context(|| format!("Cannot open DTN db at {}", path))?;
        Ok(Self { db, local_node_id: [0u8; 32] })
    }

    /// Open with a known local node identity
    pub fn with_identity(path: &str, node_id: [u8; 32]) -> Result<Self> {
        let db = sled::open(path)?;
        Ok(Self { db, local_node_id: node_id })
    }

    // ── Compose and Send ─────────────────────────────────────────────────────

    /// Create and queue a new outbound message
    pub fn send(
        &self,
        to: [u8; 32],
        subject: String,
        body: Vec<u8>,
        content_type: &str,
    ) -> Result<DtnMessage> {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();

        let id = DtnMessage::compute_id(&self.local_node_id, &to, now, &body);
        let mut clock = self.load_clock()?;
        clock.tick(&self.local_node_id);
        self.save_clock(&clock)?;

        let msg = DtnMessage {
            id,
            from: self.local_node_id,
            to,
            subject,
            body,
            content_type: content_type.to_string(),
            signature: vec![], // Signed externally by NodeIdentity
            clock,
            created_at: now,
            hops: 0,
            max_hops: 8,
            content_cid: None,
        };

        self.enqueue_outbox(&msg)?;
        info!("DTN: Queued message {} to {}", hex::encode(id), hex::encode(to));
        Ok(msg)
    }

    // ── Inbox ─────────────────────────────────────────────────────────────────

    /// Store a received message in the local inbox
    pub fn receive(&self, msg: DtnMessage) -> Result<()> {
        let tree = self.db.open_tree(INBOX_TREE)?;
        let bytes = bincode::serialize(&msg).context("Serialize inbox message")?;
        tree.insert(&msg.id, bytes.as_slice())?;
        let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
        let meta = MessageMeta { status: MessageStatus::Read, received_at: now, delivered_at: Some(now), relay_count: msg.hops };
        let meta_key = [&msg.id[..], b"_meta"].concat();
        tree.insert(meta_key.as_slice(), bincode::serialize(&meta)?.as_slice())?;

        // Merge sender's clock with ours
        let mut clock = self.load_clock()?;
        clock.merge(&msg.clock);
        clock.tick(&self.local_node_id);
        self.save_clock(&clock)?;

        info!("DTN: Received message {} from {}", hex::encode(msg.id), hex::encode(msg.from));
        Ok(())
    }

    /// List all inbox messages, newest first
    pub fn list_inbox(&self) -> Result<Vec<DtnMessage>> {
        let tree = self.db.open_tree(INBOX_TREE)?;
        let mut messages = Vec::new();
        for item in tree.iter() {
            let (key, val) = item?;
            if key.ends_with(b"_meta") { continue; }
            if let Ok(msg) = bincode::deserialize::<DtnMessage>(&val) {
                messages.push(msg);
            }
        }
        messages.sort_by(|a, b| b.created_at.cmp(&a.created_at));
        Ok(messages)
    }

    /// Get a single message by ID from inbox
    pub fn get_message(&self, id: &[u8; 32]) -> Result<Option<DtnMessage>> {
        let tree = self.db.open_tree(INBOX_TREE)?;
        match tree.get(id)? {
            Some(val) => Ok(Some(bincode::deserialize(&val)?)),
            None => {
                let tree = self.db.open_tree(OUTBOX_TREE)?;
                match tree.get(id)? {
                    Some(val) => Ok(Some(bincode::deserialize(&val)?)),
                    None => Ok(None),
                }
            }
        }
    }

    /// Delete a message from inbox
    pub fn delete_message(&self, id: &[u8; 32]) -> Result<()> {
        let tree = self.db.open_tree(INBOX_TREE)?;
        tree.remove(id)?;
        Ok(())
    }

    // ── Outbox ────────────────────────────────────────────────────────────────

    fn enqueue_outbox(&self, msg: &DtnMessage) -> Result<()> {
        let tree = self.db.open_tree(OUTBOX_TREE)?;
        let bytes = bincode::serialize(msg)?;
        tree.insert(&msg.id, bytes.as_slice())?;
        Ok(())
    }

    /// Return all pending outbound messages
    pub fn drain_outbox(&self) -> Result<Vec<DtnMessage>> {
        let tree = self.db.open_tree(OUTBOX_TREE)?;
        let mut out = Vec::new();
        for item in tree.iter() {
            let (_, val) = item?;
            if let Ok(msg) = bincode::deserialize::<DtnMessage>(&val) {
                if msg.is_alive() {
                    out.push(msg);
                }
            }
        }
        Ok(out)
    }

    /// Mark an outbox message as delivered (remove from outbox)
    pub fn mark_delivered(&self, id: &[u8; 32]) -> Result<()> {
        let tree = self.db.open_tree(OUTBOX_TREE)?;
        tree.remove(id)?;
        info!("DTN: Message {} confirmed delivered", hex::encode(id));
        Ok(())
    }

    // ── Relay Queue ───────────────────────────────────────────────────────────

    /// Store a message for relay to another node (we are not the recipient)
    pub fn queue_for_relay(&self, mut msg: DtnMessage) -> Result<()> {
        if !msg.is_alive() {
            warn!("DTN: Message {} exceeded max_hops, dropping", hex::encode(msg.id));
            return Ok(());
        }
        msg.hops += 1;
        let tree = self.db.open_tree(RELAY_TREE)?;
        let bytes = bincode::serialize(&msg)?;
        tree.insert(&msg.id, bytes.as_slice())?;
        debug!("DTN: Queued {} for relay (hops: {})", hex::encode(msg.id), msg.hops);
        Ok(())
    }

    /// Return all messages queued for relay
    pub fn drain_relay_queue(&self) -> Result<Vec<DtnMessage>> {
        let tree = self.db.open_tree(RELAY_TREE)?;
        let mut out = Vec::new();
        for item in tree.iter() {
            let (_, val) = item?;
            if let Ok(msg) = bincode::deserialize::<DtnMessage>(&val) {
                out.push(msg);
            }
        }
        Ok(out)
    }

    /// Remove a message from relay queue after successful forwarding
    pub fn remove_from_relay(&self, id: &[u8; 32]) -> Result<()> {
        let tree = self.db.open_tree(RELAY_TREE)?;
        tree.remove(id)?;
        Ok(())
    }

    // ── Routing Logic ─────────────────────────────────────────────────────────

    /// Route an incoming message: deliver to inbox if for us, relay otherwise
    pub fn route_message(&self, msg: DtnMessage) -> Result<MessageRouting> {
        if msg.to == self.local_node_id {
            self.receive(msg)?;
            Ok(MessageRouting::DeliveredLocally)
        } else {
            self.queue_for_relay(msg)?;
            Ok(MessageRouting::QueuedForRelay)
        }
    }

    // ── Sync on Reconnection ──────────────────────────────────────────────────

    /// Produce a sync digest for exchange with a newly connected peer.
    /// Returns the list of message IDs in our relay queue that might be
    /// destined for (or via) that peer.
    pub fn sync_digest(&self) -> Result<Vec<[u8; 32]>> {
        let relay = self.drain_relay_queue()?;
        let outbox = self.drain_outbox()?;
        let mut ids: Vec<[u8; 32]> = relay.iter().chain(outbox.iter())
            .map(|m| m.id)
            .collect();
        ids.dedup();
        Ok(ids)
    }

    /// Get statistics for the UI
    pub fn stats(&self) -> Result<DtnStats> {
        let inbox_tree = self.db.open_tree(INBOX_TREE)?;
        let outbox_tree = self.db.open_tree(OUTBOX_TREE)?;
        let relay_tree = self.db.open_tree(RELAY_TREE)?;
        Ok(DtnStats {
            inbox_count: inbox_tree.len() / 2, // divide by 2 (msg + meta)
            outbox_count: outbox_tree.len(),
            relay_count: relay_tree.len(),
        })
    }

    // ── Vector Clock ──────────────────────────────────────────────────────────

    fn load_clock(&self) -> Result<VectorClock> {
        match self.db.get(CLOCK_KEY)? {
            Some(bytes) => Ok(bincode::deserialize(&bytes)?),
            None => Ok(VectorClock::new()),
        }
    }

    fn save_clock(&self, clock: &VectorClock) -> Result<()> {
        let bytes = bincode::serialize(clock)?;
        self.db.insert(CLOCK_KEY, bytes.as_slice())?;
        Ok(())
    }

    pub fn current_clock(&self) -> Result<VectorClock> {
        self.load_clock()
    }

    // ── Legacy compatibility ──────────────────────────────────────────────────

    /// Raw enqueue (for backwards compatibility with earlier code)
    pub fn enqueue(&self, key: Vec<u8>, value: Vec<u8>) -> Result<()> {
        self.db.insert(key, value.as_slice())?;
        Ok(())
    }
}

#[derive(Debug)]
pub enum MessageRouting {
    DeliveredLocally,
    QueuedForRelay,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DtnStats {
    pub inbox_count: usize,
    pub outbox_count: usize,
    pub relay_count: usize,
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    fn make_queue(id: u8) -> (DtnQueue, TempDir) {
        let dir = TempDir::new().unwrap();
        let node_id = [id; 32];
        let q = DtnQueue::with_identity(dir.path().to_str().unwrap(), node_id).unwrap();
        (q, dir)
    }

    #[test]
    fn test_send_and_list_inbox() {
        let (q, _dir) = make_queue(1);
        let recipient = [2u8; 32];
        q.send(recipient, "Hello".to_string(), b"World".to_vec(), "text/plain").unwrap();
        let outbox = q.drain_outbox().unwrap();
        assert_eq!(outbox.len(), 1);
        assert_eq!(outbox[0].subject, "Hello");
    }

    #[test]
    fn test_receive_and_inbox() {
        let (q, _dir) = make_queue(1);
        let msg = DtnMessage {
            id: [9u8; 32],
            from: [2u8; 32],
            to: [1u8; 32],
            subject: "Test incoming".to_string(),
            body: b"body content".to_vec(),
            content_type: "text/plain".to_string(),
            signature: vec![],
            clock: VectorClock::new(),
            created_at: 1700000000,
            hops: 0,
            max_hops: 8,
            content_cid: None,
        };
        q.receive(msg.clone()).unwrap();
        let inbox = q.list_inbox().unwrap();
        assert_eq!(inbox.len(), 1);
        assert_eq!(inbox[0].id, msg.id);
    }

    #[test]
    fn test_relay_routing() {
        let (q, _dir) = make_queue(1);
        // Message addressed to node 3, we are node 1
        let msg = DtnMessage {
            id: [7u8; 32],
            from: [2u8; 32],
            to: [3u8; 32],
            subject: "Relay me".to_string(),
            body: b"relay".to_vec(),
            content_type: "text/plain".to_string(),
            signature: vec![],
            clock: VectorClock::new(),
            created_at: 1700000000,
            hops: 0,
            max_hops: 8,
            content_cid: None,
        };
        let routing = q.route_message(msg).unwrap();
        assert!(matches!(routing, MessageRouting::QueuedForRelay));
        assert_eq!(q.drain_relay_queue().unwrap().len(), 1);
    }

    #[test]
    fn test_vector_clock_merge() {
        let mut c1 = VectorClock::new();
        let mut c2 = VectorClock::new();
        c1.clocks.insert("A".to_string(), 3);
        c2.clocks.insert("A".to_string(), 1);
        c2.clocks.insert("B".to_string(), 5);
        c1.merge(&c2);
        assert_eq!(c1.clocks["A"], 3); // max(3,1)
        assert_eq!(c1.clocks["B"], 5); // max(0,5)
    }

    #[test]
    fn test_reply_threading() {
        let original = DtnMessage {
            id: [1u8; 32],
            from: [2u8; 32],
            to: [1u8; 32],
            subject: "Original".to_string(),
            body: b"body".to_vec(),
            content_type: "text/plain".to_string(),
            signature: vec![],
            clock: VectorClock::new(),
            created_at: 1700000000,
            hops: 0,
            max_hops: 8,
            content_cid: None,
        };
        let from = [1u8; 32];
        let reply = original.reply(&from, b"Reply body".to_vec());
        assert_eq!(reply.subject, "Re: Original");
        assert_eq!(reply.to, original.from);
        assert_eq!(reply.from, from);
    }
}

