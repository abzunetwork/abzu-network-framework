// abzu-node/src/network/kademlia.rs
//! Kademlia DHT integration for content routing
//!
//! Wraps libp2p Kademlia to provide content discovery across the AbzuNet overlay.
//! Nodes advertise content CIDs via `put_record` and discover providers via `get_providers`.

use anyhow::Result;
use libp2p::kad::{self, Behaviour as KadBehaviour, Config as KadConfig, Record, RecordKey};
use libp2p::{PeerId, Multiaddr};
use std::time::Duration;

/// Default Kademlia replication factor (k in Kademlia)
pub const KADEMLIA_K: usize = 20;

/// Create a Kademlia configuration tuned for AbzuNet
pub fn default_kademlia_config() -> KadConfig {
    let mut config = KadConfig::default();
    config.set_replication_factor(std::num::NonZeroUsize::new(KADEMLIA_K).unwrap());
    config.set_record_ttl(Some(Duration::from_secs(48 * 3600))); // 48h TTL
    config.set_publication_interval(Some(Duration::from_secs(12 * 3600))); // Re-advertise every 12h
    config.set_provider_record_ttl(Some(Duration::from_secs(48 * 3600)));
    config
}

/// Encode a root CID as a Kademlia record key
pub fn cid_to_record_key(cid: &[u8; 32]) -> RecordKey {
    RecordKey::new(cid)
}

/// Build a Kademlia provider record value (node's listen addresses as bytes)
pub fn build_provider_value(listen_addrs: &[Multiaddr]) -> Vec<u8> {
    let addrs: Vec<String> = listen_addrs.iter().map(|a| a.to_string()).collect();
    serde_json::to_vec(&addrs).unwrap_or_default()
}

/// Parse provider value back into multiaddresses
pub fn parse_provider_value(value: &[u8]) -> Vec<Multiaddr> {
    let addrs: Vec<String> = serde_json::from_slice(value).unwrap_or_default();
    addrs.iter()
        .filter_map(|s| s.parse().ok())
        .collect()
}
