// abzu-node/src/network/transport.rs
//! Custom Transport Layer for AbzuNet
//!
//! Implements Phase 1 requirement F.1: Generic Transport abstraction that composes
//! standard TCP/QUIC with UdpBroadcastTransport for offline local network operation.
//!
//! The UDP broadcast transport uses SO_BROADCAST and SO_REUSEADDR socket options
//! to enable discovery and communication over local LANs without internet routing.
//! This allows AbzuNet to function as a mesh network even when WAN connectivity fails.

use anyhow::{Context, Result};
use socket2::{Domain, Protocol, Socket, Type};
use std::io;
use std::net::{SocketAddr, UdpSocket as StdUdpSocket};
use tokio::net::UdpSocket;
use tracing::{debug, error, info, warn};

/// UDP broadcast transport for local mesh networking
///
/// This transport enables node discovery and communication over local networks
/// without requiring internet connectivity. It uses broadcast packets to reach
/// all nodes on the same subnet, implementing a basic mesh topology.
pub struct UdpBroadcastTransport {
    socket: UdpSocket,
    bind_addr: SocketAddr,
    broadcast_addr: SocketAddr,
}

impl UdpBroadcastTransport {
    /// Create a new UDP broadcast transport
    ///
    /// # Arguments
    /// * `bind_port` - Port to bind on (typically 4001)
    /// * `broadcast_port` - Port for broadcast messages
    ///
    /// # Socket Configuration
    /// - SO_BROADCAST: Enables sending broadcast packets
    /// - SO_REUSEADDR: Allows multiple nodes on same host (testing)
    /// - SO_REUSEPORT: Multiple processes can bind to same port (Linux/macOS)
    pub fn new(bind_port: u16, broadcast_port: u16) -> Result<Self> {
        // Create socket with broadcast and reuse capabilities
        let socket = Socket::new(Domain::IPV4, Type::DGRAM, Some(Protocol::UDP))
            .context("Failed to create UDP socket")?;

        // Enable broadcast
        socket.set_broadcast(true)
            .context("Failed to enable SO_BROADCAST")?;

        // Enable address reuse (important for multiple local nodes)
        socket.set_reuse_address(true)
            .context("Failed to enable SO_REUSEADDR")?;

        #[cfg(any(target_os = "linux", target_os = "macos"))]
        {
            socket.set_reuse_port(true)
                .context("Failed to enable SO_REUSEPORT")?;
        }

        // Bind to all interfaces
        let bind_addr: SocketAddr = format!("0.0.0.0:{}", bind_port).parse()?;
        socket.bind(&bind_addr.into())
            .with_context(|| format!("Failed to bind to {}", bind_addr))?;

        // Convert to tokio socket
        socket.set_nonblocking(true)?;
        let std_socket: StdUdpSocket = socket.into();
        let tokio_socket = UdpSocket::from_std(std_socket)
            .context("Failed to create tokio UdpSocket")?;

        let broadcast_addr: SocketAddr = format!("255.255.255.255:{}", broadcast_port).parse()?;

        info!(
            "UDP broadcast transport initialized: bind={}, broadcast={}",
            bind_addr, broadcast_addr
        );

        Ok(Self {
            socket: tokio_socket,
            bind_addr,
            broadcast_addr,
        })
    }

    /// Send a broadcast packet to all nodes on local network
    ///
    /// # Arguments
    /// * `data` - Data to broadcast (typically discovery or heartbeat messages)
    ///
    /// # Returns
    /// Number of bytes sent
    pub async fn broadcast(&self, data: &[u8]) -> Result<usize> {
        let sent = self.socket.send_to(data, self.broadcast_addr).await
            .context("Failed to send broadcast packet")?;

        debug!("Broadcast {} bytes to {}", sent, self.broadcast_addr);
        Ok(sent)
    }

    /// Receive a packet from the broadcast network
    ///
    /// # Returns
    /// Tuple of (data, sender_address)
    pub async fn receive(&self) -> Result<(Vec<u8>, SocketAddr)> {
        let mut buf = vec![0u8; 65535]; // Max UDP packet size
        let (len, addr) = self.socket.recv_from(&mut buf).await
            .context("Failed to receive packet")?;

        buf.truncate(len);
        debug!("Received {} bytes from {}", len, addr);

        Ok((buf, addr))
    }

    /// Get the local bind address
    pub fn local_addr(&self) -> SocketAddr {
        self.bind_addr
    }

    /// Get the broadcast address
    pub fn broadcast_addr(&self) -> SocketAddr {
        self.broadcast_addr
    }
}

/// Message types for local mesh protocol
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub enum MeshMessage {
    /// Node discovery announcement
    Discovery {
        node_id: [u8; 32],
        public_key: [u8; 32],
        listen_addrs: Vec<String>,
        timestamp: i64,
    },

    /// Heartbeat ping
    Heartbeat {
        node_id: [u8; 32],
        sequence: u64,
        timestamp: i64,
    },

    /// Response to discovery
    DiscoveryResponse {
        node_id: [u8; 32],
        public_key: [u8; 32],
        listen_addrs: Vec<String>,
        timestamp: i64,
    },

    /// Content availability announcement
    ContentAnnounce {
        node_id: [u8; 32],
        cid: [u8; 32],
        size_bytes: u64,
        timestamp: i64,
    },
}

impl MeshMessage {
    /// Serialize message to bytes for transmission
    pub fn to_bytes(&self) -> Result<Vec<u8>> {
        bincode::serialize(self).context("Failed to serialize mesh message")
    }

    /// Deserialize message from received bytes
    pub fn from_bytes(data: &[u8]) -> Result<Self> {
        bincode::deserialize(data).context("Failed to deserialize mesh message")
    }

    /// Extract Node ID from any message type
    pub fn node_id(&self) -> [u8; 32] {
        match self {
            MeshMessage::Discovery { node_id, .. } => *node_id,
            MeshMessage::Heartbeat { node_id, .. } => *node_id,
            MeshMessage::DiscoveryResponse { node_id, .. } => *node_id,
            MeshMessage::ContentAnnounce { node_id, .. } => *node_id,
        }
    }

    /// Get message timestamp
    pub fn timestamp(&self) -> i64 {
        match self {
            MeshMessage::Discovery { timestamp, .. } => *timestamp,
            MeshMessage::Heartbeat { timestamp, .. } => *timestamp,
            MeshMessage::DiscoveryResponse { timestamp, .. } => *timestamp,
            MeshMessage::ContentAnnounce { timestamp, .. } => *timestamp,
        }
    }
}

/// Local mesh network manager
///
/// Coordinates UDP broadcast transport for node discovery and content announcement
/// on isolated local networks (home LANs, disconnected islands).
pub struct MeshNetworkManager {
    transport: UdpBroadcastTransport,
    local_node_id: [u8; 32],
}

impl MeshNetworkManager {
    /// Create a new mesh network manager
    pub fn new(
        transport: UdpBroadcastTransport,
        local_node_id: [u8; 32],
    ) -> Self {
        Self {
            transport,
            local_node_id,
        }
    }

    /// Send discovery announcement to find other local nodes
    pub async fn announce_presence(&self, public_key: [u8; 32], listen_addrs: Vec<String>) -> Result<()> {
        let msg = MeshMessage::Discovery {
            node_id: self.local_node_id,
            public_key,
            listen_addrs,
            timestamp: chrono::Utc::now().timestamp(),
        };

        let data = msg.to_bytes()?;
        self.transport.broadcast(&data).await?;

        Ok(())
    }

    /// Send heartbeat to maintain presence on local network
    pub async fn send_heartbeat(&self, sequence: u64) -> Result<()> {
        let msg = MeshMessage::Heartbeat {
            node_id: self.local_node_id,
            sequence,
            timestamp: chrono::Utc::now().timestamp(),
        };

        let data = msg.to_bytes()?;
        self.transport.broadcast(&data).await?;

        Ok(())
    }

    /// Announce content availability to local nodes
    pub async fn announce_content(&self, cid: [u8; 32], size_bytes: u64) -> Result<()> {
        let msg = MeshMessage::ContentAnnounce {
            node_id: self.local_node_id,
            cid,
            size_bytes,
            timestamp: chrono::Utc::now().timestamp(),
        };

        let data = msg.to_bytes()?;
        self.transport.broadcast(&data).await?;

        Ok(())
    }

    /// Receive and parse incoming mesh messages
    pub async fn receive_message(&self) -> Result<(MeshMessage, SocketAddr)> {
        let (data, addr) = self.transport.receive().await?;

        // Ignore messages from ourselves
        let msg = MeshMessage::from_bytes(&data)?;
        if msg.node_id() == self.local_node_id {
            // Skip our own broadcasts
            return self.receive_message().await;
        }

        Ok((msg, addr))
    }

    /// Run discovery loop to find local peers
    ///
    /// This continuously sends discovery announcements and processes responses.
    /// Returns discovered peer information: (node_id, public_key, addresses).
    pub async fn run_discovery_loop(
        &self,
        public_key: [u8; 32],
        listen_addrs: Vec<String>,
        discovered_tx: tokio::sync::mpsc::UnboundedSender<([u8; 32], [u8; 32], Vec<String>)>,
    ) -> Result<()> {
        let mut interval = tokio::time::interval(std::time::Duration::from_secs(30));

        loop {
            tokio::select! {
                _ = interval.tick() => {
                    // Send periodic discovery announcement
                    if let Err(e) = self.announce_presence(public_key, listen_addrs.clone()).await {
                        warn!("Failed to send discovery announcement: {}", e);
                    }
                }

                result = self.receive_message() => {
                    match result {
                        Ok((msg, addr)) => {
                            match msg {
                                MeshMessage::Discovery { node_id, public_key, listen_addrs, .. } => {
                                    info!("Discovered local peer: {} from {}", hex::encode(node_id), addr);
                                    let _ = discovered_tx.send((node_id, public_key, listen_addrs));
                                }
                                MeshMessage::DiscoveryResponse { node_id, public_key, listen_addrs, .. } => {
                                    info!("Received discovery response from: {}", hex::encode(node_id));
                                    let _ = discovered_tx.send((node_id, public_key, listen_addrs));
                                }
                                _ => {
                                    // Other message types handled elsewhere
                                }
                            }
                        }
                        Err(e) => {
                            error!("Error receiving mesh message: {}", e);
                        }
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_mesh_message_serialization() {
        let msg = MeshMessage::Discovery {
            node_id: [1u8; 32],
            public_key: [2u8; 32],
            listen_addrs: vec!["/ip4/127.0.0.1/tcp/4001".to_string()],
            timestamp: 1234567890,
        };

        let bytes = msg.to_bytes().unwrap();
        let decoded = MeshMessage::from_bytes(&bytes).unwrap();

        match decoded {
            MeshMessage::Discovery { node_id, .. } => {
                assert_eq!(node_id, [1u8; 32]);
            }
            _ => panic!("Wrong message type"),
        }
    }

    #[tokio::test]
    async fn test_udp_broadcast_transport() {
        // This test requires appropriate network permissions
        let result = UdpBroadcastTransport::new(14001, 14002);
        
        match result {
            Ok(transport) => {
                assert_eq!(transport.local_addr().port(), 14001);
                assert_eq!(transport.broadcast_addr().port(), 14002);
            }
            Err(e) => {
                // Permission denied is expected in some test environments
                eprintln!("UDP broadcast test skipped: {}", e);
            }
        }
    }
}
