// abzu-node/src/network/behaviour.rs
//! Composed libp2p NetworkBehaviour for AbzuNet
//!
//! Combines Kademlia DHT, GossipSub, mDNS, Identify, and Ping
//! into a single unified swarm behaviour using the libp2p derive macro.

use libp2p::{
    gossipsub::Behaviour as Gossipsub,
    kad::{Behaviour as Kademlia, store::MemoryStore},
    identify::{Behaviour as Identify, Config as IdentifyConfig},
    mdns::{tokio::Behaviour as Mdns, Config as MdnsConfig},
    ping::{Behaviour as Ping, Config as PingConfig},
    swarm::NetworkBehaviour,
    PeerId,
};
use std::time::Duration;

/// Version string announced via Identify protocol
pub const ABZUNET_PROTOCOL_VERSION: &str = "/abzunet/2.0.3";

/// The composed network behaviour used by the AbzuNet swarm
#[derive(NetworkBehaviour)]
pub struct AbzuBehaviour {
    pub kademlia: Kademlia<MemoryStore>,
    pub gossipsub: Gossipsub,
    pub identify: Identify,
    pub mdns: Mdns,
    pub ping: Ping,
}

impl AbzuBehaviour {
    pub fn new(
        local_peer_id: PeerId,
        keypair: &libp2p::identity::Keypair,
    ) -> anyhow::Result<Self> {
        // Kademlia
        let kad_cfg = super::kademlia::default_kademlia_config();
        let kad_store = MemoryStore::new(local_peer_id);
        let kademlia = Kademlia::with_config(local_peer_id, kad_store, kad_cfg);

        // GossipSub
        let gossipsub = super::gossipsub::build_gossipsub(keypair)?;

        // Identify - announces our capabilities to connected peers
        let identify = Identify::new(IdentifyConfig::new(
            ABZUNET_PROTOCOL_VERSION.to_string(),
            keypair.public(),
        ));

        // mDNS - local peer discovery without bootstrap
        let mdns = Mdns::new(MdnsConfig::default(), local_peer_id)?;

        // Ping - keep-alive and latency measurement
        let ping = Ping::new(
            PingConfig::new()
                .with_interval(Duration::from_secs(15))
                .with_timeout(Duration::from_secs(10))
        );

        Ok(Self { kademlia, gossipsub, identify, mdns, ping })
    }
}
