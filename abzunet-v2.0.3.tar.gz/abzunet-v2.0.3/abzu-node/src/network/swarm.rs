// abzu-node/src/network/swarm.rs
//! Swarm Event Loop — Phase 1 + 2 Integration
//!
//! Drives the libp2p swarm, handling all NetworkBehaviour events and bridging
//! them to the rest of the node via Tokio channels. This is the central nervous
//! system of the node: it connects peer discovery, DHT routing, GossipSub
//! messaging, and the gateway's remote-fetch requests into a single coherent loop.
//!
//! Architecture:
//!
//!   Gateway  ──cmd──►  SwarmCommand channel  ──►  SwarmLoop
//!   Gateway  ◄──evt──  SwarmEvent channel    ◄──  SwarmLoop
//!   UDP Mesh ──addr──►  discovered_peers      ──►  SwarmLoop (dial)
//!
//! The swarm loop runs exclusively on one task. All external interaction is
//! via channels, eliminating lock contention on the swarm itself.

use anyhow::Result;
use futures::StreamExt;
use libp2p::{
    gossipsub::{IdentTopic, Message as GossipMessage},
    kad::{self, QueryId, RecordKey},
    mdns,
    swarm::{Swarm, SwarmEvent},
    Multiaddr, PeerId,
};
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::time::Duration;
use tokio::sync::{mpsc, oneshot};
use tracing::{debug, error, info, warn};

use super::behaviour::{AbzuBehaviour, AbzuBehaviourEvent};
use super::gossipsub::{heartbeat_topic, TOPIC_CONTENT, TOPIC_ANNOUNCE};
use super::kademlia::{cid_to_record_key, build_provider_value};
use crate::favor::{FavorEngine, HealthState};

// ─── Channel Types ────────────────────────────────────────────────────────────

/// Commands sent from the gateway/other subsystems into the swarm loop
#[derive(Debug)]
pub enum SwarmCommand {
    /// Advertise this node as a provider of a root CID in Kademlia
    ProvideContent {
        cid: [u8; 32],
    },
    /// Find providers for a CID and return their peer IDs + addresses
    FindProviders {
        cid: [u8; 32],
        reply: oneshot::Sender<Vec<(PeerId, Vec<Multiaddr>)>>,
    },
    /// Publish a message to a GossipSub topic
    Publish {
        topic: String,
        data: Vec<u8>,
    },
    /// Dial a specific peer address
    Dial {
        addr: Multiaddr,
    },
    /// Register a name→CID mapping in the DHT
    DhtPutName {
        name: String,
        cid: [u8; 32],
    },
    /// Resolve a name from the DHT
    DhtGetName {
        name: String,
        reply: oneshot::Sender<Option<[u8; 32]>>,
    },
    /// Return current peer list and health
    GetPeers {
        reply: oneshot::Sender<Vec<PeerInfo>>,
    },
    /// Shutdown the swarm
    Shutdown,
}

/// Events emitted from the swarm loop to listeners
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SwarmEvent {
    PeerConnected(String),            // peer_id hex
    PeerDisconnected(String),
    ContentAnnounced { cid: String, peer: String },
    GossipMessage { topic: String, data: Vec<u8>, source: Option<String> },
    HeartbeatReceived { node_id: String, seq: u64 },
    DhtRecord { key: String, value: Vec<u8> },
}

/// Snapshot of a peer's current state
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PeerInfo {
    pub peer_id: String,
    pub addrs: Vec<String>,
    pub health: String,
    pub ping_ms: Option<u64>,
    pub favor_score: Option<f64>,
}

// ─── Pending Query Tracking ───────────────────────────────────────────────────

enum PendingQuery {
    FindProviders {
        cid: [u8; 32],
        reply: oneshot::Sender<Vec<(PeerId, Vec<Multiaddr>)>>,
        results: Vec<(PeerId, Vec<Multiaddr>)>,
    },
    GetRecord {
        key: String,
        reply: oneshot::Sender<Option<[u8; 32]>>,
    },
}

// ─── Swarm Handle (given to gateway/other subsystems) ────────────────────────

/// Clone-able handle for sending commands to the swarm and subscribing to events
#[derive(Clone)]
pub struct SwarmHandle {
    pub cmd_tx: mpsc::UnboundedSender<SwarmCommand>,
    pub evt_tx: mpsc::UnboundedSender<SwarmEvent>,
}

impl SwarmHandle {
    /// Advertise content availability in Kademlia DHT
    pub fn provide_content(&self, cid: [u8; 32]) {
        let _ = self.cmd_tx.send(SwarmCommand::ProvideContent { cid });
    }

    /// Asynchronously find providers for a CID; returns list of (PeerId, addrs)
    pub async fn find_providers(&self, cid: [u8; 32]) -> Vec<(PeerId, Vec<Multiaddr>)> {
        let (tx, rx) = oneshot::channel();
        let _ = self.cmd_tx.send(SwarmCommand::FindProviders { cid, reply: tx });
        rx.await.unwrap_or_default()
    }

    /// Publish bytes to a named GossipSub topic
    pub fn publish(&self, topic: &str, data: Vec<u8>) {
        let _ = self.cmd_tx.send(SwarmCommand::Publish {
            topic: topic.to_string(),
            data,
        });
    }

    /// Dial a peer address
    pub fn dial(&self, addr: Multiaddr) {
        let _ = self.cmd_tx.send(SwarmCommand::Dial { addr });
    }

    /// Store a name→CID mapping in the DHT
    pub fn put_name(&self, name: String, cid: [u8; 32]) {
        let _ = self.cmd_tx.send(SwarmCommand::DhtPutName { name, cid });
    }

    /// Resolve a name from the DHT
    pub async fn get_name(&self, name: String) -> Option<[u8; 32]> {
        let (tx, rx) = oneshot::channel();
        let _ = self.cmd_tx.send(SwarmCommand::DhtGetName { name, reply: tx });
        rx.await.ok().flatten()
    }

    /// Get snapshot of connected peers
    pub async fn get_peers(&self) -> Vec<PeerInfo> {
        let (tx, rx) = oneshot::channel();
        let _ = self.cmd_tx.send(SwarmCommand::GetPeers { reply: tx });
        rx.await.unwrap_or_default()
    }

    pub fn shutdown(&self) {
        let _ = self.cmd_tx.send(SwarmCommand::Shutdown);
    }
}

// ─── Swarm Loop ──────────────────────────────────────────────────────────────

/// Run the libp2p swarm event loop.
///
/// This task owns the Swarm exclusively and processes all events in a single
/// select! loop. External interaction is entirely through channels.
pub async fn run_swarm_loop(
    mut swarm: Swarm<AbzuBehaviour>,
    mut cmd_rx: mpsc::UnboundedReceiver<SwarmCommand>,
    evt_tx: mpsc::UnboundedSender<SwarmEvent>,
    local_node_id: [u8; 32],
    local_addrs: Vec<Multiaddr>,
    favor: std::sync::Arc<FavorEngine>,
    mut discovered_peers_rx: mpsc::UnboundedReceiver<(PeerId, Vec<Multiaddr>)>,
) {
    let mut pending_queries: HashMap<QueryId, PendingQuery> = HashMap::new();
    let mut connected_peers: HashMap<PeerId, PeerInfo> = HashMap::new();
    let mut heartbeat_seq = 0u64;
    let mut heartbeat_interval = tokio::time::interval(Duration::from_secs(15));
    let mut bootstrap_interval = tokio::time::interval(Duration::from_secs(300)); // 5 min

    // Subscribe to our assigned heartbeat topic
    let hb_topic = heartbeat_topic(local_node_id[0]);
    let content_topic = IdentTopic::new(TOPIC_CONTENT);
    let announce_topic = IdentTopic::new(TOPIC_ANNOUNCE);

    if let Err(e) = swarm.behaviour_mut().gossipsub.subscribe(&hb_topic) {
        warn!("Failed to subscribe to heartbeat topic: {}", e);
    }
    if let Err(e) = swarm.behaviour_mut().gossipsub.subscribe(&content_topic) {
        warn!("Failed to subscribe to content topic: {}", e);
    }
    if let Err(e) = swarm.behaviour_mut().gossipsub.subscribe(&announce_topic) {
        warn!("Failed to subscribe to announce topic: {}", e);
    }

    info!("Swarm event loop started. HB topic: abzu/heartbeat/{:02x}", local_node_id[0]);

    loop {
        tokio::select! {
            // ── Swarm Events ─────────────────────────────────────────────
            event = swarm.next() => {
                match event {
                    Some(SwarmEvent::Behaviour(behaviour_event)) => {
                        handle_behaviour_event(
                            behaviour_event,
                            &mut swarm,
                            &evt_tx,
                            &mut pending_queries,
                            &mut connected_peers,
                            &favor,
                        ).await;
                    }
                    Some(SwarmEvent::NewListenAddr { address, .. }) => {
                        info!("Listening on {}", address);
                    }
                    Some(SwarmEvent::ConnectionEstablished { peer_id, endpoint, .. }) => {
                        let addr = endpoint.get_remote_address().clone();
                        info!("Connected to peer: {} at {}", peer_id, addr);
                        connected_peers.insert(peer_id, PeerInfo {
                            peer_id: peer_id.to_string(),
                            addrs: vec![addr.to_string()],
                            health: "Alive".to_string(),
                            ping_ms: None,
                            favor_score: None,
                        });
                        // Add to Kademlia routing table
                        swarm.behaviour_mut().kademlia.add_address(&peer_id, addr);
                        let _ = evt_tx.send(SwarmEvent::PeerConnected(peer_id.to_string()));
                    }
                    Some(SwarmEvent::ConnectionClosed { peer_id, .. }) => {
                        info!("Disconnected from peer: {}", peer_id);
                        connected_peers.remove(&peer_id);
                        favor.record_missed_heartbeat(*peer_id.as_ref().first().map(|b| {
                            let mut arr = [0u8; 32];
                            arr[0] = *b;
                            arr
                        }).get_or_insert([0u8; 32]));
                        let _ = evt_tx.send(SwarmEvent::PeerDisconnected(peer_id.to_string()));
                    }
                    Some(SwarmEvent::OutgoingConnectionError { peer_id, error, .. }) => {
                        warn!("Connection error to {:?}: {}", peer_id, error);
                    }
                    Some(SwarmEvent::IncomingConnectionError { error, .. }) => {
                        warn!("Incoming connection error: {}", error);
                    }
                    _ => {}
                }
            }

            // ── Commands from Gateway / Other Subsystems ──────────────────
            cmd = cmd_rx.recv() => {
                match cmd {
                    Some(SwarmCommand::ProvideContent { cid }) => {
                        let key = cid_to_record_key(&cid);
                        swarm.behaviour_mut().kademlia.start_providing(key).ok();
                        debug!("Advertising content: {}", hex::encode(cid));

                        // Also announce via GossipSub for immediate mesh propagation
                        let msg = serde_json::json!({
                            "cid": hex::encode(cid),
                            "node_id": hex::encode(local_node_id),
                            "addrs": local_addrs.iter().map(|a| a.to_string()).collect::<Vec<_>>(),
                        });
                        if let Ok(bytes) = serde_json::to_vec(&msg) {
                            swarm.behaviour_mut().gossipsub
                                .publish(content_topic.clone(), bytes).ok();
                        }
                    }

                    Some(SwarmCommand::FindProviders { cid, reply }) => {
                        let key = cid_to_record_key(&cid);
                        let query_id = swarm.behaviour_mut().kademlia
                            .get_providers(key);
                        pending_queries.insert(query_id, PendingQuery::FindProviders {
                            cid,
                            reply,
                            results: Vec::new(),
                        });
                        debug!("Finding providers for: {}", hex::encode(cid));
                    }

                    Some(SwarmCommand::Publish { topic, data }) => {
                        let t = IdentTopic::new(topic);
                        swarm.behaviour_mut().gossipsub.publish(t, data).ok();
                    }

                    Some(SwarmCommand::Dial { addr }) => {
                        swarm.dial(addr.clone()).ok();
                        debug!("Dialing: {}", addr);
                    }

                    Some(SwarmCommand::DhtPutName { name, cid }) => {
                        let key = RecordKey::new(&format!("abzu/ans/{}", name));
                        let record = kad::Record {
                            key,
                            value: cid.to_vec(),
                            publisher: None,
                            expires: None,
                        };
                        swarm.behaviour_mut().kademlia.put_record(record, kad::Quorum::One).ok();
                        info!("DHT: Stored ANS record: {} → {}", name, hex::encode(cid));
                    }

                    Some(SwarmCommand::DhtGetName { name, reply }) => {
                        let key = RecordKey::new(&format!("abzu/ans/{}", name));
                        let query_id = swarm.behaviour_mut().kademlia.get_record(key);
                        pending_queries.insert(query_id, PendingQuery::GetRecord {
                            key: name,
                            reply,
                        });
                    }

                    Some(SwarmCommand::GetPeers { reply }) => {
                        let peers: Vec<PeerInfo> = connected_peers.values().cloned().collect();
                        let _ = reply.send(peers);
                    }

                    Some(SwarmCommand::Shutdown) | None => {
                        info!("Swarm loop shutting down");
                        break;
                    }
                }
            }

            // ── Discovered Peers from UDP Broadcast Mesh ──────────────────
            discovered = discovered_peers_rx.recv() => {
                if let Some((peer_id, addrs)) = discovered {
                    info!("Mesh-discovered peer: {} at {:?}", peer_id, addrs);
                    for addr in &addrs {
                        swarm.behaviour_mut().kademlia.add_address(&peer_id, addr.clone());
                        // Attempt direct dial
                        swarm.dial(addr.clone()).ok();
                    }
                }
            }

            // ── Heartbeat ─────────────────────────────────────────────────
            _ = heartbeat_interval.tick() => {
                heartbeat_seq += 1;
                let msg = serde_json::json!({
                    "node_id": hex::encode(local_node_id),
                    "seq": heartbeat_seq,
                    "ts": chrono::Utc::now().timestamp(),
                });
                if let Ok(bytes) = serde_json::to_vec(&msg) {
                    swarm.behaviour_mut().gossipsub
                        .publish(hb_topic.clone(), bytes).ok();
                }
                debug!("Published heartbeat #{}", heartbeat_seq);
            }

            // ── Kademlia Bootstrap ────────────────────────────────────────
            _ = bootstrap_interval.tick() => {
                swarm.behaviour_mut().kademlia.bootstrap().ok();
                debug!("Kademlia bootstrap triggered");
            }
        }
    }
}

// ─── Behaviour Event Dispatcher ───────────────────────────────────────────────

async fn handle_behaviour_event(
    event: AbzuBehaviourEvent,
    swarm: &mut Swarm<AbzuBehaviour>,
    evt_tx: &mpsc::UnboundedSender<SwarmEvent>,
    pending_queries: &mut HashMap<QueryId, PendingQuery>,
    connected_peers: &mut HashMap<PeerId, PeerInfo>,
    favor: &std::sync::Arc<FavorEngine>,
) {
    match event {
        // ── Kademlia Events ───────────────────────────────────────────────
        AbzuBehaviourEvent::Kademlia(kad_event) => {
            handle_kademlia_event(kad_event, evt_tx, pending_queries).await;
        }

        // ── GossipSub Events ──────────────────────────────────────────────
        AbzuBehaviourEvent::Gossipsub(gs_event) => {
            match gs_event {
                libp2p::gossipsub::Event::Message { message, .. } => {
                    let topic = message.topic.as_str().to_string();
                    let source = message.source.map(|p| p.to_string());

                    // Parse heartbeat messages
                    if topic.starts_with("abzu/heartbeat/") {
                        if let Ok(parsed) = serde_json::from_slice::<serde_json::Value>(&message.data) {
                            let node_id = parsed["node_id"].as_str().unwrap_or("").to_string();
                            let seq = parsed["seq"].as_u64().unwrap_or(0);
                            debug!("Heartbeat from {}: seq {}", node_id, seq);
                            let _ = evt_tx.send(SwarmEvent::HeartbeatReceived { node_id, seq });
                        }
                    } else {
                        let _ = evt_tx.send(SwarmEvent::GossipMessage {
                            topic,
                            data: message.data,
                            source,
                        });
                    }
                }
                libp2p::gossipsub::Event::Subscribed { peer_id, topic } => {
                    debug!("Peer {} subscribed to {}", peer_id, topic);
                }
                _ => {}
            }
        }

        // ── mDNS Events ───────────────────────────────────────────────────
        AbzuBehaviourEvent::Mdns(mdns_event) => {
            match mdns_event {
                mdns::Event::Discovered(list) => {
                    for (peer_id, addr) in list {
                        info!("mDNS discovered: {} at {}", peer_id, addr);
                        swarm.behaviour_mut().kademlia.add_address(&peer_id, addr.clone());
                        swarm.dial(addr.clone()).ok();
                    }
                }
                mdns::Event::Expired(list) => {
                    for (peer_id, _) in list {
                        debug!("mDNS expired: {}", peer_id);
                    }
                }
            }
        }

        // ── Identify Events ───────────────────────────────────────────────
        AbzuBehaviourEvent::Identify(id_event) => {
            match id_event {
                libp2p::identify::Event::Received { peer_id, info } => {
                    debug!("Identified peer {}: protocol {}", peer_id, info.protocol_version);
                    // Add all listen addrs to Kademlia
                    for addr in &info.listen_addrs {
                        swarm.behaviour_mut().kademlia.add_address(&peer_id, addr.clone());
                    }
                    // Update peer info
                    if let Some(entry) = connected_peers.get_mut(&peer_id) {
                        entry.addrs = info.listen_addrs.iter().map(|a| a.to_string()).collect();
                    }
                }
                _ => {}
            }
        }

        // ── Ping Events ───────────────────────────────────────────────────
        AbzuBehaviourEvent::Ping(ping_event) => {
            if let Ok(rtt) = ping_event.result {
                let ms = rtt.as_millis() as u64;
                if let Some(entry) = connected_peers.get_mut(&ping_event.peer) {
                    entry.ping_ms = Some(ms);
                }
                debug!("Ping {} → {}ms", ping_event.peer, ms);
            }
        }
    }
}

async fn handle_kademlia_event(
    event: kad::Event,
    evt_tx: &mpsc::UnboundedSender<SwarmEvent>,
    pending_queries: &mut HashMap<QueryId, PendingQuery>,
) {
    match event {
        kad::Event::OutboundQueryProgressed { id, result, .. } => {
            match result {
                kad::QueryResult::GetProviders(Ok(kad::GetProvidersOk::FoundProviders {
                    key, providers, ..
                })) => {
                    if let Some(PendingQuery::FindProviders { results, .. }) =
                        pending_queries.get_mut(&id)
                    {
                        for provider in providers {
                            results.push((provider, Vec::new()));
                        }
                    }
                }

                kad::QueryResult::GetProviders(Ok(kad::GetProvidersOk::FinishedWithNoAdditionalRecord { .. })) => {
                    if let Some(PendingQuery::FindProviders { reply, results, .. }) =
                        pending_queries.remove(&id)
                    {
                        debug!("Provider search complete: {} found", results.len());
                        let _ = reply.send(results);
                    }
                }

                kad::QueryResult::GetRecord(Ok(kad::GetRecordOk::FoundRecord(rec))) => {
                    let key = String::from_utf8_lossy(rec.record.key.as_ref()).to_string();
                    let value = rec.record.value.clone();
                    let _ = evt_tx.send(SwarmEvent::DhtRecord { key: key.clone(), value: value.clone() });

                    if let Some(PendingQuery::GetRecord { reply, .. }) = pending_queries.remove(&id) {
                        if value.len() == 32 {
                            let mut arr = [0u8; 32];
                            arr.copy_from_slice(&value);
                            let _ = reply.send(Some(arr));
                        } else {
                            let _ = reply.send(None);
                        }
                    }
                }

                kad::QueryResult::GetRecord(Err(_)) => {
                    if let Some(PendingQuery::GetRecord { reply, .. }) = pending_queries.remove(&id) {
                        let _ = reply.send(None);
                    }
                }

                kad::QueryResult::StartProviding(Ok(_)) => {
                    debug!("Kademlia: now providing content");
                }

                kad::QueryResult::Bootstrap(Ok(bootstrap)) => {
                    debug!("Kademlia bootstrap complete: {:?}", bootstrap);
                }

                _ => {}
            }
        }

        kad::Event::RoutingUpdated { peer, .. } => {
            debug!("Kademlia routing table updated: {}", peer);
        }

        _ => {}
    }
}

// ─── Builder ─────────────────────────────────────────────────────────────────

/// Build a swarm and return it along with a SwarmHandle
pub fn build_swarm(
    identity: &crate::identity::NodeIdentity,
    listen_addrs: &[String],
    bootstrap_peers: &[String],
) -> Result<(
    Swarm<AbzuBehaviour>,
    SwarmHandle,
    mpsc::UnboundedReceiver<SwarmCommand>,
    mpsc::UnboundedSender<SwarmEvent>,
    mpsc::UnboundedSender<(PeerId, Vec<Multiaddr>)>,
    mpsc::UnboundedReceiver<(PeerId, Vec<Multiaddr>)>,
)> {
    use libp2p::identity::Keypair;

    // Build libp2p identity from ed25519 secret key
    let secret_bytes = identity.public_key_bytes(); // We use pubkey bytes as seed for determinism
    // In production, derive from the Ed25519 secret; here we build a fresh keypair
    let keypair = Keypair::generate_ed25519();
    let local_peer_id = libp2p::PeerId::from(keypair.public());
    info!("libp2p PeerId: {}", local_peer_id);

    let behaviour = AbzuBehaviour::new(local_peer_id, &keypair)?;

    let transport = libp2p::tokio_development_transport(keypair)?;

    let mut swarm = Swarm::new(
        transport,
        behaviour,
        local_peer_id,
        libp2p::swarm::Config::with_tokio_executor()
            .with_idle_connection_timeout(Duration::from_secs(60)),
    );

    // Listen on configured addresses
    for addr_str in listen_addrs {
        if let Ok(addr) = addr_str.parse::<Multiaddr>() {
            swarm.listen_on(addr).ok();
        }
    }

    // Add bootstrap peers to Kademlia
    for peer_str in bootstrap_peers {
        if let Ok(addr) = peer_str.parse::<Multiaddr>() {
            // Extract peer ID from the multiaddr if present
            if let Some(libp2p::multiaddr::Protocol::P2p(hash)) = addr.iter().last() {
                if let Ok(peer_id) = PeerId::from_multihash(hash) {
                    swarm.behaviour_mut().kademlia.add_address(&peer_id, addr);
                    swarm.behaviour_mut().kademlia.bootstrap().ok();
                }
            }
        }
    }

    let (cmd_tx, cmd_rx) = mpsc::unbounded_channel();
    let (evt_tx, _evt_rx) = mpsc::unbounded_channel();
    let (disc_tx, disc_rx) = mpsc::unbounded_channel();

    let handle = SwarmHandle {
        cmd_tx,
        evt_tx: evt_tx.clone(),
    };

    Ok((swarm, handle, cmd_rx, evt_tx, disc_tx, disc_rx))
}
