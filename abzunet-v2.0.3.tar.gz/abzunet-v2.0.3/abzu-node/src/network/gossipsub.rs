// abzu-node/src/network/gossipsub.rs
//! GossipSub mesh configuration with 256-way topic segmentation
//!
//! Per the specification, heartbeat topics are partitioned deterministically:
//!   topic = "abzu/heartbeat/{N_id[0]:02x}"
//! This creates 256 independent topics, each serving ~N/256 nodes,
//! preventing O(N) bandwidth consumption as the network grows.

use libp2p::gossipsub::{
    Behaviour as GossipsubBehaviour, Config as GossipsubConfig, ConfigBuilder,
    MessageAuthenticity, ValidationMode, IdentTopic, TopicHash, MessageId,
    Message,
};
use libp2p::identity::Keypair;
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};
use anyhow::Result;

// Well-known topic names
pub const TOPIC_ANNOUNCE: &str = "abzu/announce";
pub const TOPIC_CONTENT:  &str = "abzu/content";
pub const TOPIC_SLASH:    &str = "abzu/slash";

/// Return the heartbeat topic for a node whose first ID byte is `segment`
pub fn heartbeat_topic(segment: u8) -> IdentTopic {
    IdentTopic::new(format!("abzu/heartbeat/{:02x}", segment))
}

/// Return all 256 heartbeat topics (use when subscribing a gateway node)
pub fn all_heartbeat_topics() -> Vec<IdentTopic> {
    (0u8..=255).map(heartbeat_topic).collect()
}

/// Build a GossipSub configuration tuned for AbzuNet
pub fn default_gossipsub_config() -> Result<GossipsubConfig> {
    let config = ConfigBuilder::default()
        // Custom message ID: BLAKE3(source || seq) to deduplicate across reconnections
        .message_id_fn(|msg: &Message| {
            let mut hasher = DefaultHasher::new();
            if let Some(src) = &msg.source { src.hash(&mut hasher); }
            msg.sequence_number.hash(&mut hasher);
            msg.data.hash(&mut hasher);
            MessageId::from(hasher.finish().to_be_bytes().to_vec())
        })
        .validation_mode(ValidationMode::Strict)
        .heartbeat_interval(std::time::Duration::from_secs(1))
        .mesh_n(6)
        .mesh_n_low(4)
        .mesh_n_high(12)
        .gossip_lazy(6)
        .build()
        .map_err(|e| anyhow::anyhow!("GossipSub config error: {}", e))?;
    Ok(config)
}

/// Create a GossipSub behaviour authenticated with the local keypair
pub fn build_gossipsub(keypair: &Keypair) -> Result<GossipsubBehaviour> {
    let config = default_gossipsub_config()?;
    GossipsubBehaviour::new(MessageAuthenticity::Signed(keypair.clone()), config)
        .map_err(|e| anyhow::anyhow!("GossipSub init error: {}", e))
}
