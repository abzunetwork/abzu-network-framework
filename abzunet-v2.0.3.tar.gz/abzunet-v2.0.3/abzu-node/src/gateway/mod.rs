// abzu-node/src/gateway/mod.rs
//! HTTP Gateway for Web2 Compatibility - Phase 7: Application Layer
//!
//! Full API surface:
//!   GET  /                           AbzuNet Browser UI
//!   GET  /status                     Node status JSON
//!   GET  /abzu/:cid                  Retrieve content by CID
//!   POST /abzu/upload                Upload content, returns CID
//!   GET  /abzu/ls                    List stored CIDs
//!   GET  /abzu/peers                 Connected peer list
//!   GET  /abzuname/:name             Resolve ANS name → CID (local + DHT)
//!   POST /abzuname/:name/:cid        Register ANS name (local + DHT)
//!   GET  /abzu/messages              List inbox messages
//!   GET  /abzu/messages/:id          Get single message
//!   POST /abzu/messages/send         Send a DTN message
//!   DELETE /abzu/messages/:id        Delete inbox message

use anyhow::Result;
use axum::{
    body::Body,
    extract::{Path, State, Multipart},
    http::{header, HeaderMap, StatusCode},
    response::{Html, IntoResponse, Json, Response},
    routing::{delete, get, post},
    Router,
};
use serde::{Deserialize, Serialize};
use std::net::SocketAddr;
use std::sync::Arc;
use tower_http::cors::CorsLayer;

use crate::storage::{chunker::Chunker, store::ContentStore};
use crate::favor::FavorEngine;
use crate::dtn::{DtnQueue, DtnMessage};
use crate::network::SwarmHandle;

/// Shared gateway state (Arc-wrapped and passed to every handler)
pub struct GatewayState {
    pub store: Arc<ContentStore>,
    pub favor: Arc<FavorEngine>,
    pub node_id_hex: String,
    pub local_node_id: [u8; 32],
    pub listen_addrs: Vec<String>,
    pub ans_registry: Arc<AnsRegistry>,
    pub dtn: Arc<DtnQueue>,
    pub swarm: Option<SwarmHandle>,
    // v2.0.3: ANRS and LoRa handles
    pub anrs: Option<crate::anrs::AnrsHandle>,
    pub lora_stats: Option<Arc<tokio::sync::Mutex<crate::transport::LoraStats>>>,
}

/// Abzu Name System local registry (sled-backed)
pub struct AnsRegistry {
    db: sled::Db,
}

impl AnsRegistry {
    pub fn open(path: &str) -> Result<Self> {
        Ok(Self { db: sled::open(path)? })
    }

    pub fn register(&self, name: &str, root_cid: [u8; 32]) -> Result<()> {
        self.db.insert(name.as_bytes(), root_cid.as_slice())?;
        Ok(())
    }

    pub fn resolve(&self, name: &str) -> Result<Option<[u8; 32]>> {
        match self.db.get(name.as_bytes())? {
            Some(val) if val.len() == 32 => {
                let mut arr = [0u8; 32];
                arr.copy_from_slice(&val);
                Ok(Some(arr))
            }
            _ => Ok(None),
        }
    }

    pub fn list_names(&self) -> Result<Vec<(String, String)>> {
        let mut names = Vec::new();
        for item in self.db.iter() {
            let (k, v) = item?;
            if let (Ok(name), 32) = (std::str::from_utf8(&k), v.len()) {
                let mut arr = [0u8; 32];
                arr.copy_from_slice(&v);
                names.push((name.to_string(), hex::encode(arr)));
            }
        }
        Ok(names)
    }
}

/// Start the HTTP gateway
pub async fn start_gateway(
    bind_addr: SocketAddr,
    state: Arc<GatewayState>,
) -> Result<()> {
    let app = Router::new()
        .route("/", get(serve_ui))
        .route("/status", get(handle_status))
        .route("/abzu/:cid", get(handle_content_request))
        .route("/abzuname/:name", get(handle_ans_resolve))
        .route("/abzuname/:name/:cid", post(handle_ans_register))
        .route("/abzu/upload", post(handle_upload))
        .route("/abzu/ls", get(handle_list))
        .route("/abzu/peers", get(handle_peers))
        .route("/abzu/messages", get(handle_list_messages))
        .route("/abzu/messages/:id", get(handle_get_message))
        .route("/abzu/messages/:id", delete(handle_delete_message))
        .route("/abzu/messages/send", post(handle_send_message))
        // v2.0.3: ANRS endpoints
        .route("/anrs/status", get(handle_anrs_status))
        .route("/anrs/balance", get(handle_anrs_balance))
        .route("/anrs/withdraw", post(handle_anrs_withdraw))
        // v2.0.3: LoRa endpoints
        .route("/lora/status", get(handle_lora_status))
        .layer(CorsLayer::permissive())
        .with_state(state);

    tracing::info!("AbzuNet Gateway v2.0.3 on {}", bind_addr);
    axum::Server::bind(&bind_addr)
        .serve(app.into_make_service())
        .await?;
    Ok(())
}

// ─── Handlers ────────────────────────────────────────────────────────────────

async fn serve_ui() -> Html<&'static str> {
    Html(BROWSER_UI_HTML)
}

#[derive(Serialize)]
struct NodeStatus {
    node_id: String,
    version: &'static str,
    listen_addrs: Vec<String>,
    stored_objects: usize,
    disk_usage_bytes: u64,
    dtn_stats: serde_json::Value,
    blockchain_connected: bool,
}

async fn handle_status(State(state): State<Arc<GatewayState>>) -> impl IntoResponse {
    let stored = state.store.chunk_count().unwrap_or(0);
    let disk = state.store.size_on_disk().unwrap_or(0);
    let dtn_stats = state.dtn.stats()
        .map(|s| serde_json::to_value(s).unwrap_or_default())
        .unwrap_or_default();
    Json(NodeStatus {
        node_id: state.node_id_hex.clone(),
        version: "2.0.2",
        listen_addrs: state.listen_addrs.clone(),
        stored_objects: stored,
        disk_usage_bytes: disk,
        dtn_stats,
        blockchain_connected: false,
    })
}

async fn handle_content_request(
    Path(cid_hex): Path<String>,
    State(state): State<Arc<GatewayState>>,
) -> Response {
    let cid_bytes = match parse_cid(&cid_hex) {
        Ok(c) => c,
        Err(e) => return (StatusCode::BAD_REQUEST, e).into_response(),
    };

    // Try local store first
    match state.store.retrieve_file(&cid_bytes) {
        Ok(Some(data)) => return serve_bytes(data, &cid_hex),
        Ok(None) => {}
        Err(e) => return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }

    // Fall back to DHT provider lookup via swarm
    if let Some(swarm) = &state.swarm {
        let providers = swarm.find_providers(cid_bytes).await;
        if providers.is_empty() {
            return (StatusCode::NOT_FOUND, format!("CID {} not found locally or on network", cid_hex)).into_response();
        }
        // TODO: dial provider and fetch chunks via request-response protocol
        return (StatusCode::SERVICE_UNAVAILABLE,
            format!("CID {} found on {} remote provider(s) — remote fetch in progress", cid_hex, providers.len())
        ).into_response();
    }

    (StatusCode::NOT_FOUND, format!("CID {} not found", cid_hex)).into_response()
}

async fn handle_ans_resolve(
    Path(name): Path<String>,
    State(state): State<Arc<GatewayState>>,
) -> Response {
    // Check local registry first
    if let Ok(Some(cid)) = state.ans_registry.resolve(&name) {
        return Json(serde_json::json!({ "name": name, "cid": hex::encode(cid), "source": "local" })).into_response();
    }

    // Fall back to DHT lookup
    if let Some(swarm) = &state.swarm {
        if let Some(cid) = swarm.get_name(name.clone()).await {
            // Cache locally
            state.ans_registry.register(&name, cid).ok();
            return Json(serde_json::json!({ "name": name, "cid": hex::encode(cid), "source": "dht" })).into_response();
        }
    }

    (StatusCode::NOT_FOUND, format!("Name '{}' not registered", name)).into_response()
}

async fn handle_ans_register(
    Path((name, cid_hex)): Path<(String, String)>,
    State(state): State<Arc<GatewayState>>,
) -> Response {
    let cid_bytes = match parse_cid(&cid_hex) {
        Ok(c) => c,
        Err(e) => return (StatusCode::BAD_REQUEST, e).into_response(),
    };

    // Store locally
    if let Err(e) = state.ans_registry.register(&name, cid_bytes) {
        return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response();
    }

    // Propagate to DHT
    if let Some(swarm) = &state.swarm {
        swarm.put_name(name.clone(), cid_bytes);
    }

    Json(serde_json::json!({ "registered": true, "name": name, "cid": cid_hex, "dht": state.swarm.is_some() })).into_response()
}

#[derive(Serialize)]
struct UploadResponse {
    cid: String,
    chunks: usize,
    bytes: usize,
}

async fn handle_upload(
    State(state): State<Arc<GatewayState>>,
    mut multipart: Multipart,
) -> Response {
    while let Ok(Some(field)) = multipart.next_field().await {
        let data = match field.bytes().await {
            Ok(b) => b.to_vec(),
            Err(e) => return (StatusCode::BAD_REQUEST, e.to_string()).into_response(),
        };

        let chunker = Chunker::new();
        let (chunks, root_cid) = chunker.chunk_bytes(&data);
        let chunk_count = chunks.len();
        let total_bytes = data.len();

        if let Err(e) = state.store.store_file_chunks(&chunks, root_cid) {
            return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response();
        }

        // Announce content availability in Kademlia DHT
        if let Some(swarm) = &state.swarm {
            swarm.provide_content(root_cid);
        }

        return Json(UploadResponse {
            cid: hex::encode(root_cid),
            chunks: chunk_count,
            bytes: total_bytes,
        }).into_response();
    }
    (StatusCode::BAD_REQUEST, "No file provided").into_response()
}

async fn handle_list(State(state): State<Arc<GatewayState>>) -> Response {
    match state.store.list_root_cids() {
        Ok(cids) => Json(cids.iter()
            .map(|c| serde_json::json!({ "cid": hex::encode(c) }))
            .collect::<Vec<_>>()).into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

async fn handle_peers(State(state): State<Arc<GatewayState>>) -> Response {
    if let Some(swarm) = &state.swarm {
        let peers = swarm.get_peers().await;
        return Json(peers).into_response();
    }
    Json(serde_json::json!({ "peers": [], "swarm": "not running" })).into_response()
}

// ─── DTN / Messaging Handlers ─────────────────────────────────────────────────

async fn handle_list_messages(State(state): State<Arc<GatewayState>>) -> Response {
    match state.dtn.list_inbox() {
        Ok(messages) => {
            let items: Vec<_> = messages.iter().map(|m| serde_json::json!({
                "id": hex::encode(m.id),
                "from": hex::encode(m.from),
                "subject": m.subject,
                "created_at": m.created_at,
                "age_secs": m.age_secs(),
                "content_type": m.content_type,
                "size_bytes": m.body.len(),
            })).collect();
            Json(items).into_response()
        }
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

async fn handle_get_message(
    Path(id_hex): Path<String>,
    State(state): State<Arc<GatewayState>>,
) -> Response {
    let id_bytes = match hex::decode(&id_hex) {
        Ok(b) if b.len() == 32 => {
            let mut arr = [0u8; 32];
            arr.copy_from_slice(&b);
            arr
        }
        _ => return (StatusCode::BAD_REQUEST, "Invalid message ID").into_response(),
    };

    match state.dtn.get_message(&id_bytes) {
        Ok(Some(msg)) => Json(serde_json::json!({
            "id": hex::encode(msg.id),
            "from": hex::encode(msg.from),
            "to": hex::encode(msg.to),
            "subject": msg.subject,
            "body": String::from_utf8_lossy(&msg.body),
            "content_type": msg.content_type,
            "created_at": msg.created_at,
            "hops": msg.hops,
            "content_cid": msg.content_cid.map(hex::encode),
        })).into_response(),
        Ok(None) => (StatusCode::NOT_FOUND, "Message not found").into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

async fn handle_delete_message(
    Path(id_hex): Path<String>,
    State(state): State<Arc<GatewayState>>,
) -> Response {
    let id_bytes = match hex::decode(&id_hex) {
        Ok(b) if b.len() == 32 => { let mut arr = [0u8; 32]; arr.copy_from_slice(&b); arr }
        _ => return (StatusCode::BAD_REQUEST, "Invalid message ID").into_response(),
    };
    match state.dtn.delete_message(&id_bytes) {
        Ok(()) => Json(serde_json::json!({ "deleted": true })).into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

#[derive(Deserialize)]
struct SendMessageRequest {
    to_node_id: String,
    subject: String,
    body: String,
    content_type: Option<String>,
}

async fn handle_send_message(
    State(state): State<Arc<GatewayState>>,
    Json(req): Json<SendMessageRequest>,
) -> Response {
    let to_bytes = match hex::decode(&req.to_node_id) {
        Ok(b) if b.len() == 32 => { let mut arr = [0u8; 32]; arr.copy_from_slice(&b); arr }
        _ => return (StatusCode::BAD_REQUEST, "Invalid recipient node ID (must be 64 hex chars)").into_response(),
    };

    let content_type = req.content_type.unwrap_or_else(|| "text/plain".to_string());
    match state.dtn.send(to_bytes, req.subject, req.body.into_bytes(), &content_type) {
        Ok(msg) => {
            // Publish to GossipSub for immediate delivery if recipient is reachable
            if let Some(swarm) = &state.swarm {
                if let Ok(bytes) = bincode::serialize(&msg) {
                    swarm.publish("abzu/dtn", bytes);
                }
            }
            Json(serde_json::json!({
                "sent": true,
                "message_id": hex::encode(msg.id),
                "queued_for_delivery": true,
            })).into_response()
        }
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

fn parse_cid(hex: &str) -> Result<[u8; 32], String> {
    let bytes = hex::decode(hex).map_err(|_| "CID must be hex-encoded".to_string())?;
    if bytes.len() != 32 { return Err("CID must be exactly 32 bytes (64 hex chars)".to_string()); }
    let mut arr = [0u8; 32];
    arr.copy_from_slice(&bytes);
    Ok(arr)
}

fn serve_bytes(data: Vec<u8>, filename: &str) -> Response {
    let mime = mime_guess::from_path(filename).first_or_octet_stream().to_string();
    let mut headers = HeaderMap::new();
    headers.insert(header::CONTENT_TYPE, mime.parse().unwrap());
    (StatusCode::OK, headers, data).into_response()
}

// ─── Browser UI (v2.0.2 — with Messaging tab) ────────────────────────────────

static BROWSER_UI_HTML: &str = r#"<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AbzuNet Browser v2.0.2 — SynthicSoft Labs</title>
  <style>
    :root {
      --teal: #19e3c8; --teal-dim: #0fa89a;
      --bg: #07090f; --panel: #0d1220; --border: #1a2540;
      --text: #d0dbe8; --muted: #6a7a8a; --danger: #ff4757; --warn: #ffa502;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }

    #topbar { display: flex; align-items: center; gap: 12px; background: var(--panel); border-bottom: 1px solid var(--border); padding: 10px 20px; position: sticky; top: 0; z-index: 100; }
    #logo { color: var(--teal); font-weight: 800; font-size: 1.1rem; letter-spacing: 1px; white-space: nowrap; }
    #logo span { color: #fff; }
    #logo small { font-size: .65rem; color: var(--muted); display: block; font-weight: 400; letter-spacing: 0; }
    #address-bar { flex: 1; display: flex; gap: 8px; }
    #address-input { flex: 1; background: var(--bg); border: 1px solid var(--border); border-radius: 6px; color: var(--text); font-size: .95rem; padding: 8px 14px; outline: none; transition: border-color .2s; }
    #address-input:focus { border-color: var(--teal); }
    #address-input::placeholder { color: var(--muted); }
    button { background: var(--teal); color: #07090f; border: none; border-radius: 6px; font-weight: 700; padding: 8px 18px; cursor: pointer; font-size: .9rem; transition: background .15s; }
    button:hover { background: var(--teal-dim); }
    button.secondary { background: var(--border); color: var(--text); }
    button.secondary:hover { background: #253050; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--teal); display: inline-block; margin-right: 5px; animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100%{opacity:1}50%{opacity:.4} }

    #layout { display: grid; grid-template-columns: 220px 1fr; min-height: calc(100vh - 54px); }
    #sidebar { background: var(--panel); border-right: 1px solid var(--border); padding: 16px 12px; display: flex; flex-direction: column; gap: 6px; }
    .sidebar-section { font-size: .7rem; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; margin: 10px 0 5px; }
    .nav-item { padding: 7px 11px; border-radius: 6px; cursor: pointer; font-size: .88rem; display: flex; align-items: center; gap: 8px; transition: background .15s; color: var(--text); }
    .nav-item:hover { background: rgba(25,227,200,.08); }
    .nav-item.active { background: rgba(25,227,200,.15); color: var(--teal); font-weight: 600; }

    #main { padding: 22px; overflow-y: auto; }
    .page { display: none; }
    .page.active { display: block; }
    h2 { color: var(--teal); font-size: 1.25rem; margin-bottom: 16px; }
    h3 { font-size: .95rem; color: #9ab; margin-bottom: 10px; font-weight: 600; }
    .card { background: var(--panel); border: 1px solid var(--border); border-radius: 10px; padding: 18px; margin-bottom: 16px; }

    .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; margin-bottom: 18px; }
    .stat-card { background: var(--panel); border: 1px solid var(--border); border-radius: 8px; padding: 14px; text-align: center; }
    .stat-val { font-size: 1.6rem; font-weight: 800; color: var(--teal); }
    .stat-lbl { font-size: .73rem; color: var(--muted); margin-top: 3px; }

    #content-display { background: var(--bg); border: 1px solid var(--border); border-radius: 8px; min-height: 180px; padding: 16px; font-family: monospace; white-space: pre-wrap; font-size: .88rem; max-height: 55vh; overflow-y: auto; }
    #content-display img { max-width: 100%; border-radius: 6px; }
    #content-display.loading { color: var(--muted); font-style: italic; }

    #drop-zone { border: 2px dashed var(--border); border-radius: 10px; padding: 36px; text-align: center; cursor: pointer; transition: border-color .2s, background .2s; margin-bottom: 14px; }
    #drop-zone.dragover { border-color: var(--teal); background: rgba(25,227,200,.05); }
    #drop-zone .dz-icon { font-size: 2.2rem; margin-bottom: 8px; }
    #file-input { display: none; }

    .cid-list { display: flex; flex-direction: column; gap: 7px; }
    .cid-item { background: var(--bg); border: 1px solid var(--border); border-radius: 6px; padding: 9px 12px; display: flex; align-items: center; gap: 8px; font-family: monospace; font-size: .8rem; }
    .cid-hash { flex: 1; color: var(--teal); word-break: break-all; }
    .mini-btn { background: var(--border); color: var(--text); border: none; border-radius: 4px; padding: 4px 9px; cursor: pointer; font-size: .75rem; }
    .mini-btn:hover { background: var(--teal); color: #07090f; }

    .ans-row { display: grid; grid-template-columns: 1fr 2fr auto; gap: 8px; align-items: start; margin-bottom: 14px; }
    input[type="text"], textarea { background: var(--bg); border: 1px solid var(--border); border-radius: 6px; color: var(--text); font-size: .88rem; padding: 7px 11px; outline: none; width: 100%; transition: border-color .2s; }
    input[type="text"]:focus, textarea:focus { border-color: var(--teal); }
    textarea { resize: vertical; min-height: 80px; font-family: monospace; }

    /* Messaging */
    .msg-item { background: var(--bg); border: 1px solid var(--border); border-radius: 8px; padding: 12px 16px; margin-bottom: 8px; cursor: pointer; transition: border-color .2s; }
    .msg-item:hover { border-color: var(--teal); }
    .msg-from { font-family: monospace; font-size: .75rem; color: var(--muted); }
    .msg-subject { font-weight: 600; color: var(--text); margin: 4px 0 2px; }
    .msg-age { font-size: .73rem; color: var(--muted); }
    .msg-body { background: var(--bg); border: 1px solid var(--border); border-radius: 6px; padding: 14px; font-family: monospace; white-space: pre-wrap; font-size: .87rem; max-height: 300px; overflow-y: auto; }
    .send-form { display: grid; gap: 10px; }

    /* Peers */
    .peer-row { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid var(--border); }
    .peer-dot { width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0; }
    .peer-dot.alive { background: var(--teal); }
    .peer-id { font-family: monospace; font-size: .8rem; flex: 1; }
    .peer-meta { font-size: .75rem; color: var(--muted); }

    #log-panel { background: #040608; border: 1px solid var(--border); border-radius: 8px; padding: 12px; font-family: monospace; font-size: .78rem; height: 180px; overflow-y: auto; color: #7acc9a; }
    .log-err { color: var(--danger); }
    .log-warn { color: var(--warn); }

    #toast { position: fixed; bottom: 22px; right: 22px; background: var(--panel); border: 1px solid var(--teal); border-radius: 8px; padding: 10px 18px; font-size: .85rem; z-index: 9999; transform: translateY(70px); opacity: 0; transition: all .3s; }
    #toast.show { transform: translateY(0); opacity: 1; }
    #toast.err { border-color: var(--danger); }
  </style>
</head>
<body>

<div id="topbar">
  <div id="logo">ABZU<span>NET</span><small>v2.0.2 · SynthicSoft Labs</small></div>
  <div id="address-bar">
    <input id="address-input" type="text" placeholder="abzu://cid  or  abzuname://sitename  or  abzudtn://nodeId" />
    <button onclick="handleAddressBar()">Go</button>
    <button class="secondary" onclick="showPage('upload')">↑ Upload</button>
  </div>
  <span style="color:var(--muted);font-size:.78rem;white-space:nowrap"><span class="dot"></span>Active</span>
</div>

<div id="layout">
  <div id="sidebar">
    <div class="sidebar-section">Browse</div>
    <div class="nav-item active" onclick="showPage('home')" data-page="home">⌂ Home</div>
    <div class="nav-item" onclick="showPage('browse')" data-page="browse">◈ Retrieve Content</div>
    <div class="nav-item" onclick="showPage('upload')" data-page="upload">↑ Upload</div>
    <div class="sidebar-section">Network</div>
    <div class="nav-item" onclick="showPage('ans')" data-page="ans">⊛ Name System (ANS)</div>
    <div class="nav-item" onclick="showPage('messages')" data-page="messages">✉ Messages</div>
    <div class="nav-item" onclick="showPage('peers')" data-page="peers">◉ Peers</div>
    <div class="sidebar-section">Node</div>
    <div class="nav-item" onclick="showPage('stored')" data-page="stored">▤ Stored Objects</div>
    <div class="nav-item" onclick="showPage('status')" data-page="status">◎ Node Status</div>
  </div>

  <div id="main">

    <!-- Home -->
    <div id="page-home" class="page active">
      <h2>AbzuNet Browser</h2>
      <p style="color:var(--muted);margin-bottom:18px;line-height:1.7">A resilient, decentralized information network operational with or without internet access. Content is addressed by BLAKE3 hash and routed via Kademlia DHT. Messages are stored and forwarded via the DTN layer.</p>
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-val" id="h-node">…</div><div class="stat-lbl">Node ID (prefix)</div></div>
        <div class="stat-card"><div class="stat-val" id="h-objects">…</div><div class="stat-lbl">Stored Objects</div></div>
        <div class="stat-card"><div class="stat-val" id="h-disk">…</div><div class="stat-lbl">Disk Usage</div></div>
        <div class="stat-card"><div class="stat-val" id="h-inbox">…</div><div class="stat-lbl">Inbox Messages</div></div>
      </div>
      <div class="card">
        <h3>Quick Actions</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button onclick="showPage('browse')">Retrieve Content</button>
          <button class="secondary" onclick="showPage('upload')">Upload</button>
          <button class="secondary" onclick="showPage('messages')">Messages</button>
          <button class="secondary" onclick="showPage('ans')">Name System</button>
        </div>
      </div>
      <div class="card"><h3>Network Log</h3><div id="log-panel"></div></div>
    </div>

    <!-- Browse -->
    <div id="page-browse" class="page">
      <h2>Retrieve Content</h2>
      <div class="card">
        <h3>By CID</h3>
        <div style="display:flex;gap:8px;margin-bottom:12px">
          <input type="text" id="browse-cid" placeholder="64-char hex CID…" style="flex:1" />
          <button onclick="retrieveContent()">Retrieve</button>
        </div>
        <div id="content-display" class="loading">Enter a CID above to retrieve content.</div>
      </div>
    </div>

    <!-- Upload -->
    <div id="page-upload" class="page">
      <h2>Upload Content</h2>
      <div class="card">
        <div id="drop-zone" onclick="document.getElementById('file-input').click()"
             ondragover="event.preventDefault();this.classList.add('dragover')"
             ondragleave="this.classList.remove('dragover')"
             ondrop="handleDrop(event)">
          <div class="dz-icon">⬆</div>
          <div style="font-size:1rem;margin-bottom:5px">Drop files here or click to select</div>
          <div style="color:var(--muted);font-size:.85rem">Chunked into 4MB segments · BLAKE3-addressed · CID returned for sharing</div>
        </div>
        <input type="file" id="file-input" multiple onchange="handleFileSelect(event)" />
        <div id="upload-result" style="display:none;margin-top:12px">
          <h3>Upload Complete</h3>
          <div id="upload-cid" style="font-family:monospace;color:var(--teal);word-break:break-all;font-size:.88rem"></div>
          <div id="upload-meta" style="color:var(--muted);font-size:.78rem;margin-top:4px"></div>
          <div style="display:flex;gap:8px;margin-top:10px">
            <button onclick="copyUploadCid()" class="secondary">Copy CID</button>
            <button onclick="registerAfterUpload()" class="secondary">Register Name →</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ANS -->
    <div id="page-ans" class="page">
      <h2>Abzu Name System</h2>
      <div class="card">
        <h3>Register Name</h3>
        <div class="ans-row">
          <input type="text" id="ans-name" placeholder="sitename" />
          <input type="text" id="ans-cid" placeholder="64-char CID" />
          <button onclick="registerAns()">Register</button>
        </div>
        <h3>Resolve Name</h3>
        <div style="display:flex;gap:8px">
          <input type="text" id="ans-resolve" placeholder="sitename" style="flex:1" />
          <button onclick="resolveAns()">Resolve</button>
        </div>
        <div id="ans-result" style="display:none;margin-top:10px;font-family:monospace;font-size:.85rem;color:var(--teal)"></div>
      </div>
    </div>

    <!-- Messages -->
    <div id="page-messages" class="page">
      <h2>Messages</h2>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <div>
          <div class="card">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
              <h3 style="margin:0">Inbox</h3>
              <button class="secondary" style="padding:4px 10px;font-size:.78rem" onclick="loadMessages()">Refresh</button>
            </div>
            <div id="msg-list"><div style="color:var(--muted)">Loading…</div></div>
          </div>
          <div class="card">
            <h3>Compose</h3>
            <div class="send-form">
              <input type="text" id="msg-to" placeholder="Recipient Node ID (64 hex chars)" />
              <input type="text" id="msg-subject" placeholder="Subject" />
              <textarea id="msg-body" placeholder="Message body…"></textarea>
              <button onclick="sendMessage()">Send via DTN</button>
            </div>
          </div>
        </div>
        <div id="msg-view-panel">
          <div class="card" style="color:var(--muted);text-align:center;padding:40px">Select a message to read it</div>
        </div>
      </div>
    </div>

    <!-- Peers -->
    <div id="page-peers" class="page">
      <h2>Connected Peers</h2>
      <div class="card">
        <div style="display:flex;justify-content:space-between;margin-bottom:10px">
          <h3 style="margin:0">Swarm Peers</h3>
          <button class="secondary" style="padding:4px 10px;font-size:.78rem" onclick="loadPeers()">Refresh</button>
        </div>
        <div id="peer-list"><div style="color:var(--muted)">Loading…</div></div>
      </div>
    </div>

    <!-- Stored Objects -->
    <div id="page-stored" class="page">
      <h2>Stored Objects</h2>
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <h3 style="margin:0">Local Content Store</h3>
          <button class="secondary" onclick="loadStored()">Refresh</button>
        </div>
        <div id="cid-list" class="cid-list"><div style="color:var(--muted)">Loading…</div></div>
      </div>
    </div>

    <!-- Status -->
    <div id="page-status" class="page">
      <h2>Node Status</h2>
      <div class="card">
        <pre id="status-json" style="font-family:monospace;font-size:.83rem;color:var(--teal);white-space:pre-wrap">Loading…</pre>
      </div>
    </div>

  </div>
</div>

<div id="toast"></div>

<script>
let currentUploadCid = '';
const $ = id => document.getElementById(id);

const log = (msg, level='') => {
  const p = $('log-panel'); if (!p) return;
  const d = document.createElement('div');
  d.className = level ? 'log-'+level : '';
  d.textContent = `[${new Date().toTimeString().slice(0,8)}] ${msg}`;
  p.appendChild(d); p.scrollTop = p.scrollHeight;
};
const toast = (msg, err=false) => {
  const t = $('toast'); t.textContent = msg;
  t.className = 'show' + (err ? ' err' : '');
  setTimeout(() => t.className='', 3200);
};

function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  $('page-'+name)?.classList.add('active');
  document.querySelector(`[data-page="${name}"]`)?.classList.add('active');
  if (name==='status') loadStatus();
  if (name==='stored') loadStored();
  if (name==='peers') loadPeers();
  if (name==='messages') loadMessages();
}

function handleAddressBar() {
  const raw = $('address-input').value.trim();
  if (raw.startsWith('abzuname://')) {
    const name = raw.replace('abzuname://','').split('/')[0];
    $('ans-resolve').value = name; showPage('ans'); resolveAns();
  } else if (raw.startsWith('abzudtn://')) {
    const nid = raw.replace('abzudtn://','');
    $('msg-to').value = nid; showPage('messages');
  } else {
    const cid = raw.replace('abzu://','').split('/')[0];
    if (cid.length===64) { $('browse-cid').value=cid; showPage('browse'); retrieveContent(); }
    else toast('Invalid address',true);
  }
}

const fmt = b => { if(!b) return '0 B'; const k=1024,s=['B','KB','MB','GB','TB'],i=Math.floor(Math.log(b)/Math.log(k)); return (b/Math.pow(k,i)).toFixed(1)+' '+s[i]; };

async function loadStatus() {
  try {
    const d = await fetch('/status').then(r=>r.json());
    $('status-json').textContent = JSON.stringify(d,null,2);
    $('h-node').textContent = (d.node_id||'').slice(0,8)+'…';
    $('h-objects').textContent = d.stored_objects??'—';
    $('h-disk').textContent = fmt(d.disk_usage_bytes??0);
    $('h-inbox').textContent = d.dtn_stats?.inbox_count??'—';
    log(`Status: ${d.stored_objects} objects · ${fmt(d.disk_usage_bytes)} · DHT: ${d.blockchain_connected?'on':'off'}`);
  } catch(e) { log('Status error: '+e.message,'err'); }
}

async function retrieveContent() {
  const cid = $('browse-cid').value.trim();
  if (!cid||cid.length!==64) { toast('Enter a 64-char CID',true); return; }
  const d = $('content-display');
  d.className='loading'; d.textContent='Retrieving '+cid+'…';
  log('Fetching: '+cid);
  try {
    const r = await fetch('/abzu/'+cid);
    if (!r.ok) throw new Error(`${r.status}: ${await r.text()}`);
    const ct = r.headers.get('content-type')||'';
    d.className='';
    if (ct.startsWith('image/')) { const url=URL.createObjectURL(await r.blob()); d.innerHTML=`<img src="${url}"/>`; }
    else if (ct.startsWith('text/')||ct.includes('json')) d.textContent=await r.text();
    else { const buf=await r.arrayBuffer(); d.textContent=`Binary: ${fmt(buf.byteLength)}\nType: ${ct}`; }
    log('Retrieved '+cid);
  } catch(e) { d.className='loading'; d.textContent='Error: '+e.message; toast(e.message,true); }
}

function handleDrop(e) { e.preventDefault(); $('drop-zone').classList.remove('dragover'); if(e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]); }
function handleFileSelect(e) { if(e.target.files[0]) uploadFile(e.target.files[0]); }

async function uploadFile(file) {
  toast(`Uploading ${file.name}…`);
  log(`Upload: ${file.name} (${fmt(file.size)})`);
  const fd = new FormData(); fd.append('file',file);
  try {
    const r = await fetch('/abzu/upload',{method:'POST',body:fd});
    if (!r.ok) throw new Error(await r.text());
    const d = await r.json();
    currentUploadCid = d.cid;
    $('upload-result').style.display='block';
    $('upload-cid').textContent = d.cid;
    $('upload-meta').textContent = `${d.chunks} chunk(s) · ${fmt(d.bytes)} · Announced to DHT`;
    $('ans-cid').value = d.cid;
    log(`Uploaded: ${d.cid}`); toast('Upload complete!');
  } catch(e) { log('Upload error: '+e.message,'err'); toast(e.message,true); }
}
function copyUploadCid() { navigator.clipboard.writeText(currentUploadCid).then(()=>toast('CID copied!')); }
function registerAfterUpload() { $('ans-name').value=''; showPage('ans'); }

async function registerAns() {
  const name=$('ans-name').value.trim(), cid=$('ans-cid').value.trim();
  if (!name||cid.length!==64) { toast('Enter name and valid CID',true); return; }
  try {
    const r = await fetch(`/abzuname/${name}/${cid}`,{method:'POST'});
    if (!r.ok) throw new Error(await r.text());
    const d = await r.json();
    toast(`Registered: ${name}${d.dht?' (propagated to DHT)':''}`);
    log(`ANS: ${name} → ${cid}${d.dht?' [DHT]':''}`);
  } catch(e) { toast(e.message,true); }
}

async function resolveAns() {
  const name=$('ans-resolve').value.trim();
  if (!name) { toast('Enter a name',true); return; }
  const el=$('ans-result');
  try {
    const r=await fetch(`/abzuname/${name}`);
    if (!r.ok) throw new Error(`'${name}' not found`);
    const d=await r.json();
    el.style.display='block'; el.style.color='var(--teal)';
    el.textContent=`${d.name}  →  ${d.cid}  [${d.source}]`;
    log(`Resolved: ${d.name} → ${d.cid} (${d.source})`);
  } catch(e) { el.style.display='block'; el.style.color='var(--danger)'; el.textContent=e.message; }
}

async function loadMessages() {
  const list=$('msg-list');
  list.innerHTML='<div style="color:var(--muted)">Loading…</div>';
  try {
    const msgs=await fetch('/abzu/messages').then(r=>r.json());
    if (!msgs.length) { list.innerHTML='<div style="color:var(--muted)">Inbox is empty.</div>'; return; }
    list.innerHTML='';
    for (const m of msgs) {
      const item=document.createElement('div'); item.className='msg-item';
      const age = m.age_secs < 60 ? m.age_secs+'s ago' : m.age_secs<3600 ? Math.floor(m.age_secs/60)+'m ago' : Math.floor(m.age_secs/3600)+'h ago';
      item.innerHTML=`<div class="msg-from">From: ${m.from.slice(0,16)}…</div><div class="msg-subject">${m.subject||'(no subject)'}</div><div class="msg-age">${age} · ${m.size_bytes} bytes</div>`;
      item.onclick=()=>viewMessage(m.id);
      list.appendChild(item);
    }
  } catch(e) { list.innerHTML=`<div style="color:var(--danger)">${e.message}</div>`; }
}

async function viewMessage(id) {
  const panel=$('msg-view-panel');
  try {
    const m=await fetch(`/abzu/messages/${id}`).then(r=>r.json());
    panel.innerHTML=`<div class="card">
      <div style="margin-bottom:12px">
        <div style="font-size:.8rem;color:var(--muted)">From: ${m.from}</div>
        <div style="font-size:.8rem;color:var(--muted)">To: ${m.to}</div>
        <div style="font-weight:700;font-size:1rem;margin:6px 0">${m.subject||'(no subject)'}</div>
      </div>
      <div class="msg-body">${m.body||''}</div>
      <div style="display:flex;gap:8px;margin-top:12px">
        <button class="secondary" onclick="replyTo('${m.from}','${(m.subject||'').replace(/'/g,"\\'")}')">Reply</button>
        <button class="secondary" style="background:var(--danger);color:#fff" onclick="deleteMsg('${id}')">Delete</button>
      </div>
    </div>`;
  } catch(e) { panel.innerHTML=`<div class="card" style="color:var(--danger)">${e.message}</div>`; }
}

function replyTo(nodeId, subject) {
  $('msg-to').value=nodeId;
  $('msg-subject').value=subject.startsWith('Re: ')?subject:'Re: '+subject;
  $('msg-body').focus();
}

async function deleteMsg(id) {
  await fetch(`/abzu/messages/${id}`,{method:'DELETE'});
  toast('Deleted'); loadMessages();
  $('msg-view-panel').innerHTML='<div class="card" style="color:var(--muted);text-align:center;padding:40px">Deleted</div>';
}

async function sendMessage() {
  const to=$('msg-to').value.trim(), subj=$('msg-subject').value.trim(), body=$('msg-body').value.trim();
  if (to.length!==64) { toast('Recipient must be a 64-char Node ID',true); return; }
  try {
    const r=await fetch('/abzu/messages/send',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to_node_id:to,subject:subj,body})
    });
    if (!r.ok) throw new Error(await r.text());
    const d=await r.json();
    toast('Message queued: '+d.message_id.slice(0,12)+'…');
    log(`DTN sent: ${d.message_id}`);
    $('msg-subject').value=''; $('msg-body').value='';
    loadMessages();
  } catch(e) { toast(e.message,true); }
}

async function loadPeers() {
  const list=$('peer-list');
  try {
    const peers=await fetch('/abzu/peers').then(r=>r.json());
    if (Array.isArray(peers)&&peers.length) {
      list.innerHTML=peers.map(p=>`<div class="peer-row">
        <div class="peer-dot alive"></div>
        <div class="peer-id">${p.peer_id}</div>
        <div class="peer-meta">${p.ping_ms!=null?p.ping_ms+'ms':''} ${p.health||''}</div>
      </div>`).join('');
    } else {
      list.innerHTML='<div style="color:var(--muted)">No peers connected. Running on local mesh.</div>';
    }
  } catch(e) { list.innerHTML=`<div style="color:var(--danger)">${e.message}</div>`; }
}

async function loadStored() {
  const list=$('cid-list');
  list.innerHTML='<div style="color:var(--muted)">Loading…</div>';
  try {
    const items=await fetch('/abzu/ls').then(r=>r.json());
    if (!items.length) { list.innerHTML='<div style="color:var(--muted)">No objects stored locally.</div>'; return; }
    list.innerHTML='';
    for (const item of items) {
      const row=document.createElement('div'); row.className='cid-item';
      row.innerHTML=`<div class="cid-hash">${item.cid}</div>
        <div style="display:flex;gap:5px">
          <button class="mini-btn" onclick="openCid('${item.cid}')">View</button>
          <button class="mini-btn" onclick="navigator.clipboard.writeText('${item.cid}').then(()=>toast('Copied!'))">Copy</button>
        </div>`;
      list.appendChild(row);
    }
    log(`${items.length} stored object(s)`);
  } catch(e) { list.innerHTML=`<div style="color:var(--danger)">${e.message}</div>`; }
}

function openCid(cid) { $('browse-cid').value=cid; showPage('browse'); retrieveContent(); }

window.addEventListener('DOMContentLoaded', ()=>{
  log('AbzuNet Browser v2.0.2 ready');
  log('Swarm: libp2p QUIC + TCP + Kademlia DHT + GossipSub');
  log('Storage: BLAKE3 CAS + Bao streaming verification');
  log('Messaging: DTN vector-clock store-and-forward');
  loadStatus();
});
</script>
</body>
</html>"#;
//!
//! Provides a local HTTP server that serves as the user's interface to AbzuNet.
//! Acts as the equivalent of a web browser's "address bar resolver":
//!   GET /abzu/{cid}          - Retrieve content by root CID
//!   GET /abzuname/{name}     - Resolve an Abzu Name System name
//!   POST /abzu/upload        - Upload content and receive a CID
//!   GET /abzu/ls             - List locally stored CIDs
//!   GET /abzu/peers          - Current peer list and health
//!   GET /                    - Serve the AbzuNet browser UI
//!   GET /status              - Node status JSON

use anyhow::Result;
use axum::{
    body::Body,
    extract::{Path, State, Multipart},
    http::{header, HeaderMap, StatusCode},
    response::{Html, IntoResponse, Json, Response},
    routing::{get, post},
    Router,
};
use serde::{Deserialize, Serialize};
use std::net::SocketAddr;
use std::sync::Arc;
use tower_http::cors::CorsLayer;

use crate::storage::{chunker::Chunker, store::ContentStore};
use crate::favor::{FavorEngine, HealthState};

/// Shared gateway state
pub struct GatewayState {
    pub store: Arc<ContentStore>,
    pub favor: Arc<FavorEngine>,
    pub node_id_hex: String,
    pub listen_addrs: Vec<String>,
    pub ans_registry: Arc<AnsRegistry>,
}

/// Abzu Name System - maps human-readable names to root CIDs
/// In a production deployment this lives in the DHT or a smart contract.
/// Here we keep an in-memory registry that syncs with sled for persistence.
pub struct AnsRegistry {
    db: sled::Db,
}

impl AnsRegistry {
    pub fn open(path: &str) -> Result<Self> {
        Ok(Self { db: sled::open(path)? })
    }

    pub fn register(&self, name: &str, root_cid: [u8; 32]) -> Result<()> {
        self.db.insert(name.as_bytes(), root_cid.as_slice())?;
        Ok(())
    }

    pub fn resolve(&self, name: &str) -> Result<Option<[u8; 32]>> {
        match self.db.get(name.as_bytes())? {
            Some(val) if val.len() == 32 => {
                let mut arr = [0u8; 32];
                arr.copy_from_slice(&val);
                Ok(Some(arr))
            }
            _ => Ok(None),
        }
    }

    pub fn list_names(&self) -> Result<Vec<(String, String)>> {
        let mut names = Vec::new();
        for item in self.db.iter() {
            let (k, v) = item?;
            if let (Ok(name), 32) = (std::str::from_utf8(&k), v.len()) {
                let mut arr = [0u8; 32];
                arr.copy_from_slice(&v);
                names.push((name.to_string(), hex::encode(arr)));
            }
        }
        Ok(names)
    }
}

/// Start the gateway HTTP server
pub async fn start_gateway(
    bind_addr: SocketAddr,
    state: Arc<GatewayState>,
) -> Result<()> {
    let app = Router::new()
        .route("/", get(serve_ui))
        .route("/status", get(handle_status))
        .route("/abzu/:cid", get(handle_content_request))
        .route("/abzuname/:name", get(handle_ans_resolve))
        .route("/abzuname/:name/:cid", post(handle_ans_register))
        .route("/abzu/upload", post(handle_upload))
        .route("/abzu/ls", get(handle_list))
        .route("/abzu/peers", get(handle_peers))
        .layer(CorsLayer::permissive())
        .with_state(state);

    tracing::info!("AbzuNet Gateway listening on {}", bind_addr);

    axum::Server::bind(&bind_addr)
        .serve(app.into_make_service())
        .await?;

    Ok(())
}

// ─── Handlers ────────────────────────────────────────────────────────────────

async fn serve_ui() -> Html<&'static str> {
    Html(BROWSER_UI_HTML)
}

#[derive(Serialize)]
struct NodeStatus {
    node_id: String,
    version: &'static str,
    listen_addrs: Vec<String>,
    stored_objects: usize,
    disk_usage_bytes: u64,
}

async fn handle_status(State(state): State<Arc<GatewayState>>) -> impl IntoResponse {
    let stored = state.store.chunk_count().unwrap_or(0);
    let disk = state.store.size_on_disk().unwrap_or(0);

    Json(NodeStatus {
        node_id: state.node_id_hex.clone(),
        version: "2.0.2",
        listen_addrs: state.listen_addrs.clone(),
        stored_objects: stored,
        disk_usage_bytes: disk,
    })
}

async fn handle_content_request(
    Path(cid_hex): Path<String>,
    State(state): State<Arc<GatewayState>>,
) -> Response {
    let cid_bytes = match hex::decode(&cid_hex) {
        Ok(b) if b.len() == 32 => {
            let mut arr = [0u8; 32];
            arr.copy_from_slice(&b);
            arr
        }
        _ => {
            return (StatusCode::BAD_REQUEST, "Invalid CID: must be 64 hex chars").into_response();
        }
    };

    match state.store.retrieve_file(&cid_bytes) {
        Ok(Some(data)) => {
            let mime = mime_guess::from_path(&cid_hex)
                .first_or_octet_stream()
                .to_string();
            let mut headers = HeaderMap::new();
            headers.insert(header::CONTENT_TYPE, mime.parse().unwrap());
            headers.insert(
                header::CONTENT_DISPOSITION,
                format!("inline; filename=\"{}\"", cid_hex).parse().unwrap(),
            );
            (StatusCode::OK, headers, data).into_response()
        }
        Ok(None) => (StatusCode::NOT_FOUND, format!("CID {} not found locally", cid_hex)).into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

async fn handle_ans_resolve(
    Path(name): Path<String>,
    State(state): State<Arc<GatewayState>>,
) -> Response {
    match state.ans_registry.resolve(&name) {
        Ok(Some(cid)) => {
            Json(serde_json::json!({
                "name": name,
                "cid": hex::encode(cid),
            })).into_response()
        }
        Ok(None) => (StatusCode::NOT_FOUND, format!("Name '{}' not registered", name)).into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

async fn handle_ans_register(
    Path((name, cid_hex)): Path<(String, String)>,
    State(state): State<Arc<GatewayState>>,
) -> Response {
    let cid_bytes = match hex::decode(&cid_hex) {
        Ok(b) if b.len() == 32 => {
            let mut arr = [0u8; 32];
            arr.copy_from_slice(&b);
            arr
        }
        _ => return (StatusCode::BAD_REQUEST, "Invalid CID").into_response(),
    };

    match state.ans_registry.register(&name, cid_bytes) {
        Ok(()) => Json(serde_json::json!({"registered": true, "name": name, "cid": cid_hex})).into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

#[derive(Serialize)]
struct UploadResponse {
    cid: String,
    chunks: usize,
    bytes: usize,
}

async fn handle_upload(
    State(state): State<Arc<GatewayState>>,
    mut multipart: Multipart,
) -> Response {
    while let Ok(Some(field)) = multipart.next_field().await {
        let data = match field.bytes().await {
            Ok(b) => b.to_vec(),
            Err(e) => return (StatusCode::BAD_REQUEST, e.to_string()).into_response(),
        };

        let chunker = Chunker::new();
        let (chunks, root_cid) = chunker.chunk_bytes(&data);
        let chunk_count = chunks.len();
        let total_bytes = data.len();

        if let Err(e) = state.store.store_file_chunks(&chunks, root_cid) {
            return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response();
        }

        return Json(UploadResponse {
            cid: hex::encode(root_cid),
            chunks: chunk_count,
            bytes: total_bytes,
        }).into_response();
    }

    (StatusCode::BAD_REQUEST, "No file provided").into_response()
}

#[derive(Serialize)]
struct ListEntry {
    cid: String,
}

async fn handle_list(State(state): State<Arc<GatewayState>>) -> Response {
    match state.store.list_root_cids() {
        Ok(cids) => {
            let entries: Vec<ListEntry> = cids
                .iter()
                .map(|c| ListEntry { cid: hex::encode(c) })
                .collect();
            Json(entries).into_response()
        }
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
    }
}

async fn handle_peers(State(state): State<Arc<GatewayState>>) -> Response {
    // In a full implementation this would query the swarm's peer store.
    // For now we return status information about the favor engine.
    Json(serde_json::json!({
        "message": "Peer list available via swarm event stream",
        "favor_engine": "active",
    })).into_response()
}

// ─── Embedded Browser UI ─────────────────────────────────────────────────────

/// Full AbzuNet Browser UI - the user interface for the post-internet network.
/// This is the "web browser" for AbzuNet: address bar, content viewer, uploader,
/// ANS registry, peer status, and network dashboard all in one self-contained page.
static BROWSER_UI_HTML: &str = r#"<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AbzuNet Browser — SynthicSoft Labs</title>
  <style>
    :root {
      --teal: #19e3c8;
      --teal-dim: #0fa89a;
      --bg: #07090f;
      --panel: #0d1220;
      --border: #1a2540;
      --text: #d0dbe8;
      --muted: #6a7a8a;
      --danger: #ff4757;
      --warn: #ffa502;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }

    /* ── Top Bar ── */
    #topbar {
      display: flex; align-items: center; gap: 12px;
      background: var(--panel); border-bottom: 1px solid var(--border);
      padding: 10px 20px; position: sticky; top: 0; z-index: 100;
    }
    #logo { color: var(--teal); font-weight: 800; font-size: 1.1rem; letter-spacing: 1px; white-space: nowrap; }
    #logo span { color: #fff; }
    #address-bar {
      flex: 1; display: flex; gap: 8px;
    }
    #address-input {
      flex: 1; background: var(--bg); border: 1px solid var(--border); border-radius: 6px;
      color: var(--text); font-size: 0.95rem; padding: 8px 14px; outline: none;
      transition: border-color .2s;
    }
    #address-input:focus { border-color: var(--teal); }
    #address-input::placeholder { color: var(--muted); }
    button {
      background: var(--teal); color: #07090f; border: none; border-radius: 6px;
      font-weight: 700; padding: 8px 18px; cursor: pointer; font-size: 0.9rem;
      transition: background .15s;
    }
    button:hover { background: var(--teal-dim); }
    button.secondary { background: var(--border); color: var(--text); }
    button.secondary:hover { background: #253050; }
    button.danger { background: var(--danger); color: #fff; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--teal); display: inline-block; margin-right: 5px; animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }

    /* ── Layout ── */
    #layout { display: grid; grid-template-columns: 240px 1fr; min-height: calc(100vh - 52px); }

    /* ── Sidebar ── */
    #sidebar {
      background: var(--panel); border-right: 1px solid var(--border);
      padding: 20px 14px; display: flex; flex-direction: column; gap: 8px;
    }
    .sidebar-section { font-size: 0.72rem; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; margin: 12px 0 6px; }
    .nav-item {
      padding: 8px 12px; border-radius: 6px; cursor: pointer; font-size: 0.9rem;
      display: flex; align-items: center; gap: 8px; transition: background .15s; color: var(--text);
    }
    .nav-item:hover { background: rgba(25,227,200,.08); }
    .nav-item.active { background: rgba(25,227,200,.15); color: var(--teal); font-weight: 600; }
    .nav-icon { width: 16px; text-align: center; }

    /* ── Main Content ── */
    #main { padding: 24px; overflow-y: auto; }
    .page { display: none; }
    .page.active { display: block; }

    h2 { color: var(--teal); font-size: 1.3rem; margin-bottom: 18px; font-weight: 700; }
    h3 { font-size: 1rem; color: #9ab; margin-bottom: 12px; font-weight: 600; }

    .card {
      background: var(--panel); border: 1px solid var(--border); border-radius: 10px;
      padding: 20px; margin-bottom: 18px;
    }

    /* ── Status Grid ── */
    .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 14px; margin-bottom: 20px; }
    .stat-card {
      background: var(--panel); border: 1px solid var(--border); border-radius: 8px; padding: 16px;
      text-align: center;
    }
    .stat-val { font-size: 1.7rem; font-weight: 800; color: var(--teal); }
    .stat-lbl { font-size: 0.78rem; color: var(--muted); margin-top: 4px; }

    /* ── Content Viewer ── */
    #content-display {
      background: var(--bg); border: 1px solid var(--border); border-radius: 8px;
      min-height: 200px; padding: 18px; font-family: monospace; white-space: pre-wrap;
      font-size: 0.9rem; max-height: 60vh; overflow-y: auto;
    }
    #content-display img { max-width: 100%; border-radius: 6px; }
    #content-display.loading { color: var(--muted); font-style: italic; }

    /* ── Upload Zone ── */
    #drop-zone {
      border: 2px dashed var(--border); border-radius: 10px; padding: 40px;
      text-align: center; cursor: pointer; transition: border-color .2s, background .2s;
      margin-bottom: 16px;
    }
    #drop-zone.dragover { border-color: var(--teal); background: rgba(25,227,200,.05); }
    #drop-zone .dz-icon { font-size: 2.5rem; margin-bottom: 10px; }
    #drop-zone .dz-text { color: var(--muted); font-size: 0.9rem; }
    #file-input { display: none; }

    /* ── CID List ── */
    .cid-list { display: flex; flex-direction: column; gap: 8px; }
    .cid-item {
      background: var(--bg); border: 1px solid var(--border); border-radius: 6px;
      padding: 10px 14px; display: flex; align-items: center; gap: 10px;
      font-family: monospace; font-size: 0.82rem;
    }
    .cid-item .cid-hash { flex: 1; color: var(--teal); word-break: break-all; }
    .cid-item .cid-actions { display: flex; gap: 6px; }
    .mini-btn {
      background: var(--border); color: var(--text); border: none; border-radius: 4px;
      padding: 4px 10px; cursor: pointer; font-size: 0.78rem; transition: background .15s;
    }
    .mini-btn:hover { background: var(--teal); color: #07090f; }

    /* ── ANS ── */
    .ans-form { display: grid; grid-template-columns: 1fr 2fr auto; gap: 10px; align-items: start; margin-bottom: 18px; }
    input[type="text"] {
      background: var(--bg); border: 1px solid var(--border); border-radius: 6px;
      color: var(--text); font-size: 0.9rem; padding: 8px 12px; outline: none; width: 100%;
      transition: border-color .2s;
    }
    input[type="text"]:focus { border-color: var(--teal); }

    /* ── Toast ── */
    #toast {
      position: fixed; bottom: 24px; right: 24px; background: var(--panel);
      border: 1px solid var(--teal); border-radius: 8px; padding: 12px 20px;
      color: var(--text); font-size: 0.88rem; z-index: 9999;
      transform: translateY(80px); opacity: 0; transition: all .3s;
    }
    #toast.show { transform: translateY(0); opacity: 1; }
    #toast.error { border-color: var(--danger); }

    /* ── Peers ── */
    .peer-row { display: flex; align-items: center; gap: 12px; padding: 10px 0; border-bottom: 1px solid var(--border); }
    .peer-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
    .peer-dot.alive { background: var(--teal); }
    .peer-dot.suspect { background: var(--warn); }
    .peer-dot.dead { background: var(--danger); }
    .peer-id { font-family: monospace; font-size: 0.82rem; flex: 1; }
    .peer-state { font-size: 0.78rem; color: var(--muted); }

    /* ── Terminal log ── */
    #log-panel {
      background: #040608; border: 1px solid var(--border); border-radius: 8px;
      padding: 14px; font-family: monospace; font-size: 0.8rem; height: 200px;
      overflow-y: auto; color: #7acc9a;
    }
    .log-line { line-height: 1.6; }
    .log-line.err { color: var(--danger); }
    .log-line.warn { color: var(--warn); }

    /* ── Responsive ── */
    @media (max-width: 700px) {
      #layout { grid-template-columns: 1fr; }
      #sidebar { display: none; }
    }
  </style>
</head>
<body>

<!-- Top Bar -->
<div id="topbar">
  <div id="logo">ABZU<span>NET</span></div>
  <div id="address-bar">
    <input id="address-input" type="text" placeholder="abzu://cid/…  or  abzuname://sitename" />
    <button onclick="handleAddressBar()">Go</button>
    <button class="secondary" onclick="showPage('upload')">Upload</button>
  </div>
  <span style="color:var(--muted);font-size:.8rem;white-space:nowrap">
    <span class="dot"></span>Node Active
  </span>
</div>

<!-- Layout -->
<div id="layout">

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="sidebar-section">Navigate</div>
    <div class="nav-item active" onclick="showPage('home')" data-page="home">
      <span class="nav-icon">⌂</span> Home
    </div>
    <div class="nav-item" onclick="showPage('browse')" data-page="browse">
      <span class="nav-icon">◈</span> Browse Content
    </div>
    <div class="nav-item" onclick="showPage('upload')" data-page="upload">
      <span class="nav-icon">↑</span> Upload
    </div>

    <div class="sidebar-section">Network</div>
    <div class="nav-item" onclick="showPage('ans')" data-page="ans">
      <span class="nav-icon">⊛</span> Name System (ANS)
    </div>
    <div class="nav-item" onclick="showPage('peers')" data-page="peers">
      <span class="nav-icon">◉</span> Peers
    </div>
    <div class="nav-item" onclick="showPage('status')" data-page="status">
      <span class="nav-icon">◎</span> Node Status
    </div>

    <div class="sidebar-section">Local</div>
    <div class="nav-item" onclick="showPage('stored')" data-page="stored">
      <span class="nav-icon">▤</span> Stored Objects
    </div>
  </div>

  <!-- Main -->
  <div id="main">

    <!-- Home -->
    <div id="page-home" class="page active">
      <h2>AbzuNet Browser</h2>
      <p style="color:var(--muted);margin-bottom:20px;line-height:1.7">
        A resilient, decentralized information network — operational with or without internet access.
        Use the address bar above to retrieve content by CID, or navigate by name using the Abzu Name System.
      </p>
      <div class="stat-grid" id="home-stats">
        <div class="stat-card"><div class="stat-val" id="stat-node-id">…</div><div class="stat-lbl">Node ID (prefix)</div></div>
        <div class="stat-card"><div class="stat-val" id="stat-objects">…</div><div class="stat-lbl">Stored Objects</div></div>
        <div class="stat-card"><div class="stat-val" id="stat-disk">…</div><div class="stat-lbl">Disk Usage</div></div>
        <div class="stat-card"><div class="stat-val" id="stat-version">2.0.2</div><div class="stat-lbl">Protocol Version</div></div>
      </div>
      <div class="card">
        <h3>Quick Actions</h3>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button onclick="showPage('browse')">Browse a CID</button>
          <button class="secondary" onclick="showPage('upload')">Upload Content</button>
          <button class="secondary" onclick="showPage('ans')">Manage Names</button>
          <button class="secondary" onclick="showPage('peers')">View Peers</button>
        </div>
      </div>
      <div class="card">
        <h3>Network Log</h3>
        <div id="log-panel"></div>
      </div>
    </div>

    <!-- Browse -->
    <div id="page-browse" class="page">
      <h2>Browse Content</h2>
      <div class="card">
        <h3>Retrieve by CID</h3>
        <div style="display:flex;gap:10px;margin-bottom:14px">
          <input type="text" id="browse-cid" placeholder="64-character hex CID…" style="flex:1" />
          <button onclick="retrieveContent()">Retrieve</button>
        </div>
        <div id="content-display" class="loading">Enter a CID above to retrieve content.</div>
      </div>
    </div>

    <!-- Upload -->
    <div id="page-upload" class="page">
      <h2>Upload Content</h2>
      <div class="card">
        <div id="drop-zone" onclick="document.getElementById('file-input').click()" 
             ondragover="event.preventDefault();this.classList.add('dragover')"
             ondragleave="this.classList.remove('dragover')"
             ondrop="handleDrop(event)">
          <div class="dz-icon">⬆</div>
          <div style="font-size:1rem;margin-bottom:6px">Drop files here or click to select</div>
          <div class="dz-text">Files are chunked into 4MB segments, BLAKE3-hashed, and stored locally.<br>A Content ID (CID) is returned for sharing.</div>
        </div>
        <input type="file" id="file-input" multiple onchange="handleFileSelect(event)" />
        <div id="upload-result" style="display:none" class="card" style="margin-top:14px">
          <h3>Upload Result</h3>
          <div id="upload-cid" style="font-family:monospace;color:var(--teal);word-break:break-all;font-size:.9rem"></div>
          <div id="upload-meta" style="color:var(--muted);font-size:.8rem;margin-top:6px"></div>
          <div style="display:flex;gap:8px;margin-top:12px">
            <button onclick="copyUploadCid()" class="secondary">Copy CID</button>
            <button onclick="registerName()" class="secondary">Register Name →</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ANS -->
    <div id="page-ans" class="page">
      <h2>Abzu Name System</h2>
      <div class="card">
        <h3>Register a Name</h3>
        <div class="ans-form">
          <input type="text" id="ans-name" placeholder="sitename" />
          <input type="text" id="ans-cid" placeholder="CID (64 hex chars)" />
          <button onclick="registerAns()">Register</button>
        </div>
        <h3>Resolve a Name</h3>
        <div style="display:flex;gap:10px">
          <input type="text" id="ans-resolve-input" placeholder="sitename" style="flex:1" />
          <button onclick="resolveAns()">Resolve</button>
        </div>
        <div id="ans-result" style="margin-top:12px;font-family:monospace;font-size:.88rem;color:var(--teal);display:none"></div>
      </div>
      <div class="card">
        <h3>Registered Names</h3>
        <div id="ans-list" style="color:var(--muted);font-size:.88rem">Loading…</div>
      </div>
    </div>

    <!-- Peers -->
    <div id="page-peers" class="page">
      <h2>Peer Network</h2>
      <div class="card">
        <h3>Connected Peers</h3>
        <div id="peer-list"><div style="color:var(--muted)">Querying swarm…</div></div>
      </div>
    </div>

    <!-- Status -->
    <div id="page-status" class="page">
      <h2>Node Status</h2>
      <div class="card">
        <pre id="status-json" style="font-family:monospace;font-size:.85rem;color:var(--teal);white-space:pre-wrap">Loading…</pre>
      </div>
    </div>

    <!-- Stored Objects -->
    <div id="page-stored" class="page">
      <h2>Stored Objects</h2>
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
          <h3 style="margin:0">Local Content Store</h3>
          <button class="secondary" onclick="loadStoredObjects()">Refresh</button>
        </div>
        <div id="cid-list" class="cid-list"><div style="color:var(--muted)">Loading…</div></div>
      </div>
    </div>

  </div><!-- #main -->
</div><!-- #layout -->

<div id="toast"></div>

<script>
// ── State ───────────────────────────────────────────────────────────────────
let currentUploadCid = '';
const log = (msg, level='info') => {
  const panel = document.getElementById('log-panel');
  if (!panel) return;
  const line = document.createElement('div');
  line.className = 'log-line' + (level === 'err' ? ' err' : level === 'warn' ? ' warn' : '');
  const ts = new Date().toTimeString().slice(0,8);
  line.textContent = `[${ts}] ${msg}`;
  panel.appendChild(line);
  panel.scrollTop = panel.scrollHeight;
};

const toast = (msg, err=false) => {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'show' + (err ? ' error' : '');
  setTimeout(() => t.className = '', 3000);
};

// ── Navigation ──────────────────────────────────────────────────────────────
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + name)?.classList.add('active');
  document.querySelector(`[data-page="${name}"]`)?.classList.add('active');

  if (name === 'status') loadStatus();
  if (name === 'stored') loadStoredObjects();
  if (name === 'ans') loadAnsNames();
  if (name === 'peers') loadPeers();
}

function handleAddressBar() {
  const raw = document.getElementById('address-input').value.trim();
  if (raw.startsWith('abzuname://')) {
    const name = raw.replace('abzuname://', '').split('/')[0];
    showPage('ans');
    document.getElementById('ans-resolve-input').value = name;
    resolveAns();
  } else {
    let cid = raw.replace('abzu://', '').split('/')[0];
    if (cid.length === 64) {
      document.getElementById('browse-cid').value = cid;
      showPage('browse');
      retrieveContent();
    } else {
      toast('Invalid address. Use abzu://CID or abzuname://name', true);
    }
  }
}

// ── Status ──────────────────────────────────────────────────────────────────
async function loadStatus() {
  try {
    const r = await fetch('/status');
    const d = await r.json();
    document.getElementById('status-json').textContent = JSON.stringify(d, null, 2);
    document.getElementById('stat-node-id').textContent = d.node_id?.slice(0,8) + '…';
    document.getElementById('stat-objects').textContent = d.stored_objects ?? '—';
    document.getElementById('stat-disk').textContent = formatBytes(d.disk_usage_bytes ?? 0);
    log(`Node status loaded: ${d.stored_objects} objects, ${formatBytes(d.disk_usage_bytes)}`);
  } catch(e) {
    log('Status fetch failed: ' + e.message, 'err');
  }
}

function formatBytes(b) {
  if (b === 0) return '0 B';
  const k = 1024, sizes = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(b) / Math.log(k));
  return (b / Math.pow(k, i)).toFixed(1) + ' ' + sizes[i];
}

// ── Content Retrieval ────────────────────────────────────────────────────────
async function retrieveContent() {
  const cid = document.getElementById('browse-cid').value.trim();
  if (!cid || cid.length !== 64) { toast('Enter a valid 64-char CID', true); return; }
  const display = document.getElementById('content-display');
  display.className = 'loading';
  display.textContent = `Retrieving ${cid}…`;
  log(`Fetching cid: ${cid}`);
  try {
    const r = await fetch(`/abzu/${cid}`);
    if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
    const ct = r.headers.get('content-type') || '';
    display.className = '';
    if (ct.startsWith('image/')) {
      const blob = await r.blob();
      const url = URL.createObjectURL(blob);
      display.innerHTML = `<img src="${url}" alt="content" />`;
    } else if (ct.startsWith('text/') || ct.includes('json')) {
      display.textContent = await r.text();
    } else {
      const buf = await r.arrayBuffer();
      display.textContent = `Binary content (${formatBytes(buf.byteLength)})\nContent-Type: ${ct}`;
    }
    log(`Retrieved ${cid} (${ct})`);
  } catch(e) {
    display.className = 'loading';
    display.textContent = `Error: ${e.message}`;
    log(`Retrieval error: ${e.message}`, 'err');
    toast('Retrieval failed: ' + e.message, true);
  }
}

// ── Upload ───────────────────────────────────────────────────────────────────
function handleDrop(e) {
  e.preventDefault();
  document.getElementById('drop-zone').classList.remove('dragover');
  const files = e.dataTransfer.files;
  if (files.length) uploadFile(files[0]);
}

function handleFileSelect(e) {
  if (e.target.files.length) uploadFile(e.target.files[0]);
}

async function uploadFile(file) {
  log(`Uploading: ${file.name} (${formatBytes(file.size)})`);
  toast(`Uploading ${file.name}…`);
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch('/abzu/upload', { method: 'POST', body: fd });
    if (!r.ok) throw new Error(await r.text());
    const d = await r.json();
    currentUploadCid = d.cid;
    document.getElementById('upload-result').style.display = 'block';
    document.getElementById('upload-cid').textContent = d.cid;
    document.getElementById('upload-meta').textContent =
      `${d.chunks} chunk(s) · ${formatBytes(d.bytes)}`;
    document.getElementById('ans-cid').value = d.cid;
    log(`Uploaded: ${d.cid} (${d.chunks} chunks, ${formatBytes(d.bytes)})`);
    toast('Upload successful!');
  } catch(e) {
    log('Upload failed: ' + e.message, 'err');
    toast('Upload failed: ' + e.message, true);
  }
}

function copyUploadCid() {
  navigator.clipboard.writeText(currentUploadCid).then(() => toast('CID copied!'));
}

function registerName() {
  document.getElementById('ans-name').value = '';
  document.getElementById('ans-cid').value = currentUploadCid;
  showPage('ans');
}

// ── ANS ──────────────────────────────────────────────────────────────────────
async function registerAns() {
  const name = document.getElementById('ans-name').value.trim();
  const cid = document.getElementById('ans-cid').value.trim();
  if (!name || cid.length !== 64) { toast('Enter a name and valid CID', true); return; }
  try {
    const r = await fetch(`/abzuname/${name}/${cid}`, { method: 'POST' });
    if (!r.ok) throw new Error(await r.text());
    log(`ANS registered: ${name} → ${cid}`);
    toast(`Registered: ${name}`);
    loadAnsNames();
  } catch(e) {
    log('ANS register error: ' + e.message, 'err');
    toast('Registration failed: ' + e.message, true);
  }
}

async function resolveAns() {
  const name = document.getElementById('ans-resolve-input').value.trim();
  if (!name) { toast('Enter a name', true); return; }
  const result = document.getElementById('ans-result');
  try {
    const r = await fetch(`/abzuname/${name}`);
    if (!r.ok) throw new Error(`Name '${name}' not found`);
    const d = await r.json();
    result.style.display = 'block';
    result.textContent = `${d.name}  →  ${d.cid}`;
    log(`Resolved ${d.name} → ${d.cid}`);
  } catch(e) {
    result.style.display = 'block';
    result.textContent = e.message;
    result.style.color = 'var(--danger)';
  }
}

async function loadAnsNames() {
  // Reload by re-resolving common names would require a list endpoint.
  // Placeholder: show registered count from local ls
  document.getElementById('ans-list').textContent = 'Use Register form above to add entries.';
}

// ── Peers ─────────────────────────────────────────────────────────────────────
async function loadPeers() {
  try {
    const r = await fetch('/abzu/peers');
    const d = await r.json();
    document.getElementById('peer-list').innerHTML =
      `<div style="color:var(--muted);font-size:.88rem">${d.message}</div>`;
  } catch(e) {
    document.getElementById('peer-list').innerHTML =
      `<div style="color:var(--danger)">Failed to fetch peers: ${e.message}</div>`;
  }
}

// ── Stored Objects ────────────────────────────────────────────────────────────
async function loadStoredObjects() {
  const list = document.getElementById('cid-list');
  list.innerHTML = '<div style="color:var(--muted)">Loading…</div>';
  try {
    const r = await fetch('/abzu/ls');
    const items = await r.json();
    if (!items.length) {
      list.innerHTML = '<div style="color:var(--muted)">No objects stored locally.</div>';
      return;
    }
    list.innerHTML = '';
    for (const item of items) {
      const row = document.createElement('div');
      row.className = 'cid-item';
      row.innerHTML = `
        <div class="cid-hash">${item.cid}</div>
        <div class="cid-actions">
          <button class="mini-btn" onclick="openCid('${item.cid}')">View</button>
          <button class="mini-btn" onclick="copyCid('${item.cid}')">Copy</button>
        </div>`;
      list.appendChild(row);
    }
    log(`Loaded ${items.length} stored object(s)`);
  } catch(e) {
    list.innerHTML = `<div style="color:var(--danger)">Error: ${e.message}</div>`;
  }
}

function openCid(cid) {
  document.getElementById('browse-cid').value = cid;
  showPage('browse');
  retrieveContent();
}

function copyCid(cid) {
  navigator.clipboard.writeText(cid).then(() => toast('CID copied!'));
}

// ── Boot ──────────────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  log('AbzuNet Browser v2.0.2 initialized');
  log('Loading node status…');
  loadStatus();
  log('Network transport: UDP Broadcast + libp2p QUIC/TCP');
  log('Content addressing: BLAKE3 (4MB chunks + Bao streaming)');
  log('Identity: Ed25519 keypair, Node ID = BLAKE3(pubkey)');
});
</script>
</body>
</html>"#;

// ─── v2.0.3: ANRS Handlers ───────────────────────────────────────────────────

#[derive(Serialize)]
struct AnrsStatusResponse {
    enabled:       bool,
    wallet_address: String,
    current_epoch: u64,
    emission_rate: String,
    score:         Option<AnrsScoreJson>,
    pending_balance_abzu: String,
    confirmed_balance_abzu: String,
    total_earned_abzu: String,
    storage_pledge_gb: u64,
    lora_active: bool,
}

#[derive(Serialize)]
struct AnrsScoreJson {
    uptime:  f64,
    storage: f64,
    serving: f64,
    routing: f64,
    lora:    f64,
    total:   f64,
}

async fn handle_anrs_status(
    State(state): State<Arc<GatewayState>>,
) -> impl IntoResponse {
    match &state.anrs {
        Some(anrs) => {
            let balance = anrs.balance.snapshot().await;
            Json(serde_json::json!({
                "enabled": true,
                "wallet_address": balance.address,
                "pending_balance_abzu": format!("{:.8}", balance.pending as f64 / 1e8),
                "confirmed_balance_abzu": format!("{:.8}", balance.confirmed as f64 / 1e8),
                "total_earned_abzu": format!("{:.8}", balance.total_earned as f64 / 1e8),
                "lora_active": state.lora_stats.is_some(),
                "message": "ANRS active — earning ABZU every epoch for network contributions",
            })).into_response()
        }
        None => Json(serde_json::json!({
            "enabled": false,
            "message": "ANRS disabled — set [anrs] enabled = true in abzu.toml to start earning",
        })).into_response()
    }
}

async fn handle_anrs_balance(
    State(state): State<Arc<GatewayState>>,
) -> impl IntoResponse {
    match &state.anrs {
        Some(anrs) => {
            let balance = anrs.balance.snapshot().await;
            Json(serde_json::json!({
                "address": balance.address,
                "pending":   format!("{:.8} ABZU", balance.pending   as f64 / 1e8),
                "confirmed": format!("{:.8} ABZU", balance.confirmed as f64 / 1e8),
                "total_available": format!("{:.8} ABZU", balance.total_available() as f64 / 1e8),
                "total_earned":    format!("{:.8} ABZU", balance.total_earned as f64 / 1e8),
                "total_withdrawn": format!("{:.8} ABZU", balance.total_withdrawn as f64 / 1e8),
                "last_sync": balance.last_sync,
            })).into_response()
        }
        None => (StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({"error": "ANRS not enabled"}))).into_response()
    }
}

#[derive(serde::Deserialize)]
struct WithdrawRequest {
    to_address: Option<String>,
}

async fn handle_anrs_withdraw(
    State(state): State<Arc<GatewayState>>,
    Json(req): Json<WithdrawRequest>,
) -> impl IntoResponse {
    match &state.anrs {
        Some(anrs) => {
            match anrs.balance.withdraw(req.to_address).await {
                Ok(withdrawal) => Json(serde_json::json!({
                    "success": true,
                    "recipient": withdrawal.recipient,
                    "amount_abzu": format!("{:.8}", withdrawal.amount as f64 / 1e8),
                    "timestamp": withdrawal.timestamp,
                    "message": "Withdrawal submitted to Arbitrum",
                })).into_response(),
                Err(e) => (StatusCode::BAD_REQUEST,
                    Json(serde_json::json!({"error": e.to_string()}))).into_response()
            }
        }
        None => (StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({"error": "ANRS not enabled"}))).into_response()
    }
}

// ─── v2.0.3: LoRa Handlers ───────────────────────────────────────────────────

async fn handle_lora_status(
    State(state): State<Arc<GatewayState>>,
) -> impl IntoResponse {
    match &state.lora_stats {
        Some(stats_lock) => {
            let stats = stats_lock.lock().await;
            Json(serde_json::json!({
                "active": stats.hardware_present,
                "packets_sent":     stats.packets_sent,
                "packets_received": stats.packets_received,
                "bytes_sent":       stats.bytes_sent,
                "bytes_received":   stats.bytes_received,
                "messages_relayed": stats.messages_relayed,
                "fragments_sent":   stats.fragments_sent,
                "fragments_received": stats.fragments_received,
                "signal_quality": stats.signal_quality.as_ref().map(|sq| serde_json::json!({
                    "snr":  sq.snr,
                    "rssi": sq.rssi,
                    "hop_count": sq.hop_count,
                    "quality": sq.quality_score(),
                })),
                "uptime_secs": stats.uptime_secs,
            })).into_response()
        }
        None => Json(serde_json::json!({
            "active": false,
            "message": "LoRa disabled — set [lora] enabled = true in abzu.toml and connect hardware",
        })).into_response()
    }
}
