// abzu-node/src/storage/mod.rs
//! Content-Addressable Storage with BLAKE3 and Bao Streaming
//! Phase 2: CAS & Streaming Implementation

use anyhow::Result;
use blake3;
use std::path::{Path, PathBuf};

pub mod chunker;
pub mod bao;
pub mod store;

pub use chunker::Chunker;
pub use store::ContentStore;

/// Root CID computation: R_cid = BLAKE3(chunk_0 || chunk_1 || ... || chunk_n)
pub fn compute_root_cid(chunks: &[Vec<u8>]) -> [u8; 32] {
    let mut hasher = blake3::Hasher::new();
    for chunk in chunks {
        hasher.update(chunk);
    }
    *hasher.finalize().as_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_root_cid_computation() {
        let chunks = vec![
            vec![1, 2, 3],
            vec![4, 5, 6],
        ];
        let cid = compute_root_cid(&chunks);
        assert_eq!(cid.len(), 32);
    }
}
