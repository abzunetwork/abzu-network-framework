// abzu-node/src/storage/store.rs
//! Content Store - BLAKE3-addressed local storage backed by sled
//!
//! Provides a persistent, content-addressable object store.
//! Chunks are keyed by their BLAKE3 hash. Manifests (root CID -> ChunkManifest)
//! are stored in a separate sled tree for fast metadata lookups.

use anyhow::{Context, Result};
use sled::Db;
use std::path::Path;
use super::chunker::{Chunk, ChunkManifest, Chunker};

const CHUNK_TREE: &str = "chunks";
const MANIFEST_TREE: &str = "manifests";

pub struct ContentStore {
    db: Db,
}

impl ContentStore {
    /// Open (or create) a content store at the given path
    pub fn open<P: AsRef<Path>>(path: P) -> Result<Self> {
        let db = sled::open(path.as_ref())
            .with_context(|| format!("Cannot open store at {}", path.as_ref().display()))?;
        Ok(Self { db })
    }

    /// Store a chunk by its BLAKE3 hash
    pub fn put_chunk(&self, chunk: &Chunk) -> Result<()> {
        let tree = self.db.open_tree(CHUNK_TREE)?;
        tree.insert(chunk.hash, chunk.data.as_slice())?;
        Ok(())
    }

    /// Retrieve a chunk by its BLAKE3 hash
    pub fn get_chunk(&self, hash: &[u8; 32]) -> Result<Option<Chunk>> {
        let tree = self.db.open_tree(CHUNK_TREE)?;
        match tree.get(hash)? {
            Some(val) => {
                let data = val.to_vec();
                // Reconstruct chunk; index is unknown from storage alone, use 0
                let chunk = Chunk { index: 0, hash: *hash, data };
                Ok(Some(chunk))
            }
            None => Ok(None),
        }
    }

    /// Check if a chunk is stored locally
    pub fn has_chunk(&self, hash: &[u8; 32]) -> Result<bool> {
        let tree = self.db.open_tree(CHUNK_TREE)?;
        Ok(tree.contains_key(hash)?)
    }

    /// Store a manifest indexed by root CID
    pub fn put_manifest(&self, manifest: &ChunkManifest) -> Result<()> {
        let tree = self.db.open_tree(MANIFEST_TREE)?;
        let bytes = bincode::serialize(manifest).context("Manifest serialization failed")?;
        tree.insert(manifest.root_cid, bytes.as_slice())?;
        Ok(())
    }

    /// Retrieve a manifest by root CID
    pub fn get_manifest(&self, root_cid: &[u8; 32]) -> Result<Option<ChunkManifest>> {
        let tree = self.db.open_tree(MANIFEST_TREE)?;
        match tree.get(root_cid)? {
            Some(val) => {
                let manifest: ChunkManifest = bincode::deserialize(&val)
                    .context("Manifest deserialization failed")?;
                Ok(Some(manifest))
            }
            None => Ok(None),
        }
    }

    /// Store all chunks + the manifest for a complete file
    pub fn store_file_chunks(&self, chunks: &[Chunk], root_cid: [u8; 32]) -> Result<()> {
        for chunk in chunks {
            self.put_chunk(chunk)?;
        }
        let manifest = ChunkManifest::from_chunks(chunks, root_cid);
        self.put_manifest(&manifest)?;
        Ok(())
    }

    /// Retrieve all chunks for a root CID (from local store)
    ///
    /// Returns None if any chunk is missing locally.
    pub fn retrieve_all_chunks(&self, root_cid: &[u8; 32]) -> Result<Option<Vec<Chunk>>> {
        let manifest = match self.get_manifest(root_cid)? {
            Some(m) => m,
            None => return Ok(None),
        };

        let mut chunks = Vec::with_capacity(manifest.chunk_count);
        for (index, hash) in manifest.chunk_hashes.iter().enumerate() {
            match self.get_chunk(hash)? {
                Some(mut chunk) => {
                    chunk.index = index; // Restore index from manifest
                    chunks.push(chunk);
                }
                None => return Ok(None), // Missing chunk
            }
        }

        Ok(Some(chunks))
    }

    /// Reassemble a complete file from local storage
    pub fn retrieve_file(&self, root_cid: &[u8; 32]) -> Result<Option<Vec<u8>>> {
        match self.retrieve_all_chunks(root_cid)? {
            Some(chunks) => Ok(Some(Chunker::reassemble(&chunks)?)),
            None => Ok(None),
        }
    }

    /// List all stored root CIDs
    pub fn list_root_cids(&self) -> Result<Vec<[u8; 32]>> {
        let tree = self.db.open_tree(MANIFEST_TREE)?;
        let mut cids = Vec::new();
        for item in tree.iter() {
            let (key, _) = item?;
            if key.len() == 32 {
                let mut arr = [0u8; 32];
                arr.copy_from_slice(&key);
                cids.push(arr);
            }
        }
        Ok(cids)
    }

    /// Return total number of chunks stored
    pub fn chunk_count(&self) -> Result<usize> {
        let tree = self.db.open_tree(CHUNK_TREE)?;
        Ok(tree.len())
    }

    /// Return approximate storage usage in bytes
    pub fn size_on_disk(&self) -> Result<u64> {
        Ok(self.db.size_on_disk()?)
    }

    /// Delete all chunks for a root CID (and its manifest)
    pub fn delete_file(&self, root_cid: &[u8; 32]) -> Result<()> {
        if let Some(manifest) = self.get_manifest(root_cid)? {
            let chunk_tree = self.db.open_tree(CHUNK_TREE)?;
            for hash in &manifest.chunk_hashes {
                chunk_tree.remove(hash)?;
            }
            let manifest_tree = self.db.open_tree(MANIFEST_TREE)?;
            manifest_tree.remove(root_cid)?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    fn make_store() -> (ContentStore, TempDir) {
        let dir = TempDir::new().unwrap();
        let store = ContentStore::open(dir.path()).unwrap();
        (store, dir)
    }

    #[test]
    fn test_store_and_retrieve_chunk() {
        let (store, _dir) = make_store();
        let chunk = Chunk::new(0, b"test data payload".to_vec());
        store.put_chunk(&chunk).unwrap();
        let retrieved = store.get_chunk(&chunk.hash).unwrap().unwrap();
        assert_eq!(retrieved.data, chunk.data);
    }

    #[test]
    fn test_store_and_retrieve_file() {
        let (store, _dir) = make_store();
        let chunker = Chunker::with_chunk_size(8);
        let original = b"Hello, post-internet world!".to_vec();
        let (chunks, root_cid) = chunker.chunk_bytes(&original);

        store.store_file_chunks(&chunks, root_cid).unwrap();

        let retrieved = store.retrieve_file(&root_cid).unwrap().unwrap();
        assert_eq!(original, retrieved);
    }

    #[test]
    fn test_missing_file_returns_none() {
        let (store, _dir) = make_store();
        let result = store.retrieve_file(&[0u8; 32]).unwrap();
        assert!(result.is_none());
    }

    #[test]
    fn test_list_root_cids() {
        let (store, _dir) = make_store();
        let chunker = Chunker::with_chunk_size(10);
        let (chunks, cid) = chunker.chunk_bytes(b"listing test");
        store.store_file_chunks(&chunks, cid).unwrap();

        let cids = store.list_root_cids().unwrap();
        assert!(cids.contains(&cid));
    }
}
