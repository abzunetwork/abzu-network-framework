// abzu-node/src/transport/fragment.rs
//! LoRa Packet Fragmentation and Reassembly
//!
//! LoRa's maximum physical payload is ~237 bytes. libp2p protocol messages
//! can be many kilobytes. This module fragments outbound messages into
//! 200-byte chunks and reassembles inbound fragments into complete messages.
//!
//! Fragment format (37-byte header + 200-byte payload = 237 bytes total):
//!   [0..4]   msg_id      u32  — random message identifier for grouping
//!   [4..6]   chunk_idx   u16  — this fragment's index (0-based)
//!   [6..8]   total       u16  — total number of fragments
//!   [8..40]  from        [u8;32] — sender's AbzuNet Node ID
//!   [40..72] to          [u8;32] — recipient's AbzuNet Node ID
//!   [72..]   payload     Vec<u8> — up to 165 bytes of data

use std::collections::HashMap;
use std::time::{Duration, Instant};
use tracing::{debug, warn};

pub const MAX_PAYLOAD_BYTES: usize = 165;
pub const HEADER_SIZE: usize = 72;
pub const MAX_FRAGMENT_SIZE: usize = HEADER_SIZE + MAX_PAYLOAD_BYTES; // 237 bytes
pub const REASSEMBLY_TIMEOUT: Duration = Duration::from_secs(60);

/// A single LoRa fragment, ready to transmit
#[derive(Debug, Clone)]
pub struct LoraFragment {
    pub msg_id:    u32,
    pub chunk_idx: u16,
    pub total:     u16,
    pub from:      [u8; 32],
    pub to:        [u8; 32],
    pub payload:   Vec<u8>,
}

impl LoraFragment {
    /// Encode fragment to raw bytes for LoRa transmission
    pub fn encode(&self) -> Vec<u8> {
        let mut buf = Vec::with_capacity(MAX_FRAGMENT_SIZE);
        buf.extend_from_slice(&self.msg_id.to_le_bytes());
        buf.extend_from_slice(&self.chunk_idx.to_le_bytes());
        buf.extend_from_slice(&self.total.to_le_bytes());
        buf.extend_from_slice(&self.from);
        buf.extend_from_slice(&self.to);
        buf.extend_from_slice(&self.payload);
        buf
    }

    /// Decode a fragment from raw received bytes
    pub fn decode(data: &[u8]) -> Option<Self> {
        if data.len() < HEADER_SIZE {
            warn!("LoRa fragment too short: {} bytes", data.len());
            return None;
        }
        let msg_id = u32::from_le_bytes(data[0..4].try_into().ok()?);
        let chunk_idx = u16::from_le_bytes(data[4..6].try_into().ok()?);
        let total = u16::from_le_bytes(data[6..8].try_into().ok()?);
        let mut from = [0u8; 32];
        let mut to = [0u8; 32];
        from.copy_from_slice(&data[8..40]);
        to.copy_from_slice(&data[40..72]);
        let payload = data[HEADER_SIZE..].to_vec();

        if chunk_idx >= total {
            warn!("Invalid fragment: chunk_idx {} >= total {}", chunk_idx, total);
            return None;
        }

        Some(Self { msg_id, chunk_idx, total, from, to, payload })
    }
}

/// Fragment a complete message into LoRa-sized chunks
pub fn fragment_message(
    msg_id: u32,
    from: [u8; 32],
    to: [u8; 32],
    data: &[u8],
) -> Vec<LoraFragment> {
    let chunks: Vec<&[u8]> = data.chunks(MAX_PAYLOAD_BYTES).collect();
    let total = chunks.len() as u16;

    chunks
        .into_iter()
        .enumerate()
        .map(|(idx, chunk)| LoraFragment {
            msg_id,
            chunk_idx: idx as u16,
            total,
            from,
            to,
            payload: chunk.to_vec(),
        })
        .collect()
}

/// Generate a random 32-bit message ID
pub fn new_msg_id() -> u32 {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};
    use std::time::SystemTime;

    let mut hasher = DefaultHasher::new();
    SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .unwrap_or_default()
        .subsec_nanos()
        .hash(&mut hasher);
    hasher.finish() as u32
}

// ─── Reassembler ─────────────────────────────────────────────────────────────

/// Tracks in-progress message reassembly
struct PendingMessage {
    total:     u16,
    from:      [u8; 32],
    to:        [u8; 32],
    fragments: HashMap<u16, Vec<u8>>,
    received:  Instant,
}

impl PendingMessage {
    fn is_complete(&self) -> bool {
        self.fragments.len() == self.total as usize
    }

    fn is_expired(&self) -> bool {
        self.received.elapsed() > REASSEMBLY_TIMEOUT
    }

    fn assemble(&self) -> Option<ReassembledMessage> {
        if !self.is_complete() {
            return None;
        }
        let mut data = Vec::new();
        for i in 0..self.total {
            data.extend_from_slice(self.fragments.get(&i)?);
        }
        Some(ReassembledMessage {
            from: self.from,
            to:   self.to,
            data,
        })
    }
}

/// A fully reassembled message ready to pass up to the transport layer
#[derive(Debug)]
pub struct ReassembledMessage {
    pub from: [u8; 32],
    pub to:   [u8; 32],
    pub data: Vec<u8>,
}

/// Stateful reassembly buffer. Feed fragments in, receive complete messages out.
pub struct Reassembler {
    pending: HashMap<u32, PendingMessage>, // msg_id → pending
}

impl Reassembler {
    pub fn new() -> Self {
        Self { pending: HashMap::new() }
    }

    /// Feed a fragment. Returns Some(message) when reassembly is complete.
    pub fn feed(&mut self, fragment: LoraFragment) -> Option<ReassembledMessage> {
        // Expire stale entries
        self.pending.retain(|_, v| !v.is_expired());

        let entry = self.pending.entry(fragment.msg_id).or_insert_with(|| {
            debug!(
                "New reassembly: msg_id={} total={}",
                fragment.msg_id, fragment.total
            );
            PendingMessage {
                total:     fragment.total,
                from:      fragment.from,
                to:        fragment.to,
                fragments: HashMap::new(),
                received:  Instant::now(),
            }
        });

        entry.fragments.insert(fragment.chunk_idx, fragment.payload);

        if entry.is_complete() {
            let result = entry.assemble();
            self.pending.remove(&fragment.msg_id);
            if result.is_some() {
                debug!("Reassembly complete: msg_id={}", fragment.msg_id);
            }
            result
        } else {
            debug!(
                "Reassembly progress: msg_id={} {}/{} fragments",
                fragment.msg_id,
                entry.fragments.len(),
                entry.total
            );
            None
        }
    }
}
