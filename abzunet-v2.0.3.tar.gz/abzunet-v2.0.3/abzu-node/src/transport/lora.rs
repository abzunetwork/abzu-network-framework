// abzu-node/src/transport/lora.rs
//! LoRa Transport — libp2p Transport Trait Implementation
//!
//! Implements libp2p's Transport trait over LoRa radio, enabling all AbzuNet
//! protocol traffic (Kademlia DHT, GossipSub, DTN) to flow over LoRa links
//! with zero modifications to upper protocol layers.
//!
//! Architecture:
//!
//!   libp2p Swarm
//!       │
//!       ▼
//!   LoraTransport (this module)
//!       │
//!       ├── Mode::Meshtastic → MeshtasticBridge → USB Serial → LoRa Hardware
//!       └── Mode::Direct     → DirectLoRa → SX126x/SX127x chipset (v2.1)
//!
//! Since LoRa is connectionless (like UDP), this transport implements
//! "virtual connections" — each unique remote Node ID is treated as a
//! connection endpoint, with in-order delivery guaranteed by the fragment
//! reassembler's msg_id sequencing.
//!
//! Multiaddress format: /lora/{frequency}/{node_id_hex}
//!   Example: /lora/915mhz/19e3c8a4f2b7d3c1e5a8f2b4d6e9c3a1b7d2e5f8a3c6e9b2d5f8a1c4e7b3d6e9

use anyhow::Result;
use std::collections::HashMap;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};
use tokio::sync::{mpsc, Mutex};
use tracing::{debug, error, info, warn};

use super::fragment::{ReassembledMessage, fragment_message, new_msg_id};
use super::lora_meshtastic::{MeshtasticBridge, LoraSignalQuality, detect_meshtastic_port};

// ─── Configuration ────────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub enum LoraFrequency {
    Mhz433,
    Mhz868,
    Mhz915,
}

impl LoraFrequency {
    pub fn from_str(s: &str) -> Option<Self> {
        match s {
            "433mhz" | "433" => Some(Self::Mhz433),
            "868mhz" | "868" => Some(Self::Mhz868),
            "915mhz" | "915" => Some(Self::Mhz915),
            _ => None,
        }
    }

    pub fn to_str(&self) -> &'static str {
        match self {
            Self::Mhz433 => "433mhz",
            Self::Mhz868 => "868mhz",
            Self::Mhz915 => "915mhz",
        }
    }

    /// EU 868MHz has a 10% duty cycle restriction
    pub fn has_duty_cycle_restriction(&self) -> bool {
        matches!(self, Self::Mhz868 | Self::Mhz433)
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum LoraMode {
    /// Mode A: Ride existing Meshtastic mesh via PRIVATE_APP messages
    Meshtastic,
    /// Mode B: Direct SX126x/SX127x serial control (v2.1)
    Direct,
}

#[derive(Debug, Clone)]
pub struct LoraConfig {
    pub enabled:         bool,
    pub port:            String,
    pub frequency:       LoraFrequency,
    pub mode:            LoraMode,
    pub spreading_factor: u8,     // 7–12
    pub bandwidth_khz:   u32,     // 125, 250, or 500
    pub tx_power_dbm:    i32,     // up to 30 (check local regulations)
    pub hop_limit:       u32,     // Meshtastic hop count
}

impl Default for LoraConfig {
    fn default() -> Self {
        Self {
            enabled:          false,
            port:             "/dev/ttyUSB0".to_string(),
            frequency:        LoraFrequency::Mhz915,
            mode:             LoraMode::Meshtastic,
            spreading_factor: 9,
            bandwidth_khz:    125,
            tx_power_dbm:     20,
            hop_limit:        3,
        }
    }
}

// ─── LoRa Statistics (feeds into ANRS LoraScore) ─────────────────────────────

#[derive(Debug, Default, Clone)]
pub struct LoraStats {
    pub packets_sent:     u64,
    pub packets_received: u64,
    pub bytes_sent:       u64,
    pub bytes_received:   u64,
    pub fragments_sent:   u64,
    pub fragments_received: u64,
    pub messages_relayed: u64,
    pub signal_quality:   Option<LoraSignalQuality>,
    pub hardware_present: bool,
    pub uptime_secs:      u64,
}

// ─── Virtual Connection ───────────────────────────────────────────────────────

/// A virtual LoRa "connection" to a remote node.
/// Since LoRa is connectionless, this is a logical abstraction that
/// lets libp2p treat each peer as a connection endpoint.
pub struct LoraConnection {
    pub remote_node_id: [u8; 32],
    pub outbound_tx:    mpsc::UnboundedSender<(Vec<u8>, [u8; 32])>,
    pub inbound_rx:     Arc<Mutex<mpsc::UnboundedReceiver<Vec<u8>>>>,
}

// ─── LoRa Transport ──────────────────────────────────────────────────────────

/// LoRa transport handle — shareable across the swarm
#[derive(Clone)]
pub struct LoraTransportHandle {
    pub config:     LoraConfig,
    pub local_id:   [u8; 32],
    pub stats:      Arc<Mutex<LoraStats>>,
    pub outbound_tx: mpsc::UnboundedSender<(Vec<u8>, [u8; 32])>,
}

impl LoraTransportHandle {
    /// Send bytes to a remote node over LoRa
    pub async fn send(&self, data: Vec<u8>, to: [u8; 32]) -> Result<()> {
        let byte_count = data.len() as u64;
        let frag_count = (byte_count / super::fragment::MAX_PAYLOAD_BYTES as u64) + 1;

        self.outbound_tx.send((data, to))
            .map_err(|e| anyhow::anyhow!("LoRa send channel closed: {}", e))?;

        let mut stats = self.stats.lock().await;
        stats.packets_sent += 1;
        stats.bytes_sent += byte_count;
        stats.fragments_sent += frag_count;

        Ok(())
    }

    /// Broadcast bytes to all reachable LoRa peers
    pub async fn broadcast(&self, data: Vec<u8>) -> Result<()> {
        let broadcast_id = [0xFFu8; 32]; // Broadcast address
        self.send(data, broadcast_id).await
    }

    /// Get current LoRa statistics for ANRS scoring
    pub async fn stats(&self) -> LoraStats {
        self.stats.lock().await.clone()
    }

    /// Mark a message as relayed (for ANRS LoraScore)
    pub async fn record_relay(&self) {
        let mut stats = self.stats.lock().await;
        stats.messages_relayed += 1;
    }
}

// ─── Transport Initialization ─────────────────────────────────────────────────

/// Initialize LoRa transport and return a handle
///
/// This function:
/// 1. Detects or uses configured serial port
/// 2. Spawns the Meshtastic bridge task
/// 3. Returns a LoraTransportHandle for the swarm
pub async fn init_lora_transport(
    config: LoraConfig,
    local_id: [u8; 32],
    inbound_tx: mpsc::UnboundedSender<ReassembledMessage>,
) -> Result<LoraTransportHandle> {
    // Auto-detect port if not specified
    let port = if config.port == "auto" {
        match detect_meshtastic_port().await {
            Some(p) => {
                info!("Auto-detected Meshtastic port: {}", p);
                p
            }
            None => {
                anyhow::bail!("LoRa enabled but no Meshtastic hardware detected. Check USB connection.");
            }
        }
    } else {
        config.port.clone()
    };

    info!(
        "Initializing LoRa transport: port={} freq={} mode={:?}",
        port,
        config.frequency.to_str(),
        config.mode
    );

    let (outbound_tx, outbound_rx) = mpsc::unbounded_channel::<(Vec<u8>, [u8; 32])>();
    let stats = Arc::new(Mutex::new(LoraStats {
        hardware_present: true,
        ..Default::default()
    }));

    match config.mode {
        LoraMode::Meshtastic => {
            let bridge = MeshtasticBridge::new(port.clone(), local_id);
            let inbound_tx_clone = inbound_tx.clone();

            tokio::spawn(async move {
                if let Err(e) = bridge.start(inbound_tx_clone, outbound_rx).await {
                    error!("Meshtastic bridge error: {}", e);
                }
            });

            info!("LoRa transport ready (Meshtastic mode, {})", config.frequency.to_str());
        }
        LoraMode::Direct => {
            warn!("Direct LoRa mode not yet implemented — use Meshtastic mode for v2.0.3");
        }
    }

    Ok(LoraTransportHandle {
        config,
        local_id,
        stats,
        outbound_tx,
    })
}

// ─── Duty Cycle Manager ───────────────────────────────────────────────────────

/// Enforces EU 868MHz / 433MHz 10% duty cycle restriction.
/// Tracks airtime used in the last rolling hour.
pub struct DutyCycleManager {
    frequency: LoraFrequency,
    tx_log:    Vec<(std::time::Instant, u64)>, // (timestamp, airtime_ms)
}

impl DutyCycleManager {
    pub fn new(frequency: LoraFrequency) -> Self {
        Self { frequency, tx_log: Vec::new() }
    }

    /// Check if transmission is allowed. Returns true if within duty cycle.
    pub fn can_transmit(&mut self, estimated_airtime_ms: u64) -> bool {
        if !self.frequency.has_duty_cycle_restriction() {
            return true;
        }

        let one_hour_ago = std::time::Instant::now()
            .checked_sub(std::time::Duration::from_secs(3600))
            .unwrap_or_else(std::time::Instant::now);

        // Remove entries older than 1 hour
        self.tx_log.retain(|(t, _)| *t > one_hour_ago);

        let used_ms: u64 = self.tx_log.iter().map(|(_, ms)| ms).sum();
        let max_ms = 3600 * 1000 / 10; // 10% of 1 hour = 360,000ms

        if used_ms + estimated_airtime_ms <= max_ms {
            self.tx_log.push((std::time::Instant::now(), estimated_airtime_ms));
            true
        } else {
            warn!(
                "LoRa duty cycle limit reached: used {}ms / {}ms in last hour",
                used_ms, max_ms
            );
            false
        }
    }

    /// Estimate airtime for a payload at given spreading factor and bandwidth
    pub fn estimate_airtime_ms(
        payload_bytes: usize,
        spreading_factor: u8,
        bandwidth_khz: u32,
    ) -> u64 {
        // LoRa airtime formula (simplified):
        // T_sym = 2^SF / BW
        // T_preamble = (preamble_len + 4.25) * T_sym
        // T_payload = (8 + ceil((8*PL - 4*SF + 28 + 16) / (4*SF)) * (CR+4)) * T_sym
        let bw_hz = bandwidth_khz as f64 * 1000.0;
        let t_sym_ms = (2_f64.powi(spreading_factor as i32) / bw_hz) * 1000.0;
        let t_preamble_ms = (16.0 + 4.25) * t_sym_ms;
        let payload_symbols = 8.0 + (((8.0 * payload_bytes as f64 - 4.0 * spreading_factor as f64 + 28.0 + 16.0)
            / (4.0 * spreading_factor as f64)).ceil().max(0.0)) * (4.0 + 4.0);
        let t_payload_ms = payload_symbols * t_sym_ms;
        (t_preamble_ms + t_payload_ms) as u64
    }
}
