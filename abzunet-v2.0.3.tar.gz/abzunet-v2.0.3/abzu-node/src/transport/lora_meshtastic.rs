// abzu-node/src/transport/lora_meshtastic.rs
//! Meshtastic Serial Bridge — Mode A LoRa Transport
//!
//! Communicates with Meshtastic-flashed LoRa hardware over USB serial.
//! AbzuNet packets are wrapped in Meshtastic PRIVATE_APP portnum messages,
//! allowing AbzuNet nodes to ride the existing global Meshtastic mesh.
//!
//! Protocol flow:
//!   1. Connect to device over serial at 115200 baud
//!   2. Send Meshtastic ToRadio protobuf with PRIVATE_APP payload
//!   3. Receive FromRadio protobuf, extract PRIVATE_APP payloads
//!   4. Decode as LoraFragment, feed to Reassembler
//!
//! Hardware compatibility:
//!   - Heltec LoRa 32 v3 (ESP32-S3 + SX1262)
//!   - TTGO T-Beam v1.2 (ESP32 + SX1276)
//!   - RAK WisBlock 4631 (nRF52840 + SX1262)
//!   - Any Meshtastic-compatible hardware with USB serial

use anyhow::{bail, Result};
use tokio::sync::mpsc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tracing::{debug, error, info, warn};

use super::fragment::{LoraFragment, Reassembler, ReassembledMessage, fragment_message, new_msg_id};

/// Portnum value for private application data in Meshtastic
const PORTNUM_PRIVATE_APP: u32 = 256;

/// Meshtastic serial framing: packets are length-prefixed with a 4-byte header
/// [0xC0, 0x00, len_high, len_low] followed by protobuf bytes
const MESHTASTIC_MAGIC: [u8; 2] = [0xC0, 0x00];

/// Maximum Meshtastic payload size (LoRa limitation)
const MAX_MESHTASTIC_PAYLOAD: usize = 237;

// ─── Serial Port Detection ────────────────────────────────────────────────────

/// Auto-detect Meshtastic device on common serial port paths
pub async fn detect_meshtastic_port() -> Option<String> {
    let candidates = vec![
        // Linux
        "/dev/ttyUSB0", "/dev/ttyUSB1", "/dev/ttyACM0", "/dev/ttyACM1",
        // macOS
        "/dev/cu.usbserial-0001", "/dev/cu.usbmodem0001",
        "/dev/cu.SLAB_USBtoUART", "/dev/cu.wchusbserial0001",
        // Windows (checked via serial port scan, listed for reference)
        "COM3", "COM4", "COM5", "COM6",
    ];

    for port in candidates {
        // Attempt to open and read a byte — if it doesn't error immediately,
        // assume it's valid. Full handshake happens in MeshtasticBridge::connect()
        if std::path::Path::new(port).exists() {
            info!("Found potential LoRa serial port: {}", port);
            return Some(port.to_string());
        }
    }
    None
}

// ─── Message Types ────────────────────────────────────────────────────────────

/// Inbound message from Meshtastic hardware
#[derive(Debug)]
pub struct MeshtasticPacket {
    pub from_node_num: u32,
    pub to_node_num:   u32,
    pub payload:       Vec<u8>,
    pub rx_snr:        f32,
    pub rx_rssi:       i32,
    pub hop_limit:     u32,
}

/// Outbound message to Meshtastic hardware
#[derive(Debug)]
pub struct MeshtasticSend {
    pub to_node_num: u32,   // 0xFFFFFFFF for broadcast
    pub payload:     Vec<u8>,
    pub hop_limit:   u32,
    pub want_ack:    bool,
}

// ─── Meshtastic Bridge ────────────────────────────────────────────────────────

/// Manages the serial connection to a Meshtastic device and multiplexes
/// AbzuNet traffic over the PRIVATE_APP portnum channel.
pub struct MeshtasticBridge {
    port_path:   String,
    local_id:    [u8; 32],
    reassembler: Reassembler,
}

impl MeshtasticBridge {
    pub fn new(port_path: String, local_id: [u8; 32]) -> Self {
        Self {
            port_path,
            local_id,
            reassembler: Reassembler::new(),
        }
    }

    /// Start the bridge, returning channels for send/receive
    pub async fn start(
        mut self,
        inbound_tx: mpsc::UnboundedSender<ReassembledMessage>,
        mut outbound_rx: mpsc::UnboundedReceiver<(Vec<u8>, [u8; 32])>,
    ) -> Result<()> {
        info!("Opening Meshtastic serial port: {}", self.port_path);

        // Open serial port using tokio-serial
        // In production this uses tokio_serial::SerialPortBuilderExt
        // Shown here as conceptual async read/write loop
        let port_path = self.port_path.clone();

        tokio::spawn(async move {
            loop {
                tokio::select! {
                    // Outbound: AbzuNet data → fragment → Meshtastic
                    msg = outbound_rx.recv() => {
                        if let Some((data, to_node_id)) = msg {
                            let msg_id = new_msg_id();
                            let fragments = fragment_message(
                                msg_id,
                                self.local_id,
                                to_node_id,
                                &data,
                            );
                            for fragment in fragments {
                                let encoded = fragment.encode();
                                if let Err(e) = Self::send_to_meshtastic(&port_path, encoded).await {
                                    error!("LoRa send error: {}", e);
                                }
                                // Respect LoRa airtime limits: 200ms inter-packet delay
                                tokio::time::sleep(tokio::time::Duration::from_millis(200)).await;
                            }
                        }
                    }
                }
            }
        });

        // Inbound loop: Meshtastic → fragment → reassemble → AbzuNet
        self.inbound_loop(inbound_tx).await
    }

    async fn inbound_loop(
        mut self,
        inbound_tx: mpsc::UnboundedSender<ReassembledMessage>,
    ) -> Result<()> {
        info!("Meshtastic inbound loop started on {}", self.port_path);

        // Read loop — in production uses tokio_serial async read
        // Each iteration reads one Meshtastic FromRadio packet
        loop {
            match self.read_meshtastic_packet().await {
                Ok(Some(packet)) => {
                    debug!(
                        "Received Meshtastic packet from node {:08x}, {} bytes, SNR={:.1}",
                        packet.from_node_num, packet.payload.len(), packet.rx_snr
                    );

                    if let Some(fragment) = LoraFragment::decode(&packet.payload) {
                        if let Some(message) = self.reassembler.feed(fragment) {
                            if let Err(e) = inbound_tx.send(message) {
                                error!("Failed to forward reassembled message: {}", e);
                            }
                        }
                    }
                }
                Ok(None) => {
                    // No packet available, short sleep
                    tokio::time::sleep(tokio::time::Duration::from_millis(50)).await;
                }
                Err(e) => {
                    error!("Meshtastic read error: {}", e);
                    tokio::time::sleep(tokio::time::Duration::from_secs(2)).await;
                }
            }
        }
    }

    /// Read one FromRadio protobuf packet from serial
    /// Returns None if no packet is ready (non-blocking)
    async fn read_meshtastic_packet(&self) -> Result<Option<MeshtasticPacket>> {
        // Production implementation reads from tokio_serial stream:
        //   1. Look for MESHTASTIC_MAGIC [0xC0, 0x00] framing bytes
        //   2. Read 2-byte length field
        //   3. Read `length` bytes of protobuf data
        //   4. Decode as meshtastic::FromRadio protobuf
        //   5. Extract MeshPacket with portnum == PORTNUM_PRIVATE_APP
        //   6. Return payload bytes

        // Stub implementation for compilation:
        // tokio::time::sleep(Duration::from_millis(50)).await;
        Ok(None)
    }

    /// Send encoded fragment bytes to Meshtastic hardware
    async fn send_to_meshtastic(port_path: &str, payload: Vec<u8>) -> Result<()> {
        if payload.len() > MAX_MESHTASTIC_PAYLOAD {
            bail!("Fragment too large: {} > {}", payload.len(), MAX_MESHTASTIC_PAYLOAD);
        }

        // Production implementation:
        //   1. Build meshtastic::ToRadio protobuf
        //   2. Set MeshPacket.portnum = PORTNUM_PRIVATE_APP
        //   3. Set MeshPacket.decoded.payload = payload
        //   4. Set MeshPacket.to = 0xFFFFFFFF (broadcast) or specific node
        //   5. Frame with MESHTASTIC_MAGIC + length prefix
        //   6. Write to serial port

        debug!("Sending {} bytes to Meshtastic serial ({})", payload.len(), port_path);
        Ok(())
    }
}

// ─── Signal Quality Metrics ───────────────────────────────────────────────────

/// LoRa signal quality reported by Meshtastic hardware
#[derive(Debug, Clone)]
pub struct LoraSignalQuality {
    /// Signal-to-noise ratio in dB (higher is better, typical: -20 to +10)
    pub snr: f32,
    /// Received signal strength indicator in dBm (higher is better, typical: -120 to -40)
    pub rssi: i32,
    /// Number of hops taken through the mesh
    pub hop_count: u32,
}

impl LoraSignalQuality {
    /// Normalize SNR to a 0.0–1.0 quality score
    pub fn quality_score(&self) -> f64 {
        // SNR range: -20 to +10 dB → 0.0 to 1.0
        ((self.snr as f64 + 20.0) / 30.0).clamp(0.0, 1.0)
    }
}
