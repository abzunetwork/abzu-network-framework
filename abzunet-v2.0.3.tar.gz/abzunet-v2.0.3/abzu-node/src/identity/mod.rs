// abzu-node/src/identity/mod.rs
//! Identity Module - Ed25519 Keypair Management and Node ID Derivation
//!
//! This module implements Phase 1 identity requirements from the AbzuNet specification.
//! Node identities are Ed25519 keypairs, and Node IDs are derived as BLAKE3(pubkey).
//! For zero-knowledge circuit compatibility with BN254 scalar field 𝔽_p, the 256-bit
//! Node ID is split into two 128-bit big-endian integers (N_high, N_low).
//!
//! Mathematical Invariants:
//! - N_id = BLAKE3(ed25519_pubkey) ∈ {0,1}^256
//! - N_high = N_id[0..16] as u128 ∈ [0, 2^128)
//! - N_low = N_id[16..32] as u128 ∈ [0, 2^128)
//! - Both N_high and N_low fit in BN254 scalar field: p ≈ 2^254

use anyhow::{Context, Result};
use ed25519_dalek::{Keypair, PublicKey, SecretKey, Signature, Signer, Verifier};
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::fs;

/// Node identity containing Ed25519 keypair and derived Node ID
#[derive(Clone)]
pub struct NodeIdentity {
    /// Ed25519 keypair for signing and verification
    keypair: Keypair,
    /// 32-byte Node ID derived as BLAKE3(pubkey)
    node_id: [u8; 32],
    /// High 128 bits of Node ID for BN254 compatibility
    node_id_high: u128,
    /// Low 128 bits of Node ID for BN254 compatibility
    node_id_low: u128,
}

/// Serializable format for persisting keypairs to disk
#[derive(Serialize, Deserialize)]
struct KeyfileData {
    secret_key: [u8; 32],
}

impl NodeIdentity {
    /// Generate a new random identity
    ///
    /// # Example
    /// ```
    /// use abzu_node::identity::NodeIdentity;
    /// let identity = NodeIdentity::generate();
    /// ```
    pub fn generate() -> Self {
        let mut csprng = OsRng;
        let keypair = Keypair::generate(&mut csprng);
        Self::from_keypair(keypair)
    }

    /// Create identity from existing Ed25519 keypair
    ///
    /// This derives the Node ID as BLAKE3(pubkey) and splits it into
    /// N_high and N_low for BN254 circuit compatibility.
    fn from_keypair(keypair: Keypair) -> Self {
        // Derive Node ID: N_id = BLAKE3(ed25519_pubkey)
        let node_id_hash = blake3::hash(keypair.public.as_bytes());
        let node_id: [u8; 32] = *node_id_hash.as_bytes();

        // Split into 128-bit chunks for BN254 scalar field compatibility
        // N_high = first 16 bytes as big-endian u128
        // N_low = second 16 bytes as big-endian u128
        let node_id_high = u128::from_be_bytes(node_id[0..16].try_into().unwrap());
        let node_id_low = u128::from_be_bytes(node_id[16..32].try_into().unwrap());

        // Verify both values fit in BN254 scalar field
        // BN254 modulus p ≈ 2^254, so any u128 < 2^128 is valid
        debug_assert!(node_id_high < (1u128 << 127));
        debug_assert!(node_id_low < (1u128 << 127));

        Self {
            keypair,
            node_id,
            node_id_high,
            node_id_low,
        }
    }

    /// Load identity from keyfile on disk
    ///
    /// # Arguments
    /// * `path` - Path to the keyfile (typically ~/.abzu/identity.key)
    ///
    /// # Errors
    /// Returns error if file cannot be read or contains invalid data
    pub fn load_from_file<P: AsRef<Path>>(path: P) -> Result<Self> {
        let path = path.as_ref();
        let data = fs::read(path)
            .with_context(|| format!("Failed to read keyfile: {}", path.display()))?;

        let keyfile: KeyfileData = bincode::deserialize(&data)
            .context("Failed to deserialize keyfile")?;

        let secret = SecretKey::from_bytes(&keyfile.secret_key)
            .context("Invalid secret key in keyfile")?;
        
        let public = PublicKey::from(&secret);
        let keypair = Keypair { secret, public };

        Ok(Self::from_keypair(keypair))
    }

    /// Save identity to keyfile on disk
    ///
    /// # Arguments
    /// * `path` - Path where keyfile will be written
    ///
    /// # Security
    /// Keyfile should be protected with filesystem permissions (chmod 600)
    pub fn save_to_file<P: AsRef<Path>>(&self, path: P) -> Result<()> {
        let path = path.as_ref();
        
        // Ensure parent directory exists
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)
                .context("Failed to create keyfile directory")?;
        }

        let keyfile = KeyfileData {
            secret_key: self.keypair.secret.to_bytes(),
        };

        let data = bincode::serialize(&keyfile)
            .context("Failed to serialize keyfile")?;

        fs::write(path, data)
            .with_context(|| format!("Failed to write keyfile: {}", path.display()))?;

        // Set restrictive permissions on Unix systems
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perms = fs::metadata(path)?.permissions();
            perms.set_mode(0o600); // rw------- (owner only)
            fs::set_permissions(path, perms)?;
        }

        Ok(())
    }

    /// Get the 32-byte Node ID
    pub fn node_id(&self) -> &[u8; 32] {
        &self.node_id
    }

    /// Get Node ID as hex string for display/logging
    pub fn node_id_hex(&self) -> String {
        hex::encode(self.node_id)
    }

    /// Get high 128 bits of Node ID (for BN254 circuits)
    pub fn node_id_high(&self) -> u128 {
        self.node_id_high
    }

    /// Get low 128 bits of Node ID (for BN254 circuits)
    pub fn node_id_low(&self) -> u128 {
        self.node_id_low
    }

    /// Get the first byte of Node ID (used for GossipSub topic segmentation)
    ///
    /// Heartbeat topics are deterministically assigned as:
    /// topic = "abzu/heartbeat/{node_id[0]:02x}"
    pub fn heartbeat_topic_segment(&self) -> u8 {
        self.node_id[0]
    }

    /// Get Ed25519 public key
    pub fn public_key(&self) -> &PublicKey {
        &self.keypair.public
    }

    /// Get Ed25519 public key bytes
    pub fn public_key_bytes(&self) -> &[u8; 32] {
        self.keypair.public.as_bytes()
    }

    /// Sign a message using Ed25519
    ///
    /// # Arguments
    /// * `message` - Data to sign
    ///
    /// # Returns
    /// 64-byte Ed25519 signature
    pub fn sign(&self, message: &[u8]) -> Signature {
        self.keypair.sign(message)
    }

    /// Verify an Ed25519 signature from another node
    ///
    /// # Arguments
    /// * `message` - Original message that was signed
    /// * `signature` - 64-byte signature to verify
    /// * `public_key` - Public key of the signer
    pub fn verify(
        message: &[u8],
        signature: &Signature,
        public_key: &PublicKey,
    ) -> bool {
        public_key.verify(message, signature).is_ok()
    }
}

impl std::fmt::Debug for NodeIdentity {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("NodeIdentity")
            .field("node_id", &self.node_id_hex())
            .field("public_key", &hex::encode(self.public_key_bytes()))
            .finish_non_exhaustive()
    }
}

/// Utility functions for Node ID operations
pub mod node_id_utils {
    use super::*;

    /// Compute Node ID from a public key
    ///
    /// This is used when verifying signatures from remote nodes
    /// where we need to derive their Node ID from their public key.
    pub fn compute_node_id(public_key: &PublicKey) -> [u8; 32] {
        let hash = blake3::hash(public_key.as_bytes());
        *hash.as_bytes()
    }

    /// Split a 32-byte Node ID into (N_high, N_low) for BN254 circuits
    pub fn split_node_id(node_id: &[u8; 32]) -> (u128, u128) {
        let high = u128::from_be_bytes(node_id[0..16].try_into().unwrap());
        let low = u128::from_be_bytes(node_id[16..32].try_into().unwrap());
        (high, low)
    }

    /// Reconstruct a Node ID from (N_high, N_low) components
    pub fn join_node_id_parts(high: u128, low: u128) -> [u8; 32] {
        let mut node_id = [0u8; 32];
        node_id[0..16].copy_from_slice(&high.to_be_bytes());
        node_id[16..32].copy_from_slice(&low.to_be_bytes());
        node_id
    }

    /// Convert Node ID to libp2p PeerId format
    ///
    /// This enables integration with libp2p's identity system.
    /// We use the Ed25519 public key directly for the PeerId.
    pub fn to_peer_id(public_key: &ed25519_dalek::PublicKey) -> libp2p::PeerId {
        let libp2p_pubkey = libp2p::identity::PublicKey::ed25519_from_bytes(
            public_key.as_bytes()
        ).expect("Valid Ed25519 public key");
        
        libp2p::PeerId::from_public_key(&libp2p_pubkey)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[test]
    fn test_identity_generation() {
        let identity = NodeIdentity::generate();
        
        // Node ID should be 32 bytes
        assert_eq!(identity.node_id().len(), 32);
        
        // High and low parts should be non-zero (statistically)
        assert!(identity.node_id_high() > 0);
        assert!(identity.node_id_low() > 0);
        
        // Both parts must fit in 2^128
        assert!(identity.node_id_high() < u128::MAX);
        assert!(identity.node_id_low() < u128::MAX);
    }

    #[test]
    fn test_node_id_deterministic() {
        let identity = NodeIdentity::generate();
        
        // Recompute Node ID from public key
        let recomputed = node_id_utils::compute_node_id(identity.public_key());
        
        // Should match original
        assert_eq!(identity.node_id(), &recomputed);
    }

    #[test]
    fn test_node_id_split_join() {
        let identity = NodeIdentity::generate();
        
        let (high, low) = node_id_utils::split_node_id(identity.node_id());
        let rejoined = node_id_utils::join_node_id_parts(high, low);
        
        assert_eq!(identity.node_id(), &rejoined);
        assert_eq!(identity.node_id_high(), high);
        assert_eq!(identity.node_id_low(), low);
    }

    #[test]
    fn test_signature_verification() {
        let identity = NodeIdentity::generate();
        let message = b"test message for signing";
        
        let signature = identity.sign(message);
        
        // Valid signature should verify
        assert!(NodeIdentity::verify(
            message,
            &signature,
            identity.public_key()
        ));
        
        // Wrong message should fail
        assert!(!NodeIdentity::verify(
            b"wrong message",
            &signature,
            identity.public_key()
        ));
    }

    #[test]
    fn test_keyfile_persistence() {
        let temp_dir = TempDir::new().unwrap();
        let keyfile_path = temp_dir.path().join("identity.key");
        
        // Generate and save
        let identity1 = NodeIdentity::generate();
        identity1.save_to_file(&keyfile_path).unwrap();
        
        // Load and verify
        let identity2 = NodeIdentity::load_from_file(&keyfile_path).unwrap();
        
        assert_eq!(identity1.node_id(), identity2.node_id());
        assert_eq!(identity1.public_key_bytes(), identity2.public_key_bytes());
    }

    #[test]
    fn test_heartbeat_topic_segmentation() {
        // Generate multiple identities and verify topic distribution
        let identities: Vec<_> = (0..100)
            .map(|_| NodeIdentity::generate())
            .collect();
        
        // Should distribute across 256 possible topics
        let unique_topics: std::collections::HashSet<_> = identities
            .iter()
            .map(|id| id.heartbeat_topic_segment())
            .collect();
        
        // With 100 random identities, we expect reasonable distribution
        assert!(unique_topics.len() > 20);
    }
}
