// abzu-node/src/zkp/mod.rs
//! Zero-Knowledge Proof Generation for Slashing — Phase 4
//! Groth16 over BN254 with Poseidon hash gadgets.

pub mod poseidon;
pub mod circuit;
pub mod prover;

pub use circuit::{HeartbeatFailureCircuit, SlashPublicInputs, SlashWitness};
pub use prover::{SlashProver, SerializedProof};
