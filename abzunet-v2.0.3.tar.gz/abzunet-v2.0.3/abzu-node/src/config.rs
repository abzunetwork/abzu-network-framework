// Configuration Module — v2.0.3
// Adds [lora] and [anrs] sections for LoRa transport and node rewards.
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub identity:   IdentityConfig,
    pub network:    NetworkConfig,
    pub storage:    StorageConfig,
    pub blockchain: BlockchainConfig,
    pub gateway:    GatewayConfig,
    #[serde(default)]
    pub lora:       LoraConfig,
    #[serde(default)]
    pub anrs:       AnrsConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentityConfig {
    pub keyfile: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkConfig {
    pub listen_addrs: Vec<String>,
    pub bootstrap_peers: Vec<String>,
    pub enable_mdns: bool,
    pub enable_udp_broadcast: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageConfig {
    pub data_dir: String,
    pub max_storage_gb: u64,
    pub island_tag: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlockchainConfig {
    pub arbitrum_rpc: String,
    pub registry_address: String,
    pub escrow_address: String,
    pub paymaster_address: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GatewayConfig {
    pub enabled: bool,
    pub bind_addr: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentityConfig {
    pub keyfile: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkConfig {
    pub listen_addrs:       Vec<String>,
    pub bootstrap_peers:    Vec<String>,
    pub enable_mdns:        bool,
    pub enable_udp_broadcast: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageConfig {
    pub data_dir:       String,
    pub max_storage_gb: u64,
    pub island_tag:     String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlockchainConfig {
    pub arbitrum_rpc:      String,
    pub registry_address:  String,
    pub escrow_address:    String,
    pub paymaster_address: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GatewayConfig {
    pub enabled:   bool,
    pub bind_addr: String,
}

// ─── v2.0.3: LoRa Transport Config ───────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoraConfig {
    /// Enable LoRa transport
    pub enabled: bool,
    /// Serial port path (or "auto" for auto-detection)
    pub port: String,
    /// Radio frequency: "433mhz", "868mhz", "915mhz"
    pub frequency: String,
    /// Operating mode: "meshtastic" or "direct"
    pub mode: String,
    /// LoRa spreading factor 7–12 (higher = longer range, slower)
    pub spreading_factor: u8,
    /// Bandwidth in kHz: 125, 250, or 500
    pub bandwidth_khz: u32,
    /// TX power in dBm (max 30, check local regulations)
    pub tx_power_dbm: i32,
    /// Meshtastic hop limit (1–7, default 3)
    pub hop_limit: u32,
}

impl Default for LoraConfig {
    fn default() -> Self {
        Self {
            enabled:          false,
            port:             "auto".to_string(),
            frequency:        "915mhz".to_string(),
            mode:             "meshtastic".to_string(),
            spreading_factor: 9,
            bandwidth_khz:    125,
            tx_power_dbm:     20,
            hop_limit:        3,
        }
    }
}

// ─── v2.0.3: ANRS Config ─────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnrsConfig {
    /// Enable the Autonomous Node Reward System
    pub enabled: bool,
    /// Gigabytes of storage pledged to the network
    pub storage_pledge_gb: u64,
    /// Auto-register with on-chain AbzuNodeRegistry
    pub auto_register: bool,
    /// Auto-withdraw when pending balance exceeds this (in ABZU, 8 decimals)
    /// Default: 10_000_000_000 = 100 ABZU
    pub withdraw_threshold: u64,
    /// Arbitrum RPC endpoint (can also use blockchain.arbitrum_rpc)
    #[serde(default)]
    pub arbitrum_rpc: String,
}

impl Default for AnrsConfig {
    fn default() -> Self {
        Self {
            enabled:            true,
            storage_pledge_gb:  0, // 0 = use storage.max_storage_gb
            auto_register:      true,
            withdraw_threshold: 10_000_000_000, // 100 ABZU
            arbitrum_rpc:       String::new(),
        }
    }
}
