// AbzuNet v2.0.3 — Configuration
// Adds [lora] and [anrs] sections alongside core config.
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub identity:   IdentityConfig,
    pub network:    NetworkConfig,
    pub storage:    StorageConfig,
    pub blockchain: BlockchainConfig,
    pub gateway:    GatewayConfig,
    #[serde(default)]
    pub lora:       LoraConfig,
    #[serde(default)]
    pub anrs:       AnrsConfig,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            identity:   IdentityConfig::default(),
            network:    NetworkConfig::default(),
            storage:    StorageConfig::default(),
            blockchain: BlockchainConfig::default(),
            gateway:    GatewayConfig::default(),
            lora:       LoraConfig::default(),
            anrs:       AnrsConfig::default(),
        }
    }
}

// ─── Identity ─────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentityConfig {
    pub keyfile: String,
}

impl Default for IdentityConfig {
    fn default() -> Self {
        Self { keyfile: "~/.abzu/identity.key".to_string() }
    }
}

// ─── Network ──────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkConfig {
    pub listen_addrs:         Vec<String>,
    pub bootstrap_peers:      Vec<String>,
    pub enable_mdns:          bool,
    pub enable_udp_broadcast: bool,
}

impl Default for NetworkConfig {
    fn default() -> Self {
        Self {
            listen_addrs: vec![
                "/ip4/0.0.0.0/tcp/4001".to_string(),
                "/ip4/0.0.0.0/udp/4001/quic-v1".to_string(),
            ],
            bootstrap_peers:      vec![],
            enable_mdns:          true,
            enable_udp_broadcast: true,
        }
    }
}

// ─── Storage ──────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageConfig {
    pub data_dir:       String,
    pub max_storage_gb: u64,
    pub island_tag:     String,
}

impl Default for StorageConfig {
    fn default() -> Self {
        Self {
            data_dir:       "~/.abzu/store".to_string(),
            max_storage_gb: 50,
            island_tag:     "default".to_string(),
        }
    }
}

// ─── Blockchain ───────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlockchainConfig {
    pub arbitrum_rpc:      String,
    pub registry_address:  String,
    pub escrow_address:    String,
    pub paymaster_address: String,
}

impl Default for BlockchainConfig {
    fn default() -> Self {
        Self {
            arbitrum_rpc:      String::new(),
            registry_address:  String::new(),
            escrow_address:    String::new(),
            paymaster_address: String::new(),
        }
    }
}

// ─── Gateway ──────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GatewayConfig {
    pub enabled:   bool,
    pub bind_addr: String,
}

impl Default for GatewayConfig {
    fn default() -> Self {
        Self {
            enabled:   true,
            bind_addr: "127.0.0.1:8080".to_string(),
        }
    }
}

// ─── v2.0.3: LoRa Transport ───────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoraConfig {
    /// Enable LoRa transport via Meshtastic hardware
    pub enabled: bool,
    /// Serial port path ("auto" for auto-detection, or "/dev/ttyUSB0", "COM3")
    pub port: String,
    /// Radio frequency: "433mhz", "868mhz", "915mhz"
    pub frequency: String,
    /// Operating mode: "meshtastic" (v2.0.3) or "direct" (v2.1)
    pub mode: String,
    /// LoRa spreading factor 7–12 (higher = longer range, slower)
    pub spreading_factor: u8,
    /// Bandwidth in kHz: 125, 250, or 500
    pub bandwidth_khz: u32,
    /// TX power in dBm (max 30 — check local regulations)
    pub tx_power_dbm: i32,
    /// Meshtastic hop limit 1–7 (default 3)
    pub hop_limit: u32,
}

impl Default for LoraConfig {
    fn default() -> Self {
        Self {
            enabled:          false,
            port:             "auto".to_string(),
            frequency:        "915mhz".to_string(),
            mode:             "meshtastic".to_string(),
            spreading_factor: 9,
            bandwidth_khz:    125,
            tx_power_dbm:     20,
            hop_limit:        3,
        }
    }
}

// ─── v2.0.3: Autonomous Node Reward System ────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnrsConfig {
    /// Enable the Autonomous Node Reward System — earn ABZU every epoch
    pub enabled: bool,
    /// Gigabytes pledged to the network (0 = use storage.max_storage_gb)
    pub storage_pledge_gb: u64,
    /// Auto-register with on-chain AbzuNodeRegistry on first run
    pub auto_register: bool,
    /// Auto-withdraw when pending balance exceeds this (ABZU, 8 decimals)
    /// Default: 10_000_000_000 = 100 ABZU
    pub withdraw_threshold: u64,
    /// Optional Arbitrum RPC override (falls back to blockchain.arbitrum_rpc)
    #[serde(default)]
    pub arbitrum_rpc: String,
}

impl Default for AnrsConfig {
    fn default() -> Self {
        Self {
            enabled:            true,
            storage_pledge_gb:  0,
            auto_register:      true,
            withdraw_threshold: 10_000_000_000,
            arbitrum_rpc:       String::new(),
        }
    }
}
