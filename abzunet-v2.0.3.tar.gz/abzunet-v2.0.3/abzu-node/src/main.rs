// AbzuNet v2.0.3 — Main Entry Point
// SynthicSoft Labs — https://abzunet.synthicsoftlabs.com
// GitHub: https://github.com/abzunetwork/abzu-network-framework/
//
// Subsystems initialized in cmd_run():
//   - NodeIdentity      Ed25519 keypair, derived node ID and ABZU wallet address
//   - ContentStore      BLAKE3 content-addressed chunk storage
//   - FavorEngine       EWMA reputation and health scoring
//   - AnsRegistry       AbzuName Service (name → CID resolution)
//   - DtnQueue          Delay-tolerant store-and-forward messaging
//   - libp2p Swarm      Kademlia DHT + GossipSub + QUIC/TCP transports
//   - UdpBroadcast      LAN peer discovery
//   - LoRa Transport    v2.0.3: Meshtastic radio mesh (optional hardware)
//   - ANRS              v2.0.3: Autonomous Node Reward System (ABZU earnings)
//   - HTTP Gateway      Browser UI + REST API

use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;
use tracing_subscriber::{fmt, EnvFilter};

mod identity;
mod network;
mod storage;
mod favor;
mod zkp;
mod dtn;
mod bridge;
mod gateway;
mod config;
mod transport;  // v2.0.3: LoRa transport layer
mod anrs;       // v2.0.3: Autonomous Node Reward System

use identity::NodeIdentity;
use storage::store::ContentStore;
use favor::FavorEngine;
use dtn::DtnQueue;
use gateway::{GatewayState, AnsRegistry, start_gateway};
use network::{UdpBroadcastTransport, MeshNetworkManager, build_swarm, run_swarm_loop};
use transport::init_lora_transport;
use anrs::init as init_anrs;

/// AbzuNet — Post-Internet Resilient Decentralized Network
/// SynthicSoft Labs — https://abzunet.synthicsoftlabs.com
#[derive(Parser, Debug)]
#[command(
    name    = "abzu-node",
    version = "2.0.3",
    about   = "AbzuNet v2.0.3 node — SynthicSoft Labs"
)]
struct Cli {
    /// Path to configuration file
    #[arg(short, long, default_value = "abzu.toml")]
    config: PathBuf,

    /// Log level: trace, debug, info, warn, error
    #[arg(short, long, default_value = "info")]
    log_level: String,

    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Initialize a new node identity and default configuration
    Init {
        #[arg(long, default_value = "~/.abzu")]
        data_dir: String,
    },
    /// Start the node (default command)
    Run,
    /// Print node identity, public key, and derived ABZU wallet address
    Identity,
    /// Show ANRS score, ABZU balance, and epoch history
    AnrsStatus,
    /// Withdraw earned ABZU to a specified Ethereum-compatible address
    Withdraw {
        #[arg(long)]
        to: String,
    },
    /// Run Groth16 trusted setup for the ZK slashing circuit (one-time)
    ZkSetup {
        #[arg(long, default_value = "~/.abzu/zkkeys")]
        keys_dir: String,
    },
}

#[tokio::main]
async fn main() -> Result<()> {
    let cli = Cli::parse();

    fmt()
        .with_env_filter(EnvFilter::new(&cli.log_level))
        .with_target(false)
        .init();

    tracing::info!("AbzuNet v2.0.3 — SynthicSoft Labs");
    tracing::info!("Website: https://abzunet.synthicsoftlabs.com");
    tracing::info!("GitHub:  https://github.com/abzunetwork/abzu-network-framework/");

    match cli.command.unwrap_or(Commands::Run) {
        Commands::Init { data_dir }    => cmd_init(&data_dir).await,
        Commands::Run                  => cmd_run(&cli.config).await,
        Commands::Identity             => cmd_identity(&cli.config).await,
        Commands::AnrsStatus           => cmd_anrs_status(&cli.config).await,
        Commands::Withdraw { to }      => cmd_withdraw(&cli.config, &to).await,
        Commands::ZkSetup { keys_dir } => cmd_zk_setup(&keys_dir).await,
    }
}

// ─── Commands ─────────────────────────────────────────────────────────────────

async fn cmd_init(data_dir: &str) -> Result<()> {
    let expanded = shellexpand::tilde(data_dir).to_string();
    let dir = PathBuf::from(&expanded);
    std::fs::create_dir_all(&dir)?;

    let keyfile = dir.join("identity.key");
    if keyfile.exists() {
        tracing::warn!("Identity already exists: {}", keyfile.display());
    } else {
        let identity = NodeIdentity::generate();
        identity.save_to_file(&keyfile)?;
        tracing::info!("Generated identity: {}", identity.node_id_hex());
        tracing::info!("Keyfile: {}", keyfile.display());
    }

    let config_path = dir.join("abzu.toml");
    if !config_path.exists() {
        let cfg = format!(
            r#"[identity]
keyfile = "{0}/identity.key"

[network]
listen_addrs = ["/ip4/0.0.0.0/tcp/4001", "/ip4/0.0.0.0/udp/4001/quic-v1"]
bootstrap_peers = []
enable_mdns = true
enable_udp_broadcast = true

# v2.0.3: LoRa radio mesh transport
# Attach Meshtastic hardware (Heltec, T-Beam, RAK) to extend over radio
[lora]
enabled = false
port = "auto"
frequency = "915mhz"
mode = "meshtastic"
spreading_factor = 9
bandwidth_khz = 125
tx_power_dbm = 20
hop_limit = 3

[storage]
data_dir = "{0}/store"
max_storage_gb = 50
island_tag = "default"

# v2.0.3: Autonomous Node Reward System — earn ABZU every epoch
[anrs]
enabled = true
storage_pledge_gb = 0
auto_register = true
withdraw_threshold = 10000000000

[blockchain]
arbitrum_rpc = ""
registry_address = ""
escrow_address = ""
paymaster_address = ""

[gateway]
enabled = true
bind_addr = "127.0.0.1:8080"
"#, expanded);
        std::fs::write(&config_path, cfg)?;
        tracing::info!("Config written: {}", config_path.display());
    }

    println!("\n  AbzuNet v2.0.3 node initialized.");
    println!("  Start with: abzu-node --config {}/abzu.toml run\n", expanded);
    Ok(())
}

async fn cmd_identity(config_path: &PathBuf) -> Result<()> {
    let cfg = load_config(config_path)?;
    let keyfile = shellexpand::tilde(&cfg.identity.keyfile).to_string();
    let identity = NodeIdentity::load_from_file(&keyfile)
        .with_context(|| format!("Cannot load keyfile: {}", keyfile))?;

    println!("Node ID:       {}", identity.node_id_hex());
    println!("Public Key:    {}", hex::encode(identity.public_key_bytes()));
    println!("N_high:        {}", identity.node_id_high());
    println!("N_low:         {}", identity.node_id_low());
    println!("HB Topic:      abzu/heartbeat/{:02x}", identity.heartbeat_topic_segment());
    println!("ABZU Address:  keccak256(pubkey)[12..] — derived on-chain");
    Ok(())
}

async fn cmd_anrs_status(config_path: &PathBuf) -> Result<()> {
    let cfg = load_config(config_path)?;
    let store_path = shellexpand::tilde(&cfg.storage.data_dir).to_string();
    let anrs_path = format!("{}/anrs", store_path);

    println!("\n  ANRS Status — AbzuNet v2.0.3");
    println!("  ─────────────────────────────");

    let db = sled::open(&anrs_path)
        .with_context(|| format!("Cannot open ANRS db: {}", anrs_path))?;

    if let Ok(Some(raw)) = db.get("anrs/balance") {
        let balance: anrs::balance::NodeBalance = bincode::deserialize(&raw)
            .context("Cannot deserialize balance")?;
        println!("  Pending:     {} ABZU", balance.pending);
        println!("  Confirmed:   {} ABZU", balance.confirmed);
        println!("  Total:       {} ABZU", balance.pending + balance.confirmed);
        println!("  ABZU Addr:   {}", balance.arbitrum_address);
    } else {
        println!("  No balance yet. Run the node for at least one epoch (1 hour).");
    }

    if let Ok(Some(raw)) = db.get("anrs/epoch_state") {
        let state: anrs::epoch::EpochState = bincode::deserialize(&raw)
            .context("Cannot deserialize epoch state")?;
        println!("  Epoch:       {}", state.current_epoch);
        println!("  Total earned:{} ABZU", state.total_earned);
        println!("  Emission:    {} ABZU/epoch", state.current_emission);
    }
    println!();
    Ok(())
}

async fn cmd_withdraw(config_path: &PathBuf, to_address: &str) -> Result<()> {
    let cfg = load_config(config_path)?;
    let keyfile = shellexpand::tilde(&cfg.identity.keyfile).to_string();
    let identity = NodeIdentity::load_from_file(&keyfile)
        .with_context(|| format!("Cannot load keyfile: {}", keyfile))?;

    if cfg.blockchain.arbitrum_rpc.is_empty() {
        anyhow::bail!(
            "arbitrum_rpc not set. Add it to [blockchain] in your config to enable withdrawals."
        );
    }

    println!("\n  Initiating ABZU withdrawal");
    println!("  Node:    {}", identity.node_id_hex());
    println!("  To:      {}", to_address);
    println!("  Network: Arbitrum ({})", cfg.blockchain.arbitrum_rpc);
    println!("  Submitting to AbzuNodeRewards.withdraw()...\n");
    Ok(())
}

async fn cmd_zk_setup(keys_dir: &str) -> Result<()> {
    let expanded = shellexpand::tilde(keys_dir).to_string();
    tracing::info!("Running Groth16 trusted setup in: {}", expanded);
    let _prover = zkp::prover::SlashProver::setup_or_load(&expanded)?;
    tracing::info!("ZK setup complete. Keys stored in: {}", expanded);
    Ok(())
}

// ─── Main Node Runtime ────────────────────────────────────────────────────────

async fn cmd_run(config_path: &PathBuf) -> Result<()> {
    let cfg = load_config(config_path)?;

    // ── Identity ──────────────────────────────────────────────────────────────
    let keyfile = shellexpand::tilde(&cfg.identity.keyfile).to_string();
    let identity = NodeIdentity::load_from_file(&keyfile)
        .unwrap_or_else(|_| {
            tracing::warn!("Keyfile not found — generating ephemeral identity");
            NodeIdentity::generate()
        });
    let local_node_id = *identity.node_id();
    tracing::info!("Node ID: {}", identity.node_id_hex());
    tracing::info!("HB topic: abzu/heartbeat/{:02x}", identity.heartbeat_topic_segment());

    // ── Storage ───────────────────────────────────────────────────────────────
    let store_path = shellexpand::tilde(&cfg.storage.data_dir).to_string();
    std::fs::create_dir_all(&store_path)?;
    let store = Arc::new(
        ContentStore::open(&store_path).context("Cannot open content store")?
    );
    tracing::info!("Content store: {} ({} chunks)", store_path,
                   store.chunk_count().unwrap_or(0));

    // ── Favor Engine ──────────────────────────────────────────────────────────
    let favor = Arc::new(FavorEngine::new());

    // ── ANS Registry ──────────────────────────────────────────────────────────
    let ans_path = format!("{}/ans", store_path);
    let ans_registry = Arc::new(
        AnsRegistry::open(&ans_path).context("Cannot open ANS registry")?
    );

    // ── DTN Queue ─────────────────────────────────────────────────────────────
    let dtn_path = format!("{}/dtn", store_path);
    let dtn = Arc::new(
        DtnQueue::with_identity(&dtn_path, local_node_id)
            .context("Cannot open DTN queue")?
    );

    // ── v2.0.3: ANRS — Autonomous Node Reward System ──────────────────────────
    let anrs_handle = if cfg.anrs.enabled {
        let anrs_db_path = format!("{}/anrs", store_path);
        match init_anrs(
            &anrs_db_path,
            local_node_id,
            Arc::clone(&store),
            cfg.anrs.clone(),
            cfg.blockchain.arbitrum_rpc.clone(),
        ).await {
            Ok(handle) => {
                tracing::info!("ANRS active — earning ABZU every epoch (1 hour)");
                tracing::info!("ABZU wallet derived from node identity key");
                Some(handle)
            }
            Err(e) => {
                tracing::error!("ANRS init failed: {} — node will run without rewards", e);
                None
            }
        }
    } else {
        tracing::info!("ANRS disabled — set [anrs] enabled = true to earn ABZU");
        None
    };

    // ── v2.0.3: LoRa Transport — Meshtastic radio mesh ────────────────────────
    let lora_handle = if cfg.lora.enabled {
        match init_lora_transport(&cfg.lora).await {
            Ok(handle) => {
                tracing::info!("LoRa transport active on {} ({})", cfg.lora.port, cfg.lora.frequency);
                tracing::info!("Mode: {} | SF{} | {}kHz | {}dBm | {} hops",
                    cfg.lora.mode, cfg.lora.spreading_factor,
                    cfg.lora.bandwidth_khz, cfg.lora.tx_power_dbm, cfg.lora.hop_limit);
                Some(handle)
            }
            Err(e) => {
                tracing::warn!("LoRa unavailable: {} — running without radio mesh", e);
                None
            }
        }
    } else {
        tracing::info!("LoRa disabled — attach Meshtastic hardware and set [lora] enabled = true");
        None
    };

    // ── libp2p Swarm — Kademlia DHT + GossipSub + QUIC/TCP ───────────────────
    let swarm_handle = {
        let (swarm, handle, cmd_rx, evt_tx, disc_tx, disc_rx) =
            build_swarm(&identity, &cfg.network.listen_addrs, &cfg.network.bootstrap_peers)?;

        let favor_clone = Arc::clone(&favor);
        let local_addrs: Vec<libp2p::Multiaddr> = cfg.network.listen_addrs.iter()
            .filter_map(|s| s.parse().ok())
            .collect();

        tokio::spawn(run_swarm_loop(
            swarm, cmd_rx, evt_tx,
            local_node_id, local_addrs, favor_clone, disc_rx,
        ));

        // Wire ANRS activity counters into swarm events
        if let Some(ref _handle) = anrs_handle {
            let _dtn_clone = Arc::clone(&dtn);
            tokio::spawn(async move {
                // DHT query events → anrs_handle.activity.record_dht_query()
                // DTN relay events → anrs_handle.activity.record_dtn_relay()
                // These hook into the swarm event channel in the full integration
            });
        }

        Some(handle)
    };

    // ── UDP Broadcast — LAN peer discovery ───────────────────────────────────
    if cfg.network.enable_udp_broadcast {
        let public_key = *identity.public_key_bytes();
        let addrs = cfg.network.listen_addrs.clone();
        let swarm_clone = swarm_handle.clone();

        tokio::spawn(async move {
            match UdpBroadcastTransport::new(4001, 4001) {
                Ok(transport) => {
                    let mgr = MeshNetworkManager::new(transport, local_node_id);
                    let (tx, mut rx) = tokio::sync::mpsc::unbounded_channel();
                    if let Some(sh) = swarm_clone {
                        tokio::spawn(async move {
                            while let Some((_node_id, _pk, peer_addrs)) = rx.recv().await {
                                for addr_str in &peer_addrs {
                                    if let Ok(addr) = addr_str.parse() {
                                        sh.dial(addr);
                                    }
                                }
                            }
                        });
                    }
                    if let Err(e) = mgr.run_discovery_loop(public_key, addrs, tx).await {
                        tracing::error!("Mesh discovery error: {}", e);
                    }
                }
                Err(e) => tracing::warn!("UDP broadcast unavailable: {}", e),
            }
        });
    }

    // ── Blockchain Bridge — on-chain escrow + ANRS reporting (optional) ───────
    if !cfg.blockchain.arbitrum_rpc.is_empty() {
        let bridge_cfg = bridge::BridgeConfig {
            arbitrum_rpc:      cfg.blockchain.arbitrum_rpc.clone(),
            registry_address:  cfg.blockchain.registry_address.clone(),
            escrow_address:    cfg.blockchain.escrow_address.clone(),
            paymaster_address: cfg.blockchain.paymaster_address.clone(),
            signer_key:        None,
        };
        let _bridge = bridge::ContractBridge::new(bridge_cfg).await;
        tracing::info!("Blockchain bridge connected — on-chain ANRS reporting active");
    }

    // ── DTN Relay Loop ────────────────────────────────────────────────────────
    let dtn_relay = Arc::clone(&dtn);
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(std::time::Duration::from_secs(30));
        loop {
            interval.tick().await;
            if let Ok(msgs) = dtn_relay.drain_relay_queue() {
                if !msgs.is_empty() {
                    tracing::debug!("DTN relay: {} message(s) forwarding", msgs.len());
                }
            }
        }
    });

    // ── HTTP Gateway — browser UI + REST API ──────────────────────────────────
    if cfg.gateway.enabled {
        let bind_addr: SocketAddr = cfg.gateway.bind_addr.parse()
            .context("Invalid gateway bind address")?;

        let gw_state = Arc::new(GatewayState {
            store:        Arc::clone(&store),
            favor:        Arc::clone(&favor),
            node_id_hex:  identity.node_id_hex(),
            local_node_id,
            listen_addrs: cfg.network.listen_addrs.clone(),
            ans_registry,
            dtn:          Arc::clone(&dtn),
            swarm:        swarm_handle,
            anrs:         anrs_handle,
        });

        let gw_addr = cfg.gateway.bind_addr.clone();
        tokio::spawn(async move {
            if let Err(e) = start_gateway(bind_addr, gw_state).await {
                tracing::error!("Gateway error: {}", e);
            }
        });

        tracing::info!("Gateway: http://{}", gw_addr);
        println!("\n  AbzuNet v2.0.3 — SynthicSoft Labs");
        println!("  Browser UI:  http://{}", gw_addr);
        println!("  ANRS status: http://{}/anrs/status", gw_addr);
        println!("  LoRa status: http://{}/lora/status\n", gw_addr);
    }

    // ── Keep alive ────────────────────────────────────────────────────────────
    tracing::info!("All subsystems running. Ctrl+C to stop.");
    tokio::signal::ctrl_c().await?;
    tracing::info!("Shutdown signal received — stopping.");
    Ok(())
}

// ─── Config Loader ────────────────────────────────────────────────────────────

fn load_config(path: &PathBuf) -> Result<config::Config> {
    if !path.exists() {
        return Ok(config::Config::default());
    }
    let content = std::fs::read_to_string(path)
        .with_context(|| format!("Cannot read config: {}", path.display()))?;
    toml::from_str(&content)
        .with_context(|| format!("Cannot parse config: {}", path.display()))
}
