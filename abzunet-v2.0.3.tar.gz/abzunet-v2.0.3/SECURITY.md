# Security Policy

AbzuNet is free, open infrastructure. The contracts that govern ABZU token emissions
and the node software that millions of people may eventually rely on must be held to
the highest security standard. We take every report seriously.

---

## Supported Versions

| Version | Supported |
|---------|-----------|
| v2.0.3 (current) | Yes |
| v2.0.2 | Yes — node software only |
| v2.0.1 and earlier | No |

Smart contract vulnerabilities are considered critical regardless of version, as
deployed contracts cannot be patched in place.

---

## Reporting a Vulnerability

**Please do not open a public GitHub issue for security vulnerabilities.**

If you discover a vulnerability — in the smart contracts, the node software, the
cryptographic implementation, the token economics, or anywhere else in this codebase
— report it privately first. Public disclosure before a fix is in place could expose
node operators and token holders to real harm.

### Contact

Email your report to both addresses:

- abzunetteam@gmail.com
- contact@synthicsoftlabs.com

Use the subject line: `[SECURITY] AbzuNet Vulnerability Report`

If the vulnerability is severe, please encrypt your report using our PGP key
(published at https://abzunet.synthicsoftlabs.com/security).

### What to include

- A clear description of the vulnerability
- The component affected (smart contract, node binary, cryptography, networking, etc.)
- Steps to reproduce or a proof of concept
- Your assessment of severity and potential impact
- Whether you believe it is currently being exploited

### Response timeline

- **Initial acknowledgement:** within 48 hours
- **Preliminary assessment:** within 5 business days
- **Fix timeline communicated:** within 10 business days
- **Public disclosure:** coordinated with you after fix is deployed

We will keep you informed at every step. If you do not hear back within 48 hours,
follow up directly at contact@synthicsoftlabs.com.

---

## Scope

### In scope — highest priority

- `contracts/src/AbzuToken.sol` — token supply, burn mechanism, transfer logic
- `contracts/src/AbzuNodeRewards.sol` — epoch distribution, halving schedule, withdrawal
- `contracts/src/AbzuDataCredits.sol` — burn-and-mint equilibrium, price oracle
- `abzu-node/src/identity/` — Ed25519 key generation and management
- `abzu-node/src/zkp/` — zero-knowledge proof circuits
- `abzu-node/src/anrs/` — scoring, challenge-response, balance derivation
- `abzu-node/src/storage/` — content addressing, chunk integrity
- Any cryptographic primitive or function handling private keys or funds

### In scope — standard priority

- `abzu-node/src/network/` — peer-to-peer networking, DHT, GossipSub
- `abzu-node/src/dtn/` — delay-tolerant networking, message relay
- `abzu-node/src/transport/` — LoRa transport, Meshtastic bridge
- `abzu-node/src/gateway/` — HTTP gateway, API endpoints
- Dependency vulnerabilities affecting the above

### Out of scope

- Attacks requiring physical access to a node operator's hardware
- Social engineering attacks
- Bugs in third-party dependencies that have already been publicly disclosed
- Issues in example scripts or documentation that have no security impact
- Theoretical vulnerabilities with no practical exploit path

---

## Smart Contract Security Notes

The ABZU token contracts are designed with the following security properties:

**Fixed supply.** The `AbzuToken` constructor mints exactly 1,000,000,000 ABZU once.
There is no mint function callable after deployment. Total supply can only decrease
through the burn mechanism.

**No upgrade mechanism.** Contracts are not upgradeable proxies. What is deployed
is final. This eliminates the risk of a malicious upgrade but also means bugs cannot
be patched without deploying new contracts. Audit before deployment is critical.

**Oracle trust assumption.** `AbzuNodeRewards` trusts authorized oracle addresses to
submit epoch scores. Compromise of an oracle address is a critical threat vector.
Oracle key rotation procedures are documented separately.

**Withdrawal requires caller verification.** Nodes withdraw earnings by calling
`withdraw()` from their derived Arbitrum address. The derivation from Ed25519 public
key is deterministic and documented in `abzu-node/src/anrs/balance.rs`.

---

## Bug Bounty

We do not currently operate a formal paid bug bounty program. However, researchers
who responsibly disclose valid vulnerabilities — particularly in the smart contracts —
will be recognized publicly (with your permission) and considered for ABZU token
grants from the Ecosystem Fund once the network is live.

We are committed to establishing a formal bounty program before mainnet token launch.

---

## Hall of Fame

Researchers who have responsibly disclosed vulnerabilities will be listed here
with their permission.

*None yet — be the first.*

---

## Links

- Website: https://abzunet.synthicsoftlabs.com
- GitHub: https://github.com/synthicsoft/abzunet-v2
- General contact: contact@synthicsoftlabs.com
- Security contact: abzunetteam@gmail.com

---

*AbzuNet is built by SynthicSoft Labs and released under the MIT License.
Security of the network is a shared responsibility — thank you for helping keep it safe.*
