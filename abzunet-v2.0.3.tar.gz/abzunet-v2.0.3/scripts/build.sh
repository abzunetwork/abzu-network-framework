#!/bin/bash
# AbzuNet v2.0.3 Build Script
set -e
echo "Building AbzuNet v2.0.3..."
cargo build --release --all-features
echo "Build complete!"
