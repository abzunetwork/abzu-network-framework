#!/bin/bash
# Initialize new AbzuNet node
set -e

CONFIG_DIR="${HOME}/.abzu"
CONFIG_FILE="${CONFIG_DIR}/abzu.toml"
KEY_FILE="${CONFIG_DIR}/identity.key"

echo "=== AbzuNet Node Initialization ==="

# Create config directory
mkdir -p "${CONFIG_DIR}"
mkdir -p "${CONFIG_DIR}/storage"

# Generate configuration if it doesn't exist
if [ ! -f "${CONFIG_FILE}" ]; then
    echo "Generating configuration..."
    cat > "${CONFIG_FILE}" << 'CONF'
[identity]
keyfile = "~/.abzu/identity.key"

[network]
listen_addrs = ["/ip4/0.0.0.0/tcp/4001", "/ip4/0.0.0.0/udp/4001/quic-v1"]
bootstrap_peers = []
enable_mdns = true
enable_udp_broadcast = true

[storage]
data_dir = "~/.abzu/storage"
max_storage_gb = 100
island_tag = "default"

[blockchain]
arbitrum_rpc = "https://sepolia-rollup.arbitrum.io/rpc"
registry_address = "0x0000000000000000000000000000000000000000"
escrow_address = "0x0000000000000000000000000000000000000000"
paymaster_address = "0x0000000000000000000000000000000000000000"

[gateway]
enabled = true
bind_addr = "127.0.0.1:8080"
CONF
    echo "✓ Configuration created at ${CONFIG_FILE}"
else
    echo "✓ Configuration already exists"
fi

echo ""
echo "Node initialized successfully!"
echo "Edit configuration: ${CONFIG_FILE}"
echo "Start node: abzu-node start --config ${CONFIG_FILE}"
